"""Rebuild editable CadQuery solids, STEP assembly, BREP, GLB and web mesh.

Usage: .venv-cad/bin/python cad/build_conveyor.py
No Fusion, GPU, cloud CAD, private model or paid service is used.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import struct
import sys
from datetime import datetime, timezone
from collections import defaultdict
from pathlib import Path
import cadquery as cq
import numpy as np
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
from OCP.BRep import BRep_Tool
from OCP.BRepLib import BRepLib_ToolTriangulatedShape
from OCP.TopLoc import TopLoc_Location
from OCP.TopAbs import TopAbs_Orientation

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(HERE))


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def as_shape(value):
    if isinstance(value,cq.Workplane):
        shapes=[v for v in value.vals() if isinstance(v,cq.Shape)]
        return shapes[0] if len(shapes)==1 else cq.Compound.makeCompound(shapes)
    return value


def build(parameters):
    from mechanical_base import build as mechanical
    from sensor_feed import build as sensing
    from discharge import build as discharge
    parts=[]
    names=set()
    def add(ident,name,category,shape,color='#8b9da4',**meta):
        if ident in names:
            raise ValueError('Duplicate part id: '+ident)
        names.add(ident)
        shape=as_shape(shape)
        if not isinstance(shape,cq.Shape):
            raise TypeError((ident,type(shape)))
        if not shape.isValid() or not shape.Solids():
            raise ValueError('Invalid or non-solid part: '+ident)
        if shape.Volume()<=0:
            raise ValueError('Zero-volume part: '+ident)
        if isinstance(meta.get('animation'),dict):
            a=meta['animation']
            if 'pivot_mm' in a:a['pivot']=a.pop('pivot_mm')
            if 'radius_mm' in a:a['radius']=a.pop('radius_mm')
            if isinstance(a.get('axis'),list):
                a['axis']='xyz'[max(range(3),key=lambda i:abs(a['axis'][i]))]
        category={'rollers':'roller','bearings':'bearing','guards':'guard','cables':'cable'}.get(category,category)
        if meta.get('default_visible') is False or meta.get('cutaway_hidden'):
            meta['default_hidden']=True
        meta.setdefault('evidence_status','unvalidated_concept_selection')
        meta.setdefault('manufacturing_status','preliminary_geometry_not_fabrication_release')
        parts.append(dict(id=ident,name=name,category=category,shape=shape,color=color,**meta))
    mechanical(add,parameters)
    sensing(add,parameters)
    discharge(add,parameters)
    return parts


def rgb(c):
    if isinstance(c,str):return [int(c.lstrip('#')[i:i+2],16)/255 for i in (0,2,4)]
    return list(c[:3])


def bbox(shape):
    b=Bnd_Box()
    BRepBndLib.AddOptimal_s(shape.wrapped,b,False,False)
    x0,y0,z0,x1,y1,z1=b.Get()
    return {'min':[x0,y0,z0],'max':[x1,y1,z1]}


def tessellate(part):
    # Retain indexed CAD-face vertices. Surface-derived normals shade true
    # cylinders/roundovers smoothly while independent BRep faces retain their
    # hard boundaries. This does not round or otherwise alter source geometry.
    shape=part['shape'];shape.mesh(0.6,0.16)
    from OCP.BRepAdaptor import BRepAdaptor_Surface
    vertices=[];normals=[];indices=[];apex_winding_repairs=[]
    for face_index,face in enumerate(shape.Faces()):
        loc=TopLoc_Location()
        poly=BRep_Tool.Triangulation_s(face.wrapped,loc)
        if poly is None:continue
        BRepLib_ToolTriangulatedShape.ComputeNormals_s(face.wrapped,poly)
        transform=loc.Transformation()
        reverse=face.wrapped.Orientation()==TopAbs_Orientation.TopAbs_REVERSED
        cone_apex=None
        if face.geomType()=='CONE':
            apex=BRepAdaptor_Surface(face.wrapped).Cone().Apex()
            cone_apex=np.array([apex.X(),apex.Y(),apex.Z()])
        offset=len(vertices)
        for i in range(1,poly.NbNodes()+1):
            vertex=poly.Node(i).Transformed(transform)
            normal=poly.Normal(i).Transformed(transform)
            direction=-1 if reverse else 1
            vertices.append([vertex.X(),vertex.Y(),vertex.Z()])
            normals.append([direction*normal.X(),direction*normal.Y(),direction*normal.Z()])
        for face_triangle_index,tri in enumerate(poly.Triangles()):
            order=(1,3,2) if reverse else (1,2,3)
            triangle=[tri.Value(j)+offset-1 for j in order]
            points=np.asarray([vertices[i] for i in triangle])
            area=np.cross(points[1]-points[0],points[2]-points[0])
            area_length=np.linalg.norm(area)
            if area_length>1e-10:
                reference=np.asarray([normals[i] for i in triangle]).mean(axis=0)
                agreement=float(np.dot(area,reference)/area_length)
                if agreement<=0:
                    # OCC can return a reversed triangle incident on the
                    # singular apex of a trimmed cone. Its nonsingular source
                    # surface normals still determine the outward side. Repair
                    # only that demonstrable case, preserving every position,
                    # source normal and undirected triangle edge. Other normal
                    # disagreements remain hard failures, not a generic flip.
                    distances=(np.linalg.norm(points-cone_apex,axis=1)
                               if cone_apex is not None else np.full(3,np.inf))
                    nonapex=distances>1e-6
                    if cone_apex is None or not np.any(~nonapex) or not np.any(nonapex):
                        raise ValueError(f'CAD normal/winding disagreement outside cone apex: {part["id"]}, face {face_index}')
                    regular_reference=np.asarray([normals[i] for i in triangle])[nonapex].mean(axis=0)
                    if np.dot(area,regular_reference)>=0:
                        raise ValueError(f'Ambiguous cone-apex orientation: {part["id"]}, face {face_index}')
                    triangle[1],triangle[2]=triangle[2],triangle[1]
                    apex_winding_repairs.append({'face_index':face_index,
                        'triangle_index_in_face':face_triangle_index,
                        'analytic_apex_mm':cone_apex.tolist(),
                        'winding_to_source_normal_agreement_before':agreement})
            indices.append(triangle)
    xyz=np.asarray(vertices,dtype=np.float64)
    nn=np.asarray(normals,dtype=np.float64)
    triangles=np.asarray(indices,dtype=np.int64)
    edges=xyz[triangles]
    areas=np.cross(edges[:,1]-edges[:,0],edges[:,2]-edges[:,0])
    triangles=triangles[np.linalg.norm(areas,axis=1)>1e-10]
    used,remap=np.unique(triangles.ravel(),return_inverse=True)
    xyz=xyz[used];nn=nn[used];triangles=remap.reshape((-1,3))
    if not np.isfinite(xyz).all() or not np.isfinite(nn).all():
        raise ValueError('Nonfinite CAD mesh: '+part['id'])
    if np.max(np.abs(np.linalg.norm(nn,axis=1)-1))>1e-5:
        raise ValueError('Invalid CAD surface normals: '+part['id'])
    base={k:v for k,v in part.items() if k!='shape'}
    return dict(base,tessellation_diagnostics={'cone_apex_winding_repair_count':len(apex_winding_repairs),
                    'cone_apex_winding_repairs':apex_winding_repairs,
                    'positions_and_source_normals_modified':False},
                vertices=np.round(xyz,5).ravel().tolist(),normals=np.round(nn,6).ravel().tolist(),
                indices=triangles.ravel().tolist(),bbox=bbox(part['shape']))


def write_glb(objects,path):
    """Standard GLB2, named assembly nodes, mm->m and Z-up->Y-up explicitly."""
    scene={'asset':{'version':'2.0','generator':'Ferrosift CadQuery2.8 BRep tessellation'},'scene':0,
      'scenes':[{'nodes':[]}],'nodes':[],'meshes':[],'materials':[],'buffers':[{'byteLength':0}],
      'bufferViews':[],'accessors':[]}
    data=bytearray()
    def accessor(array,component,kind,target,limits=False):
        while len(data)%4:data.append(0)
        start=len(data);data.extend(array.tobytes())
        bv=len(scene['bufferViews']);scene['bufferViews'].append({'buffer':0,'byteOffset':start,'byteLength':array.nbytes,'target':target})
        a={'bufferView':bv,'componentType':component,'count':len(array),'type':kind}
        if limits:a.update(min=array.min(axis=0).astype(float).tolist(),max=array.max(axis=0).astype(float).tolist())
        i=len(scene['accessors']);scene['accessors'].append(a);return i
    for ob in objects:
        v=np.array(ob['vertices'],dtype=np.float32).reshape((-1,3))
        n=np.array(ob['normals'],dtype=np.float32).reshape((-1,3))
        v=np.column_stack((v[:,0],v[:,2],-v[:,1])).astype('<f4')*.001
        n=np.column_stack((n[:,0],n[:,2],-n[:,1])).astype('<f4')
        ind=np.array(ob['indices'],dtype='<u4')
        pa=accessor(v,5126,'VEC3',34962,True);na=accessor(n,5126,'VEC3',34962)
        ia=accessor(ind,5125,'SCALAR',34963)
        mat=len(scene['materials']);alpha=ob.get('opacity',1)
        material={'name':ob['id']+'_finish','pbrMetallicRoughness':{'baseColorFactor':rgb(ob['color'])+[alpha],'metallicFactor':.2,'roughnessFactor':.65},'doubleSided':True}
        if alpha<1:material['alphaMode']='BLEND'
        scene['materials'].append(material)
        mi=len(scene['meshes']);scene['meshes'].append({'name':ob['id'],'primitives':[{'attributes':{'POSITION':pa,'NORMAL':na},'indices':ia,'material':mat}]})
        animation=ob.get('animation')
        if animation:
            animation=dict(animation)
            if 'pivot' in animation:
                x,y,z=animation['pivot'];animation['pivot']=[x*.001,z*.001,-y*.001]
            if 'radius' in animation:animation['radius']*=.001
            axis=animation.get('axis')
            if axis in ('x','y','z'):
                animation['axis']={'x':'x','y':'z','z':'y'}[axis]
                if axis=='y':
                    if 'angle' in animation:animation['angle']*=-1
                    animation['direction']=-(animation.get('direction',1))
            if isinstance(animation.get('direction'),list):
                x,y,z=animation['direction'];animation['direction']=[x,z,-y]
            animation['coordinate_system']='glTF metres, Y up'
        ni=len(scene['nodes']);scene['nodes'].append({'name':ob['id'],'mesh':mi,'extras':{'label':ob['name'],'category':ob['category'],'default_hidden':ob.get('default_hidden',False),'optional':ob.get('optional',False),'installed':ob.get('installed'),'animation':animation, 'status':'unvalidated_concept_geometry'}})
        scene['scenes'][0]['nodes'].append(ni)
    scene['buffers'][0]['byteLength']=len(data)
    payload=json.dumps(scene,separators=(',',':')).encode()
    payload+=b' '*((-len(payload))%4);data+=b'\0'*((-len(data))%4)
    result=struct.pack('<4sII',b'glTF',2,12+8+len(payload)+8+len(data))+struct.pack('<I4s',len(payload),b'JSON')+payload+struct.pack('<I4s',len(data),b'BIN\0')+data
    path.write_bytes(result)


def export(parts,p):
    from discharge import ROUTES
    out=ROOT/'exports';out.mkdir(exist_ok=True)
    catdir=out/'categories';catdir.mkdir(exist_ok=True)
    web=ROOT/'web';web.mkdir(exist_ok=True)
    qa=ROOT/'verification';qa.mkdir(exist_ok=True)
    assembly=cq.Assembly(name='Ferrosift_Investor_Concept_20261014_v01')
    categories=defaultdict(list)
    for part in parts:
        assembly.add(part['shape'],name=part['id'],color=cq.Color(*rgb(part['color'])))
        categories[part['category']].append(part['shape'])
    path=out/'conveyor_assembly.step'
    print(f'Exporting {len(parts)} named components to STEP',flush=True)
    assembly.export(str(path),exportType='STEP',unit='MM',outputUnit='MM')
    compound=cq.Compound.makeCompound([part['shape'] for part in parts])
    compound.exportBrep(str(out/'conveyor_assembly.brep'))
    for cat,shapes in categories.items():
        cq.exporters.export(cq.Compound.makeCompound(shapes),str(catdir/f'{cat}.step'))
    subsetdir=out/'drawing_subsets';subsetdir.mkdir(exist_ok=True)
    sensorparts=[part['shape'] for part in parts if part['category'] in ('camera','light','sensor','window') or (part['category']=='hood' and not part.get('default_hidden') and not any(t in part['id'].lower() for t in ('panel','roof','window','door','cover')))]
    cq.exporters.export(cq.Compound.makeCompound(sensorparts),str(subsetdir/'sensor_cell.step'))
    print('Tessellating verified BRep solids',flush=True)
    objects=[tessellate(part) for part in parts]
    manifest={'schema_version':1,'release_id':'investor_package_20261014_v01','generated_utc':datetime.now(timezone.utc).isoformat(),'units':'mm','coordinate_system':'x-longitudinal,y-transverse,z-up',
        'concept_status':'Discussion geometry; not fabrication, operation, safety or performance approval.',
        'parameters_sha256':digest(ROOT/'design_basis'/'parameters.json'),
        'step_sha256':digest(path),'assembly_bbox':bbox(compound),'part_count':len(parts),
        'parts':[{**{k:v for k,v in part.items() if k!='shape'},'bbox':bbox(part['shape']),
                  'volume_mm3':part['shape'].Volume(),'solid_count':len(part['shape'].Solids())} for part in parts],
        'categories':{cat:{'part_count':sum(1 for part in parts if part['category']==cat),'step_file':f'categories/{cat}.step','sha256':digest(catdir/f'{cat}.step')} for cat in categories}}
    (out/'assembly_manifest.json').write_text(json.dumps(manifest,indent=2))
    sourcehashes={f.name:digest(f) for f in HERE.glob('*.py')}
    g=p['geometry_mm'];ox=g['belt']['discharge_lip_x']-3000;oz=g['belt']['top_z']-1000
    routes={k:[[x+ox,y,z+oz] for x,y,z in path] for k,path in ROUTES.items()}
    zones=[]
    for si,(a,b) in enumerate(zip([-1450,0,1050,2000,3100], [0,1050,2000,3100,4250])):
        active=[r for r in manifest['parts'] if r['bbox']['max'][0]>a and r['bbox']['min'][0]<b]
        if not active:continue
        for side in (-1,1):
            edge=min(r['bbox']['min'][1] for r in active) if side<0 else max(r['bbox']['max'][1] for r in active)
            far=edge+side*g['service']['side_clearance']
            zones.append({'id':f'service_{si}_{side}','points':[[a,edge,0],[b,edge,0],[b,far,0],[a,far,0]],'label':'900 mm reserved beyond closed equipment; door/bin sweeps need validation'})
    packet={'schemaVersion':1,'units':'mm','coordinateSystem':'x-longitudinal,y-transverse,z-up',
      'provenance':{'kind':'cad-tessellation','releaseId':'investor_package_20261014_v01','description':'Generated from executed CadQuery/OpenCascade solid assembly with indexed vertices and source-surface normals. Unvalidated prototype design; not fabrication or tested machine performance.','cadquery':cq.__version__,'stepSha256':digest(path),'sourceSha256':sourcehashes},
      'objects':objects,'routes':routes,'serviceZones':zones,'routeStatus':'Illustrative group routing only; paths are not measured trajectories.',
      'footprints':{'camera':{'centre':[g['sensing']['rgb_center_x'],0,g['belt']['top_z']+1],'width':p['width_assumptions_mm']['camera_field_of_view_example'],'length':300,'status':'Provisional example; not validated coverage.'},'beltWidth':g['belt']['active_width'],'usableSensingWidth':None,'lastSensingDatumX':g['sensing']['last_sensing_datum_x'],'cassetteHousingEdgeX':g['induction_cassette']['center_x']+g['induction_cassette']['length']/2}}
    meshpath=web/'conveyor-assembly.json';meshpath.write_text(json.dumps(packet,separators=(',',':')))
    write_glb(objects,out/'conveyor_assembly.glb')
    print('Reimporting complete STEP for native geometry checks',flush=True)
    reopened=cq.importers.importStep(str(path)).val()
    original_volume=sum(part['shape'].Volume() for part in parts)
    receipt={'status':'passed','release_id':'investor_package_20261014_v01','generated_utc':datetime.now(timezone.utc).isoformat(),'cadquery':cq.__version__,'all_components_valid':all(part['shape'].isValid() for part in parts),
       'component_count':len(parts),'source_solid_count':len(compound.Solids()),'step_solid_count':len(reopened.Solids()),
       'step_valid':reopened.isValid(),'source_volume_mm3':original_volume,'step_volume_mm3':reopened.Volume(),
       'relative_volume_error':abs(reopened.Volume()-original_volume)/original_volume,
       'source_bbox_mm':bbox(compound),'step_bbox_mm':bbox(reopened),'triangle_count':sum(len(o['indices'])//3 for o in objects),'vertex_count':sum(len(o['vertices'])//3 for o in objects),'normal_method':'OpenCascade source-surface normals; face boundaries remain independent; indexed tessellation',
       'files':{f.name:{'bytes':f.stat().st_size,'sha256':digest(f)} for f in [path,out/'conveyor_assembly.brep',out/'conveyor_assembly.glb',meshpath]},
       'source_sha256':sourcehashes,'limitations':['Solid validity and round-trip checks do not establish strength, sensor performance, chute flow, safe guarding or machine compliance.','Some bolts/locators/assembly mating faces intentionally touch or overlap. See targeted interference report.']}
    receipt['bbox_method']='OpenCascade AddOptimal, triangulation disabled, no shape tolerance expansion'
    receipt['bbox_max_difference_mm']=max(abs(a-b) for side in ('min','max') for a,b in zip(receipt['source_bbox_mm'][side],receipt['step_bbox_mm'][side]))
    if not receipt['step_valid'] or receipt['source_solid_count']!=receipt['step_solid_count'] or receipt['relative_volume_error']>1e-6 or receipt['bbox_max_difference_mm']>.001:
        receipt['status']='failed'
    (qa/'cad_export_validation.json').write_text(json.dumps(receipt,indent=2))
    print(json.dumps({k:receipt[k] for k in ('status','component_count','source_solid_count','step_solid_count','relative_volume_error','triangle_count')}),flush=True)
    if receipt['status']!='passed':raise RuntimeError('STEP round-trip failed')
    return receipt


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--validate-only',action='store_true');parser.add_argument('--belt-width',type=float)
    args=parser.parse_args()
    input_paths=list(HERE.glob('*.py'))+list(HERE.glob('*_spec.json'))+[ROOT/'design_basis'/'parameters.json']
    initial_input_hashes={str(f.relative_to(ROOT)):digest(f) for f in input_paths}
    params=json.loads((ROOT/'design_basis'/'parameters.json').read_text())
    if args.belt_width:params['geometry_mm']['belt']['active_width']=args.belt_width
    parts=build(params)
    if args.validate_only:
        print(json.dumps({'components':len(parts),'all_valid':True,'belt_width_input':params['geometry_mm']['belt']['active_width'],'parts':[{'id':x['id'],'bbox':bbox(x['shape'])} for x in parts if x['category']=='belt']}))
    else:
        if args.belt_width:raise ValueError('Variant may only be used with --validate-only; preserve the frozen release geometry')
        result=export(parts,params)
        result['input_sha256']=initial_input_hashes
        result['source_unchanged_during_build']=all(digest(ROOT/f)==h for f,h in initial_input_hashes.items())
        if not result['source_unchanged_during_build']:result['status']='failed_source_changed_during_build'
        (ROOT/'verification'/'cad_export_validation.json').write_text(json.dumps(result,indent=2)+'\n')
        if not result['source_unchanged_during_build']:raise RuntimeError('Source changed during build; candidate must be rebuilt')
