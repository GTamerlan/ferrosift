"""Executed solid-CAD mechanical base for the Ferrosift conveyor concept.

Units: mm; x = travel, y = transverse, z = up. Every mechanical selection in
this module is a CONCEPT STUDY ASSUMPTION, not a rated or fabrication design.
Entry point: build(add, geometry_mm). The parent owns integration and export.
No sensor/window, hood, feeder, ejector, chute or review-gate geometry here.
"""
from __future__ import annotations

import math
import cadquery as cq

STEEL = "#465967"
STAINLESS = "#B7C5CC"
FASTENER = "#94A3AD"
BELT = "#263C43"
POLYMER = "#D4DFD3"
DRIVE = "#335E72"
GUARD = "#A8C3CF"


def box(x0, x1, y0, y1, z0, z1):
    return cq.Solid.makeBox(x1-x0, y1-y0, z1-z0, cq.Vector(x0,y0,z0))


def cy(r, y0, y1, x, z):
    return cq.Solid.makeCylinder(r, y1-y0, cq.Vector(x,y0,z), cq.Vector(0,1,0))


def cx(r, x0, x1, y, z):
    return cq.Solid.makeCylinder(r, x1-x0, cq.Vector(x0,y,z), cq.Vector(1,0,0))


def cz(r, z0, z1, x, y):
    return cq.Solid.makeCylinder(r, z1-z0, cq.Vector(x,y,z0))


def rounded_box(x0,x1,y0,y1,z0,z1,r=6,axis="Z"):
    """A radiused extrusion inside the supplied envelope, not a mesh bevel.

    Only extrusion-parallel edges are rounded. Radius is a disclosed study
    selection; it does not encode a purchased RHS profile or bend allowance.
    """
    shape=box(x0,x1,y0,y1,z0,z1)
    return cq.Workplane(obj=shape).edges("|"+axis).fillet(r).val()


def tube_x(x0,x1,y,z,w,h,t=4):
    return rounded_box(x0,x1,y-w/2,y+w/2,z-h/2,z+h/2,2*t,"X").cut(
        rounded_box(x0-1,x1+1,y-w/2+t,y+w/2-t,z-h/2+t,z+h/2-t,t,"X"))


def tube_y(y0,y1,x,z,w,h,t=4):
    return rounded_box(x-w/2,x+w/2,y0,y1,z-h/2,z+h/2,2*t,"Y").cut(
        rounded_box(x-w/2+t,x+w/2-t,y0-1,y1+1,z-h/2+t,z+h/2-t,t,"Y"))


def tube_z(z0,z1,x,y,w=60,t=4):
    return rounded_box(x-w/2,x+w/2,y-w/2,y+w/2,z0,z1,2*t,"Z").cut(
        rounded_box(x-w/2+t,x+w/2-t,y-w/2+t,y+w/2-t,z0-1,z1+1,t,"Z"))


def channel_x(x0,x1,y0,y1,z0,z1,t=3,r=6):
    """Open-top channel with radiused bottom bends and unchanged upper edge."""
    outside=cq.Workplane(obj=box(x0,x1,y0,y1,z0,z1)).edges("|X and <Z").fillet(r).val()
    inside=cq.Workplane(obj=box(x0-1,x1+1,y0+t,y1-t,z0+t,z1+1)).edges("|X and <Z").fillet(r-t).val()
    return outside.cut(inside)


def motor_casting(x,z):
    """Single valid finned enclosure; same nominal Ø120 × 180 envelope.

    Twelve axial cooling ribs are visible construction geometry only. Heat
    rejection, fan airflow, electrical rating and torque remain unselected.
    """
    body=cy(55,-720,-540,x,z)
    ends=[cy(60,-720,-708,x,z),cy(60,-552,-540,x,z)]
    limit=cy(60,-708,-552,x,z)
    rib=box(x-1.75,x+1.75,-708,-552,z+54,z+61)
    fins=[rib.rotate((x,0,z),(x,1,z),30*i).intersect(limit) for i in range(12)]
    pedestal=box(x-23,x+23,-615,-585,z+49,z+60)
    return body.fuse(*ends,*fins,pedestal).clean()


def capsule_slot_z(x,y,z0,z1,length=30,width=11):
    d=(length-width)/2
    return box(x-d,x+d,y-width/2,y+width/2,z0,z1).fuse(
        cz(width/2,z0,z1,x-d,y),cz(width/2,z0,z1,x+d,y))


def rounded_hull_wire(circles, y, offset=0):
    """Exact common-external-tangent hull, clockwise in the x/z plane."""
    tangents=[]
    for i,(x,z,r) in enumerate(circles):
        xx,zz,rr=circles[(i+1)%len(circles)]
        dx,dz=xx-x,zz-z
        distance=math.hypot(dx,dz)
        q=(r-rr)/distance
        s=math.sqrt(1-q*q)
        nx=(dx*q-dz*s)/distance
        nz=(dz*q+dx*s)/distance
        tangents.append((nx,nz))
    edges=[]
    for i,(x,z,r) in enumerate(circles):
        j=(i+1)%len(circles)
        xx,zz,rr=circles[j]
        nx,nz=tangents[i]
        start=cq.Vector(x+(r+offset)*nx,y,z+(r+offset)*nz)
        end=cq.Vector(xx+(rr+offset)*nx,y,zz+(rr+offset)*nz)
        edges.append(cq.Edge.makeLine(start,end))
        nxx,nzz=tangents[j]
        a1=math.atan2(nz,nx)
        a2=math.atan2(nzz,nxx)
        delta=(a1-a2)%(2*math.pi)
        am=a1-delta/2
        mid=cq.Vector(xx+(rr+offset)*math.cos(am),y,zz+(rr+offset)*math.sin(am))
        final=cq.Vector(xx+(rr+offset)*nxx,y,zz+(rr+offset)*nzz)
        edges.append(cq.Edge.makeThreePointArc(end,mid,final))
    return cq.Wire.assembleEdges(edges)


def loop_belt(circles,width,thickness):
    outer=rounded_hull_wire(circles,width/2,thickness)
    inner=rounded_hull_wire(circles,width/2,0)
    return cq.Solid.extrudeLinear(outer,[inner],cq.Vector(0,-width,0))


def roller_shell(x,z,r,width,shaft_r,wall,end_t):
    shell=cy(r,-width/2,width/2,x,z).cut(cy(r-wall,-width/2-1,width/2+1,x,z))
    ends=[]
    for a,b in ((-width/2,-width/2+end_t),(width/2-end_t,width/2)):
        ends.append(cy(r-wall,a,b,x,z).cut(cy(shaft_r,a-1,b+1,x,z)))
    return shell.fuse(*ends).clean()


def bearing(x,y,z,shaft_r,main=True):
    # Concept external pillow-block shape; no bearing rolling elements claimed.
    r=28 if main else 23
    width=55 if main else 50
    foot_x=90 if main else 76
    foot_bottom=z-(36 if main else 36)
    foot_top=z-(24 if main else 20)
    body=cy(r,y-width/2,y+width/2,x,z).fuse(
        box(x-foot_x/2,x+foot_x/2,y-width/2,y+width/2,foot_bottom,foot_top))
    body=body.cut(cy(shaft_r+.25,y-width/2-1,y+width/2+1,x,z))
    for dx in ((-36,36) if main else (-29,29)):
        body=body.cut(cz(5.5,foot_bottom-1,foot_top+1,x+dx,y))
    return body.clean()


def bolt_z(x,y,z0,shank_len=20,r=5,head_r=8.5,head_h=6):
    shank=cz(r,z0,z0+shank_len,x,y)
    head=cz(head_r,z0+shank_len,z0+shank_len+head_h,x,y)
    return shank.fuse(head)


def hex_nut_x(x0,x1,y,z):
    solid=cq.Workplane("YZ",origin=(x0,y,z)).polygon(6,19).extrude(x1-x0).val()
    return solid.cut(cx(5.2,x0-1,x1+1,y,z))


def control_conduit(top):
    """Hollow illustrative conduit outside the sensing field and below return."""
    shift=top-1000
    def v(t): return cq.Vector(t[0],t[1],t[2]+shift)
    s=60/math.sqrt(2)
    a=(850,455,808); b=(850,455,500); c=(850,395,440)
    d=(850,-590,440); e=(850,-650,500); f=(850,-650,930)
    g=(790,-650,990); h=(615,-650,990); i=(555,-650,930); j=(555,-650,875)
    edges=[cq.Edge.makeLine(v(a),v(b)),
           cq.Edge.makeThreePointArc(v(b),v((850,395+s,500-s)),v(c)),
           cq.Edge.makeLine(v(c),v(d)),
           cq.Edge.makeThreePointArc(v(d),v((850,-590-s,500-s)),v(e)),
           cq.Edge.makeLine(v(e),v(f)),
           cq.Edge.makeThreePointArc(v(f),v((790+s,-650,930+s)),v(g)),
           cq.Edge.makeLine(v(g),v(h)),
           cq.Edge.makeThreePointArc(v(h),v((615-s,-650,930+s)),v(i)),
           cq.Edge.makeLine(v(i),v(j))]
    path=cq.Wire.assembleEdges(edges)
    outer=cq.Wire.makeCircle(12,v(a),cq.Vector(0,0,-1))
    inner=cq.Wire.makeCircle(10,v(a),cq.Vector(0,0,-1))
    return cq.Solid.sweep(outer,[inner],path,True,False)


def build(add,p):
    """Populate registry. p may be geometry_mm or the whole parameters object."""
    p=p.get("geometry_mm",p)
    belt=p["belt"]
    width=float(belt["active_width"])
    x0=float(belt["inlet_x"])
    x1=float(belt["discharge_lip_x"])
    top=float(belt["top_z"])
    thickness=6.0
    z=top-56
    return_z=top-430
    left=x0+350
    right=x1-350
    centers=[(x0,z,50),(x1,z,50),(right,return_z,40),(left,return_z,40)]
    evidence="unvalidated_mechanical_concept_selection"

    def put(key,name,category,shape,color=STEEL,**meta):
        add(key,name,category,shape,color=color,evidence_status=evidence,**meta)

    put("belt_loop","6 mm closed belt; four-roller lowered return","belt",
        loop_belt(centers,width,thickness),BELT,
        note="Carrying tangent x=0..3000,z=1000. Wrap extends x=-56..3056. Belt material, tension and thickness need validation.",
        animation={"type":"belt","direction":[1,0,0],"speed_reference_m_s":1.0})

    # Tube frame deliberately has no steel transverse member in x=1300..1900.
    for side,y in (("left",-365),("right",365)):
        if side == "left":
            for name,a,b in (("inlet",x0-110,1310),("outlet",1890,x1+110)):
                put(f"frame_rail_left_{name}",f"Left {name} upper rail with cassette access break","frame",
                    tube_x(a,b,y,top-130,40,60))
            put("frame_rail_left_drop","Lowered left rail bridge beneath cassette withdrawal path","frame",
                tube_x(1310,1890,y,top-270,40,60),
                note="Bridge z700..760 leaves cassette withdrawal x1350..1850,z780..980 clear. Structural sizing is unvalidated.")
            for name,xx in (("inlet",1330),("outlet",1870)):
                put(f"frame_rail_left_drop_link_{name}",f"Left rail bridge {name} drop link","frame",
                    tube_z(top-240,top-100,xx,y,40,4))
        else:
            put(f"frame_rail_{side}",f"{side.title()} 60 × 40 × 4 upper frame rail","frame",
                tube_x(x0-110,x1+110,y,top-130,40,60))
        # Rail pieces butt against leg faces instead of geometrically penetrating them.
        for name,a,b in (("inlet",x0+150,x0+470),("middle",x0+530,x1-530),("outlet",x1-470,x1-150)):
            put(f"return_rail_{side}_{name}",f"{side.title()} {name} return-bearing rail","frame",
                tube_x(a,b,y,top-490,40,40))
        put(f"lower_stretcher_{side}",f"{side.title()} lower frame stretcher","frame",
            tube_x(x0+530,x1-530,y,top-630,40,40))

    for end,x in (("inlet",x0+500),("outlet",x1-500)):
        put(f"frame_cross_{end}",f"{end.title()} transverse frame member","frame",
            tube_y(-335,335,x,top-210,60,60))
        put(f"frame_low_cross_{end}",f"{end.title()} lower transverse stretcher","frame",
            tube_y(-335,335,x,top-630,40,40))
        for side,y in (("left",-365),("right",365)):
            tag=f"{end}_{side}"
            put(f"leg_{tag}",f"{end.title()} {side} 60 × 60 × 4 leg","frame",
                tube_z(100,top-160,x,y))
            cap=rounded_box(x-30,x+30,y-30,y+30,96,100,8)
            put(f"leg_cap_{tag}",f"{tag} lower leg cap","frame",cap)
            foot=rounded_box(x-60,x+60,y-60,y+60,8,20,12)
            for dx in (-45,45):
                for dy in (-45,45):
                    foot=foot.cut(cz(7,7,21,x+dx,y+dy))
            put(f"foot_{tag}",f"{tag} levelling-foot base; anchorage unselected","frame",foot,STAINLESS)
            put(f"foot_pad_{tag}",f"{tag} resilient foot pad envelope","frame",cz(50,0,8,x,y),BELT)
            put(f"level_stud_{tag}",f"{tag} 24 mm levelling-stud envelope","frame",cz(12,20,96,x,y),FASTENER,
                note="Plain cylinder represents adjuster envelope; no thread, adjustment capacity or load rating inferred.")
            lock=cq.Workplane("XY",origin=(x,y,84)).polygon(6,40).extrude(12).val().cut(cz(12.2,83,97,x,y))
            put(f"level_locknut_{tag}",f"{tag} levelling-adjuster locknut envelope","frame",lock,FASTENER,
                note="Hexagonal envelope with 24.4 mm clearance bore only; thread engagement, torque and anchorage loads require engineering.")
            sx=1 if end=="inlet" else -1
            verts=[(x+sx*30,top-160),(x+sx*150,top-160),(x+sx*30,top-280)]
            gusset=cq.Workplane("XZ",origin=(0,y+3,0)).polyline(verts).close().extrude(6).val()
            put(f"gusset_{tag}",f"{tag} upper-frame gusset","frame",gusset)

    # Four rotating shells, separate shafts and independently shaped bearing blocks.
    for key,x,zz,r,main in (("tail",x0,z,50,True),("head",x1,z,50,True),
                            ("return_tail",left,return_z,40,False),("return_head",right,return_z,40,False)):
        shaft_r=15 if main else 12
        shaft_half=425 if main else 400
        animation={"type":"roller","axis":[0,1,0],"pivot_mm":[x,0,zz],"radius_mm":r}
        put(f"roller_{key}",f"{key.replace('_',' ').title()} hollow Ø{2*r} × 630 roller","rollers",
            roller_shell(x,zz,r,630,shaft_r,4 if main else 3,6 if main else 5),STAINLESS,
            animation=animation,note="Concept drum dimensions; balancing, wall strength, bearing life and crown/tracking remain unvalidated.")
        put(f"shaft_{key}",f"{key.replace('_',' ').title()} Ø{2*shaft_r} shaft envelope","rollers",
            cy(shaft_r,-shaft_half,shaft_half,x,zz),FASTENER,animation=animation)
        for side,y in (("left",-365),("right",365)):
            tag=f"{key}_{side}"
            plate_z=zz-44 if main else zz-40
            half_x=95 if key=="tail" else (55 if main else 48)
            plate=rounded_box(x-half_x,x+half_x,y-35,y+35,plate_z,plate_z+(8 if main else 4),8)
            for dx in ((-36,36) if main else (-29,29)):
                cutter=capsule_slot_z(x+dx,y,plate_z-1,plate_z+9,30,11) if key=="tail" else cz(5.5,plate_z-1,plate_z+9,x+dx,y)
                plate=plate.cut(cutter)
            put(f"bearing_plate_{tag}",f"{tag} {'slotted tension' if key=='tail' else 'bearing mounting'} plate","bearings",plate,STAINLESS,
                note="Tail slots 30 × 11 mm; displayed centred adjustment only. Bolt preload and tracking procedure unspecified.")
            bearing_body=bearing(x,y,zz,shaft_r,main)
            if key == "tail":
                bearing_body=bearing_body.cut(cx(5.25,x-36,x-14,y,zz-8))
            put(f"bearing_{tag}",f"{tag} pillow-block bearing envelope","bearings",bearing_body,DRIVE)
            # Fasteners sit in the actual clearance holes, without intersecting shafts.
            for i,dx in enumerate((-36,36) if main else (-29,29)):
                foot_top=zz-(24 if main else 20)
                put(f"bearing_bolt_{tag}_{i+1}",f"{tag} mounting fastener {i+1}; M10 envelope","fasteners",
                    bolt_z(x+dx,y,plate_z,foot_top-plate_z),FASTENER)

    # Paired mechanical tensioning screws and holed anchor plates, at the tail.
    for side,y in (("left",-365),("right",365)):
        anchor=rounded_box(x0-110,x0-100,y-25,y+25,z-44,z+12,6,"X").cut(cx(5.5,x0-111,x0-99,y,z-8))
        put(f"tension_anchor_{side}",f"{side.title()} tail tensioner anchor","tensioning",anchor,STAINLESS)
        put(f"tension_screw_{side}",f"{side.title()} tension-screw envelope","tensioning",cx(5,x0-120,x0-20,y,z-8),FASTENER,
            note="Study adjuster only; thread form, belt tension and adjustment limits need design.")
        put(f"tension_nut_{side}",f"{side.title()} tension-adjuster nut","tensioning",hex_nut_x(x0-119,x0-111,y,z-8),FASTENER)
        put(f"tension_locknut_{side}",f"{side.title()} tail-adjuster jam nut concept","tensioning",
            hex_nut_x(x0-99,x0-91,y,z-8),FASTENER,
            note="Geometric jam-nut envelope only; thread, torque, retention and adjustment procedure are not specified.")
        # Etched scale is real shallow-cut geometry on a removable indicator strip.
        # It reads position only; these divisions are not belt-tension calibration.
        sy0,sy1=(y-35,y-29) if side=="left" else (y+29,y+35)
        scale=rounded_box(x0-55,x0+55,sy0,sy1,z-36,z-35,2)
        for k in range(-4,5):
            end=sy1 if side=="left" else sy0+(4 if k%2==0 else 2.5)
            start=sy1-(4 if k%2==0 else 2.5) if side=="left" else sy0
            scale=scale.cut(box(x0+k*10-.4,x0+k*10+.4,start,end,z-35.25,z-34))
        put(f"tension_position_scale_{side}",f"{side.title()} adjustment-position witness strip","tensioning",scale,FASTENER,
            note="Uncalibrated 10 mm geometric divisions; not a force/tension scale. Final measurement datum and usable travel need design.")

    # Slider deck is nonconductive in this concept. Root supplies central window.
    for key,a,b in (("upstream",x0+80,1350),("downstream",1850,x1-80)):
        put(f"slider_{key}",f"{key.title()} polymer slider-deck concept","deck",
            box(a,b,-width/2,width/2,top-14,top-6),POLYMER,
            note="8 mm illustrative support plate; wear, deflection, friction and belt material have not been engineered.")
    for key,x in (("upstream",x0+600),("downstream",x1-600)):
        put(f"slider_cross_{key}",f"{key.title()} slider support crossmember","deck",
            tube_y(-330,330,x,top-32,40,36),STAINLESS,
            note="Steel support outside x=1300..1900 sensor exclusion bay.")
        for side,y in (("left",-330),("right",330)):
            if y<0:
                foot=box(x-50,x+50,-385,-315,top-100,top-92)
                web=box(x-50,x+50,-334,-326,top-92,top-14)
            else:
                foot=box(x-50,x+50,315,385,top-100,top-92)
                web=box(x-50,x+50,326,334,top-92,top-14)
            # Crossmember terminates at y±330; subtract its own occupied space.
            bracket=foot.fuse(web).cut(box(x-20,x+20,-330,330,top-50,top-14))
            put(f"slider_bracket_{key}_{side}",f"{key} {side} slider-deck bracket","deck",bracket,STAINLESS)

    # Generic gearmotor envelope; no vendor motor or power selection is implied.
    gearbox=rounded_box(x1-75,x1+75,-510,-425,z-65,z+65,14,"Y").cut(cy(15.5,-511,-424,x1,z))
    put("drive_gearbox","Generic shaft-mounted gearbox envelope","drive",gearbox,DRIVE,
        note="150 × 85 × 130 envelope only; ratio, efficiency, torque, power and mass are not selected.")
    put("drive_motor","Generic finned motor envelope, no selected power rating","drive",motor_casting(x1,z),DRIVE,
        note="Twelve axial enclosure ribs within original diameter120 envelope; heat rejection, power, efficiency and fan arrangement remain unvalidated.")
    put("drive_motor_adapter","Motor/gearbox adapter envelope","drive",cy(48,-540,-510,x1,z),STAINLESS)
    put("drive_terminal_box","Radiused motor terminal-box envelope","drive",rounded_box(x1-35,x1+35,-630,-570,z+60,z+95,6),DRIVE)
    fan_cover=cy(58,-728,-720,x1,z).cut(cy(54,-726,-719,x1,z))
    for xx in (-30,-15,0,15,30):
        fan_cover=fan_cover.cut(rounded_box(x1+xx-3,x1+xx+3,-729,-725,z-28,z+28,2.5,"Y"))
    put("drive_fan_cover","Slotted rear motor-end cover concept","drive",fan_cover,STEEL,
        note="Visible 8 mm deep cover with five geometric ventilation slots; no airflow, finger-access protection or ingress rating implied.")
    gear_cover=rounded_box(x1-61,x1+61,-425,-421,z-52,z+52,12,"Y").cut(cy(24,-426,-420,x1,z))
    put("drive_gear_cover","Rounded gearbox output-side service cover","drive",gear_cover,STAINLESS,
        note="Concept removable cover; sealing, fastening, lubricant containment and service procedure unresolved.")
    # Output-coupling representation stays outside the support bearing.
    coupling=cy(23,-425,-397,x1,z).cut(cy(15.5,-426,-396,x1,z))
    put("drive_coupling","Drive output coupling envelope","drive",coupling,STAINLESS)
    base=rounded_box(x1-120,x1+120,-760,-345,top-176,top-160,12)
    webs=box(x1-90,x1-82,-720,-395,top-160,z-77).fuse(box(x1+82,x1+90,-720,-395,top-160,z-77))
    plate=rounded_box(x1-120,x1+120,-760,-395,z-77,z-69,10)
    put("drive_bracket","Gearmotor support bracket concept","drive",base.fuse(webs,plate),STEEL,
        note="Bracket is an envelope; fastener pattern, overhung moment and structural sizing unresolved.")
    put("drive_mount_spacer","Gearbox mounting spacer concept","drive",box(x1-60,x1+60,-500,-435,z-69,z-65),STAINLESS)

    # Encoder is a labelled device envelope; feedback adequacy is a future test.
    encoder=cy(26,430,475,x1,z)
    put("encoder_body","Head-shaft encoder device envelope","encoder",encoder,"#DE9D58",
        note="No vendor model, pulse count, resolution, fault coverage or belt-slip measurement claim.")
    put("encoder_coupling","Encoder flexible-coupling envelope","encoder",
        cy(20,403,430,x1,z).cut(cy(15.5,402,431,x1,z)),STAINLESS)
    encoder_plate=box(x1-45,x1+45,475,481,z-54,z+36)
    encoder_foot=box(x1-45,x1+45,385,481,top-106,top-100)
    put("encoder_bracket","Encoder support bracket","encoder",encoder_plate.fuse(encoder_foot),STAINLESS)

    # Return guard and removable transparent access panels are concept coverage,
    # not a completed machine safeguarding design or an interlocked guard system.
    trough=channel_x(x0+200,x1-200,-330,330,top-503,top-482)
    put("return_guard","Removable under-return-belt trough guard concept","guards",trough,GUARD,
        removable=True,note="Minimum 24 mm belt-to-floor clearance at the horizontal lower return; no certified access protection claimed.")
    for side,yy in (("left",-408),("right",405)):
        panel=rounded_box(1250,1950,yy,yy+3,top-385,top-180,12,"Y")
        if side == "left":
            # Fixed polymer drawer rails pass through these clearance apertures.
            # The panel still requires removal before cassette withdrawal.
            for rail_x in (1395,1805):
                panel=panel.cut(box(rail_x-16,rail_x+16,yy-1,yy+4,top-242,top-218))
        for xx in (1265,1935):
            for zz in (top-370,top-195):
                panel=panel.cut(cy(4,yy-1,yy+4,xx,zz))
        put(f"access_panel_{side}",f"{side.title()} removable clear access-panel concept","guards",panel,GUARD,
            opacity=.28,removable=True,
            note="3 mm transparent-sheet envelope; impact resistance, retention, access reach and interlocking are unresolved.")
        # Top hangers anchor panels outside the sensing envelope and belt edges.
        for i,xx in enumerate((1270,1930)):
            ystart,yend=(-405,-385) if side=="left" else (385,405)
            tab=box(xx-20,xx+20,ystart,yend,top-190,top-184)
            web_y0,web_y1=(-389,-385) if side=="left" else (385,389)
            tab=tab.fuse(box(xx-20,xx+20,web_y0,web_y1,top-184,top-130))
            put(f"access_hanger_{side}_{i+1}",f"{side} access-panel hanger {i+1}","guards",tab,STAINLESS)

    # Thin curved tail-wrap cheeks sit beyond the drum ends, avoiding the belt,
    # shaft and bearing-mount volumes. These are not a complete nip-point guard.
    for side,ya,yb in (("left",-326,-320),("right",320,326)):
        cheek=cy(75,ya,yb,x0,z).cut(cy(66,ya-1,yb+1,x0,z))
        cheek=cheek.intersect(box(x0-76,x0,ya-1,yb+1,z-76,z+76))
        tab_y0,tab_y1=(-345,-320) if side=="left" else (320,345)
        tab=box(x0-60,x0-45,tab_y0,tab_y1,z-56,z-52)
        put(f"tail_wrap_cheek_{side}",f"{side.title()} curved tail-wrap side cheek concept","guards",cheek.fuse(tab).clean(),GUARD,
            removable=True,note="R66..75 partial cheek outside drum ends, y±320..326; geometric mounting tab only. Nip access, reach distances, attachment and removal controls need safeguarding design.")

    # Outer cable trunk is segregated from the belt and the replaceable cassette.
    trunk=channel_x(x0+150,x1-150,425,485,top-195,top-135)
    trunk=trunk.cut(cz(12.5,top-196,top-191,850,455))
    put("cable_trunk","Outer-side protected cable trunk","cables",trunk,STEEL,
        note="60 × 60 mm reserved route; actual cable fill, bend radii, separation, bonding and ingress protection unspecified.")
    put("cable_trunk_lid","Radiused removable cable-trunk lid","cables",rounded_box(x0+150,x1-150,423,487,top-135,top-132,10),STAINLESS,removable=True)
    for i,x in enumerate((x0+400,x0+1100,x1-900,x1-400)):
        bracket=box(x-25,x+25,385,425,top-195,top-191).fuse(
            box(x-25,x+25,385,389,top-191,top-135))
        put(f"cable_bracket_{i+1}",f"Cable-trunk bracket {i+1}","cables",bracket,STAINLESS)
        # Strap ends attach outside the reserved cable cavity. Retention concept,
        # not a chosen product or an ingress/strain-relief qualification.
        clip=rounded_box(x-8,x+8,421,489,top-150,top-129,4,"X").cut(
            rounded_box(x-9,x+9,423,487,top-151,top-130,2,"X"))
        put(f"cable_lid_clip_{i+1}",f"Cable-trunk lid retaining strap {i+1}","cables",clip,DRIVE,
            removable=True,note="2 mm side-wall, 1 mm crown concept clip; latch action, retention force, bonding and cable protection remain unspecified.")
    put("control_cable_conduit","Protected control-cable route to external cabinet; envelope","cables",
        control_conduit(top),BELT,
        note="Hollow Ø24/20 route with illustrative 60 mm centreline bends. Crosses below return at x850,z440, outside sensing bay; conduit type, supports, grounding, fill and bend radii not selected.")


if __name__ == "__main__":
    import json
    from pathlib import Path
    p=Path(__file__).resolve().parents[1]/"design_basis"/"parameters.json"
    rows=[]
    def inspect(key,name,category,shape,**meta):
        shape=shape.val() if isinstance(shape,cq.Workplane) else shape
        bb=shape.BoundingBox()
        rows.append({"id":key,"valid":shape.isValid(),"solids":len(shape.Solids()),
                     "volume_mm3":shape.Volume(),"bbox_mm":[bb.xmin,bb.xmax,bb.ymin,bb.ymax,bb.zmin,bb.zmax]})
    build(inspect,json.loads(p.read_text()))
    print(json.dumps({"component_count":len(rows),"all_valid":all(r["valid"] for r in rows),
                      "all_positive_volume":all(r["volume_mm3"]>0 for r in rows),"components":rows},indent=2))
