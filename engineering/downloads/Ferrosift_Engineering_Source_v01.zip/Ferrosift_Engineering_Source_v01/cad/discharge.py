"""Editable solid geometry for a concept pneumatic split and group-review gate.

All dimensions are study selections. This does not compute pneumatic impulse,
safe guard openings, chute flow, actuator timing or containment requirements.
"""
import math
import cadquery as cq

STEEL = '#8b9da4'
BLUE = '#43677a'
ORANGE = '#e49c48'


def box(x, y, z, dx, dy, dz):
    return cq.Workplane('XY').box(dx, dy, dz).translate((x, y, z)).val()


def rounded_box(x, y, z, dx, dy, dz, radius, axis='Z'):
    return cq.Workplane('XY').box(dx,dy,dz).edges('|'+axis).fillet(radius).translate((x,y,z)).val()


def rod_between(a,b,radius,bore=0):
    delta=cq.Vector(*b).sub(cq.Vector(*a))
    shape=cylinder(radius,delta.Length,a,delta.normalized().toTuple())
    if bore:shape=shape.cut(cylinder(bore,delta.Length,a,delta.normalized().toTuple()))
    return shape


def panel(points, thickness=3, normal=(0, 0, 1)):
    wire = cq.Wire.makePolygon([cq.Vector(*v) for v in points], close=True)
    return cq.Solid.extrudeLinear(wire, [], cq.Vector(*normal).normalized().multiply(thickness))


def cylinder(radius, length, origin, axis):
    return cq.Solid.makeCylinder(radius, length, cq.Vector(*origin), cq.Vector(*axis))


def trough(add, ident, start, end, width, wall=100, color=STEEL):
    dx, dy = end[0]-start[0], end[1]-start[1]
    length = math.hypot(dx, dy)
    nx, ny = -dy/length*width/2, dx/length*width/2
    a = (start[0]+nx, start[1]+ny, start[2])
    b = (start[0]-nx, start[1]-ny, start[2])
    c = (end[0]-nx, end[1]-ny, end[2])
    d = (end[0]+nx, end[1]+ny, end[2])
    add(ident+'_floor', ident.replace('_',' ')+' floor', 'chute', panel([a,b,c,d]), color,
        notes='Provisional slope; friction, bounce, bridging and trajectories require tests.')
    for side, pts in [('L',[a,d,(d[0],d[1],d[2]+wall),(a[0],a[1],a[2]+wall)]),
                      ('R',[b,c,(c[0],c[1],c[2]+wall),(b[0],b[1],b[2]+wall)])]:
        add(ident+'_side_'+side, ident+' side cheek '+side, 'chute', panel(pts,3,(nx,ny,0)), color)
        add(ident+'_rolled_edge_'+side, ident+' rounded cheek edge '+side, 'chute',
            rod_between(pts[3],pts[2],6,3),color,
            notes='Rounded edge study; attachment, wear and actual formed-sheet bend allowances unselected.')
    # Rounded nose lies below the floor termination, keeping the flow opening
    # above the original floor. It does not assert successful fragment flow.
    add(ident+'_nose',ident+' rounded discharge nose','chute',
        rod_between((c[0],c[1],c[2]-4),(d[0],d[1],d[2]-4),5),color,
        notes='Preliminary lip detail; fragment bounce and hang-up require trials.')


def routing_trough(add, ident, corners, wall=100, color=STEEL, nose_setback=0):
    """Four physical edge points, ordered upstream +Y/-Y, downstream -Y/+Y.

    Two triangular plates allow branch crossfall to flatten toward a bin without
    pretending that a non-planar quadrilateral is a flat sheet. Thickness is
    3 mm vertically; fabrication development remains a design hold.
    """
    a,b,c,d=corners
    floor=panel([a,b,c]).fuse(panel([a,c,d])).clean()
    add(ident+'_floor',ident.replace('_',' ')+' tapered floor','chute',floor,color,
        routing_edges_mm=corners,
        notes='Full geometric intake coverage only; friction, bridging, rebound and all accepted feed dimensions require physical tests.')
    for side,p0,p1,sign in [('L',a,d,1),('R',b,c,-1)]:
        pts=[p0,p1,(p1[0],p1[1],p1[2]+wall),(p0[0],p0[1],p0[2]+wall)]
        add(ident+'_side_'+side,ident+' enclosing cheek '+side,'chute',panel(pts,3,(0,sign,0)),color)
        add(ident+'_rolled_edge_'+side,ident+' rounded cheek edge '+side,'chute',
            rod_between(pts[3],pts[2],6,3),color,
            notes='Preliminary formed-edge provision; connections, wear and manufacturability unvalidated.')
    add(ident+'_nose',ident+' discharge nose','chute',
        rod_between((c[0]-nose_setback,c[1],c[2]-4),(d[0]-nose_setback,d[1],d[2]-4),5),color,
        notes='Preliminary rounded lip; drop and rebound into bin require tests.')


def build(add, p):
    lip = p['geometry_mm']['belt']['discharge_lip_x']
    deck = p['geometry_mm']['belt']['top_z']
    ox, oz = lip-3000, deck-1000
    def shift_shape(shape):
        return shape.translate((ox,0,oz))
    upstream_add = add
    def add(ident, name, category, shape, color=STEEL, **meta):
        meta.setdefault('status','unvalidated_concept_selection')
        if 'animation' in meta:
            pivot=meta['animation'].get('pivot')
            if pivot:
                meta['animation']['pivot']=[pivot[0]+ox,pivot[1],pivot[2]+oz]
        upstream_add(ident,name,category,shift_shape(shape),color,**meta)

    # Hollow manifold and individual nozzle envelopes. Pitch is a drawing
    # selection only and must not be used as a claimed separation resolution.
    outer=cylinder(24,640,(3090,-320,910),(0,1,0))
    inner=cylinder(19,642,(3090,-321,910),(0,1,0))
    add('air_manifold','Pneumatic manifold, hollow envelope','airjet',outer.cut(inner),BLUE,
        notes='No pressure or valve response specified. 50 mm nozzle spacing is a geometric placeholder.')
    for n,y in enumerate(range(-275,276,50)):
        axis=cq.Vector(.28,0,.96).normalized()
        nozzle=cylinder(7,45,(3090,y,930),axis.toTuple()).cut(cylinder(3.5,46,(3090,y,929.5),axis.toTuple()))
        add(f'nozzle_{n:02d}',f'Nozzle envelope {n+1}','airjet',nozzle,ORANGE,
            vendor_model=None,orifice_status='3.5 mm drawn radius is an unsized study bore; no flow or impulse claim')
        collar=cylinder(11,9,(3090,y,930),axis.toTuple()).cut(cylinder(7.2,11,(3089.72,y,929.04),axis.toTuple()))
        add(f'nozzle_union_{n:02d}',f'Nozzle compression-union envelope {n+1}','airjet',collar,STEEL,
            thread_pressure_rating='unselected',service='individual nozzle removal provision only')
    for y in (-340,340):
        bracket=rounded_box(3130,y,875,100,8,130,12,'Y')
        for xx in (3100,3160):
            bracket=bracket.cut(rounded_box(xx,y,875,9,12,70,4,'Y'))
        add(f'air_bracket_{y}','Slotted adjustable airbar mounting plate','airjet',bracket,STEEL,
            notes='Two 70 mm concept adjustment slots; fastener, locking and rigidity unvalidated.')
    bank=rounded_box(3300,640,780,290,130,130,14).cut(rounded_box(3300,640,790,278,118,122,9))
    add('valve_pack','Open service enclosure for unselected valve bank','airjet',bank,BLUE,
        notes='Generic envelope only; no selected manufacturer, switching time or proven channel independence.')
    add('air_valve_carrier','Removable valve carrier plate','airjet',rounded_box(3300,640,838,286,120,6,6),STEEL,
        notes='Study carrier plate; bolt pattern and selected valve manifold connection unresolved.')
    for n in range(12):
        xx=3179+n*22
        add(f'air_valve_{n:02d}',f'Unselected pneumatic valve envelope {n+1}','airjet',
            rounded_box(xx,638,855,17,80,28,3),STEEL,
            selected=False,manufacturer_model=None,notes='Illustrative one-valve-per-nozzle concept; circuit, tubing and response unresolved.')
        add(f'air_valve_coil_{n:02d}',f'Valve electrical connector envelope {n+1}','airjet',
            rounded_box(xx,668,877,15,22,24,3),BLUE,
            voltage=None,control_interface=None,thermal_duty=None)
    for xx in (3170,3430):
        add(f'air_bank_mount_{xx}','Valve-enclosure support bracket','airjet',
            rounded_box(xx,590,711,38,190,8,6),STEEL,
            notes='Study bracket; attachment and load review required.')
        # Far-side provisions cannot obstruct the negative-y cassette corridor
        # or any of the three bins during their positive-x withdrawal.
        add(f'air_bank_post_{xx}','External valve-bank pedestal','airjet',
            rounded_box(xx,640,354,30,30,708,4),BLUE,load_rating=None,anchorage='unvalidated')
    add('air_isolation','Pneumatic isolation / dump valve envelope','airjet',box(3480,640,780,70,75,100),ORANGE,
        notes='Requires selected valve and validated isolation / stored-energy procedure.')
    add('pressure_sensor','Pressure transducer envelope','airjet',cylinder(15,55,(3500,640,830),(0,0,1)),BLUE,
        notes='Unselected device; range, response, wiring and calibration unresolved.')
    pipe_outer=cylinder(12,320,(3090,320,915),(0,1,0)).fuse(cylinder(12,370,(3090,640,915),(1,0,0)),cylinder(12,85,(3460,640,830),(0,0,1)))
    pipe_inner=cylinder(9,322,(3090,319,915),(0,1,0)).fuse(cylinder(9,372,(3089,640,915),(1,0,0)),cylinder(9,87,(3460,640,829),(0,0,1)))
    add('air_supply_route','Protected pneumatic supply route envelope','airjet',pipe_outer.cut(pipe_inner),BLUE,
        notes='Routing envelope only; connectors, bends, pressure rating and flow sizing unselected.')
    for yy in (-326,320):
        cap=cylinder(28,6,(3090,yy,910),(0,1,0))
        add(f'air_manifold_end_{yy}','Manifold end-closure envelope','airjet',cap,STEEL,
            notes='Seal, fasteners, pressure and proof test unselected.')
    for xx,yy,zz,ax in [(3090,590,915,(0,1,0)),(3205,640,915,(1,0,0)),(3460,640,840,(0,0,1))]:
        union=cylinder(17,20,(xx,yy,zz),ax).cut(cylinder(12.2,20,(xx,yy,zz),ax))
        add(f'air_route_union_{xx}_{yy}','Pneumatic route union envelope','airjet',union,STEEL,
            notes='Interface envelope only, no selected fitting or pressure rating.')

    # Natural-path catch precedes the group gate. Concentrate passes above
    # this region into the farther central chute after a tested jet impulse.
    routing_trough(add,'balance_catch',[(3140,330,780),(3140,-330,780),
                    (3305,-68,700),(3305,68,700)],100,nose_setback=6)
    # Keep the concentrate stream above the branch cheeks wherever their XY
    # footprints overlap. A 600 mm outlet elevation leaves a deliberate drop
    # into the central bin rather than crossing a branch wall at z~600.
    routing_trough(add,'concentrate_chute',[(3610,330,820),(3610,-330,820),
                    (4000,-130,600),(4000,130,600)],105,ORANGE)
    routing_trough(add,'balance_branch',[(3560,110,628.5),(3560,12,594.2),
                    (4000,210,490),(4000,470,490)],90,BLUE)
    routing_trough(add,'review_branch',[(3560,-12,594.2),(3560,-110,628.5),
                    (4000,-470,490),(4000,-210,490)],90,'#aa8259')

    # A radially sloped floor permits a vertical-axis blade to retain its
    # nominal underside contact throughout rotation. The cone decreases toward
    # the downstream shaft; the two branch floors continue downhill from its
    # outlet edges. This is a conceptual formed floor, not fabrication detail.
    px,theta,half_width=3560,0.45,110
    cone_below=cq.Solid.makeCone(0,1000,350,cq.Vector(px,0,590),cq.Vector(0,0,1))
    cone_above=cq.Solid.makeCone(0,1000,350,cq.Vector(px,0,593),cq.Vector(0,0,1))
    chamber_envelope=box(3432.5,0,750,255,220,400)
    floor=cone_below.cut(cone_above).intersect(chamber_envelope)
    add('review_gate_floor','Conical inward-sloping group routing floor','gate',floor,STEEL,
        top_surface='z = 593 + 0.35 * hypot(x - 3560, y), in native mm coordinates',
        notes='3 mm vertical shell; nominal blade contact only. Wear, tolerances, friction, formed-floor manufacture and cleanability remain DESIGN HOLD.')
    # Symmetric tip bevels make nominal planar contact at both end stops, with
    # no artificially inflated obstacle or concealed seal clearance.
    reach=half_width/math.sin(theta)
    corner=(half_width-2*math.cos(theta))/math.sin(theta)
    blade_plan=[(px-reach,0,590),(px-corner,-2,590),(px+1,-2,590),
                (px+1,2,590),(px-corner,2,590)]
    blade=panel(blade_plan,230).intersect(cone_above)
    add('review_gate_plate','Upstream-pointing group routing swing blade','gate',blade,ORANGE,
        animation={'type':'review-gate','axis':'z','pivot':[px,0,740],
                   'angle':-theta,'balanceAngle':theta,'bladeDirection':'upstream-negative-x'},
        nominal_reach_mm=reach,nominal_tip_and_floor_clearance_mm=0,
        notes='Drawn centre position is prohibited transition. Nominal zero-gap surfaces are a closure study, not validated physical seals; specify tolerances, compliant seals, feed height/shape/thickness, wear and jam clearance before operation. Inhibit feed, clear, position and verify before resuming.')
    add('review_gate_shaft','Vertical gate shaft','gate',cylinder(12,370,(px,0,510),(0,0,1)),STEEL,
        notes='Blade/shaft overlap is a conceptual joined interface. Bearings are outside the material passage.')
    for side,sy in [('L',1),('R',-1)]:
        wall_shape=box(3432.5,sy*111.5,705,255,3,230).intersect(cone_below)
        add('gate_chamber_side_'+side,'Gate chamber continuous side wall '+side,'gate',wall_shape,STEEL,
            notes='Nominal blade stop contact at y=+/-110; actual end stop and seals unselected.')
        shoulder=box(3303.5,sy*89,760,3,42,120)
        add('gate_inlet_shoulder_'+side,'Gate inlet throat shoulder '+side,'gate',shoulder,STEEL)
    rear=box(3303.5,0,645,3,220,110).intersect(cone_below)
    add('gate_inlet_step','Enclosed step below 136 mm inlet throat','gate',rear,STEEL,
        notes='Catch outlet floor top703; chamber floor under throat is682.25..685.37. Controlled downward transfer, rebound unvalidated.')
    # Root separator continues from the shaft tangent into the diverging inner
    # branch walls. The branch cheek solids themselves bound both routes.
    splitter=panel([(3560,-12,590),(3560,12,590),(3587,24.15,590),(3587,-24.15,590)],230).cut(cylinder(12,240,(px,0,585),(0,0,1)))
    # Keep its lower part above the two branch surface planes by retaining the
    # central protected wedge; it joins the shaft and inner cheeks at the root.
    add('gate_branch_splitter','Stationary bifurcation root splitter','gate',splitter,STEEL,
        notes='Closed root provision adjoining both branch inner cheeks; nominal joint, attachment and abrasion detail unselected.')
    for zz in (550,856):
        bearing=box(px,0,zz,65,55,20).cut(cylinder(12.25,22,(px,0,zz-11),(0,0,1)))
        add(f'gate_bearing_{zz}','Gate shaft bearing envelope','gate',bearing,BLUE)
    add('gate_actuator','Below-floor rotary actuator envelope','gate',box(px,0,490,90,95,40),BLUE,
        notes='No selected actuator, torque, default spring or cycle time established.')
    mount=box(px,0,514,110,260,8).cut(cylinder(13,10,(px,0,509),(0,0,1)))
    for yy in (-40,40):
        for xx in (-35,35):
            mount=mount.cut(cylinder(4.5,10,(px+xx,yy,509),(0,0,1)))
    add('gate_actuator_mount','Below-floor actuator mounting plate envelope','gate',mount,BLUE,
        notes='Provisional mount only; load, fasteners, tool access, dust protection and isolation require engineering review.')
    for sign in (-1,1):
        add(f'gate_actuator_hanger_{sign}','External actuator support hanger','gate',
            box(px-35,sign*118.5,582,20,15,136),BLUE,
            notes='External to material chamber; conceptual joined bracket, attachment and load rating unvalidated.')
    for y in (-80,80):
        add(f'gate_feedback_{y}','Gate end-position switch envelope','gate',box(px+20,y,848,40,25,30),'#dcbb55')

    # Open-top removable bins. Colour denotes intended routing, not contents.
    for ident,cy,color in [('review',-340,'#aa8259'),('concentrate',0,ORANGE),('balance',340,BLUE)]:
        outer=rounded_box(4000,cy,280,380,300,400,16)
        inner=rounded_box(4000,cy,284,372,292,400,12)
        shell=outer.cut(inner)
        add('bin_'+ident,ident.title()+' collection bin','bin',shell,color,
            notes='Ordinary collection bin; not hazardous-material or battery-fire containment.')
        for sx in (-145,145):
            for sy in (-110,110):
                add(f'bin_{ident}_foot_{sx}_{sy}',ident+' bin foot','bin',box(4000+sx,cy+sy,40,35,35,80),STEEL)
        rim=rounded_box(4000,cy,476,388,308,8,20).cut(rounded_box(4000,cy,476,368,288,10,10))
        add(f'bin_{ident}_rim',ident+' bin reinforced rounded rim','bin',rim,color,
            notes='Study rim; handling load and sharp-edge review unvalidated.')
        for sx in (-1,1):
            xg=4000+sx*210;xb=4000+sx*190
            handle=rod_between((xg,cy-45,405),(xg,cy+45,405),6)
            handle=handle.fuse(rod_between((xb,cy-45,405),(xg,cy-45,405),6),rod_between((xb,cy+45,405),(xg,cy+45,405),6))
            add(f'bin_{ident}_handle_{sx}',ident+' bin pull handle','bin',handle,STEEL,
                handling_rating='unvalidated; not a lifting point')

    # Ejection enclosure frame with removable roof and side access screens.
    for x in (3170,4180):
        for y in (-525,525):
            add(f'discharge_post_{x}_{y}','Ejection enclosure upright','guard',box(x,y,606,35,35,1188),BLUE)
            add(f'discharge_foot_{x}_{y}','Ejection enclosure foot','guard',box(x,y,6,100,80,12),STEEL)
    for y in (-525,525):
        add(f'discharge_toprail_{y}','Ejection enclosure top rail','guard',box(3675,y,1190,1045,35,35),BLUE)
        side=rounded_box(3675,y,920,975,3,450,24,'Y')
        # Two large inspectable apertures retain borders; no claim that their
        # openings are safe. In practice guards require risk assessment.
        for x in (3415,3910):
            side=side.cut(rounded_box(x,y,920,410,9,355,20,'Y'))
        add(f'discharge_access_frame_{y}','Removable discharge access frame','guard',side,STEEL,
            notes='Window insert and fastening detail require containment/risk review.')
        for x in (3415,3910):
            add(f'discharge_window_{x}_{y}','Discharge observation window envelope','guard',rounded_box(x,y,920,410,2,355,20,'Y'),'#577885',
                opacity=.18,removable=True)
        for xx in (3215,4135):
            add(f'discharge_panel_latch_{xx}_{y}','Removable panel captive latch envelope','guard',
                cylinder(12,10,(xx,y-5,1090),(0,1,0)),BLUE,
                notes='Unselected retention hardware; no interlock or guarding claim.')
    roof=rounded_box(3675,0,1220,1075,1080,3,30).cut(cylinder(51,8,(4040,0,1216),(0,0,1)))
    add('discharge_roof','Removable discharge cover','guard',roof,BLUE,
        removable=True,default_hidden=True)
    port=cylinder(55,100,(4040,0,1220),(0,0,1)).cut(cylinder(51,102,(4040,0,1219),(0,0,1)))
    add('discharge_dust_port','Unspecified extraction interface','guard',port,STEEL,
        notes='Interface reservation only; airflow, dust/fire design and trajectory interference unvalidated.')


ROUTES={
 'target':[[3000,0,1014],[3090,0,995],[3190,0,1060],[3440,0,1020],[3650,0,850],[3900,0,680],[4000,0,635],[4040,0,540],[4040,0,280]],
 'balance':[[3000,0,1014],[3100,0,950],[3220,0,790],[3308,0,730],[3445,50,670],[3560,65,640],[3780,205,575],[4000,340,525],[4040,340,470],[4040,340,280]],
 'review':[[3000,0,1014],[3100,0,950],[3220,0,790],[3308,0,730],[3445,-50,670],[3560,-65,640],[3780,-205,575],[4000,-340,525],[4040,-340,470],[4040,-340,280]],
}
