# Ferrosift investor engineering candidate — 14 October 2026, v01

This is a new versioned, editable industrial conveyor concept derived from the preserved 13 October release. It is an unvalidated prototype design, not a manufactured or certified machine and not a fabrication release. The verified public `af611cd` website and the older CAD/PDF/ZIP files remain separate, unchanged records.

## Sources and deliverables

- `cad/build_conveyor.py` integrates `mechanical_base.py`, `sensor_feed.py` and `discharge.py`; the Python sources and `design_basis/parameters.json` are the editable design.
- `exports/conveyor_assembly.step` and `.brep` contain named solid components in millimetres; `.glb` is a viewing mesh in metres, Y up. Category STEP files and a sensor-cell subset support the drawings.
- `exports/assembly_manifest.json` identifies every component, its category, chosen geometry, bounding box, solid volume and stated assumptions. A geometric solid volume is not a measured machine mass.
- `web/conveyor-assembly.json` is tessellated from those same solids, with surface-derived normals and indexed vertices for the website. It is not separate artist-created mockup geometry.
- `drawings/` holds the dimensioned drawing package and its editable sources; `bom/` holds the preliminary component schedule. Dimensions and tolerance targets require engineering review before procurement or fabrication.
- `verification/` holds checks run for this candidate. A copied script is not evidence until it is executed against these sources. Existing release hashes and counts must not be reused as current validation.

## Frozen coordination basis

The belt is provisionally 600 mm wide with a carrying tangent from x=0 to x=3000 mm and a top surface at z=1000 mm. X is travel, Y is across the belt and Z is up. RGB centre x=1300; induction enclosure centre x=1600; final active sensing datum x=1750; enclosure end x=1775; discharge lip x=3000. Ideal sensor-to-lip travel is therefore 1250 mm. These retained datums support cross-artifact coordination; they are not validated machine requirements.

The cassette remains an unpopulated enclosure. Its top is z=980; the nonmetallic support-window underside is z=988. The 8 mm enclosure-to-window gap is **not** coil-to-material standoff. Coil position, operating frequencies, field coverage and sensor response are unselected. No steel slider plate spans the active window. Optical mounts and service interfaces show adjustable provisions; no purchased camera, lens, depth device, encoder or valve specification is implied. Optional depth geometry is uninstalled and hidden by default.

Screening into 12.5–25 mm and 25–50 mm campaigns does not establish maximum piece height, length or mass. The feed must be depolluted, liberated, dry and cleared of batteries/hazardous components. Thickness, mass, belt loading and permitted shapes require measured feed acceptance limits.

## Sorting and service assumptions

Induction measures material response; air jets perform the primary target/balance split. A real second mechanical route is represented by the balance-stream review gate, with concentrate, balance and review collection bins. The review gate acts on conservative groups/windows. Feed inhibit, a measured clearing interval and position feedback must precede a transition. It cannot retrieve an item already ejected to concentrate.

Nozzle pitch, valve fittings, motor form, cooling ribs, bearings, sheet thicknesses, formed radii and fasteners are geometric design selections. No supplier variant, pressure, impulse, response time, motor power, load rating or purchased bill of materials is selected. Catalog valve response would not establish total acquisition-to-ejection delay.

The cassette core is intended to withdraw toward negative Y after access panels and retention hardware are released, connectors are disconnected and external support is provided. Bins withdraw forward. Source-solid clearance checks cover only their documented geometric scopes; they do not certify operator access, safe handling, isolation, guarding or regulatory compliance. Window stiffness/wear, loads, tension, tracking, airflow/dust/fire risks, electromagnetic interference, full wiring and control safety remain unresolved.

## Rebuild locally

The pinned environment is recorded in `requirements.lock.txt`. This candidate uses the existing local CadQuery 2.8 environment; it needs no cloud CAD, paid compute or model training. From this directory, set `CAD_PYTHON` to an installed compatible Python interpreter, for example the preserved local `.venv-cad/bin/python`:

```sh
export PYTHONDONTWRITEBYTECODE=1
export XDG_CACHE_HOME=/tmp/ferrosift-investor-cad-cache
"$CAD_PYTHON" cad/build_conveyor.py
"$CAD_PYTHON" cad/build_conveyor.py --validate-only --belt-width 620 > verification/parameter_variant_620.json
"$CAD_PYTHON" design_basis/calculate.py --check
"$CAD_PYTHON" -m unittest discover -s design_basis -p 'test_*.py'
"$CAD_PYTHON" verification/run_interface_review.py
"$CAD_PYTHON" verification/run_discharge_independent_review.py
"$CAD_PYTHON" verification/full_width_routing_review.py
"$CAD_PYTHON" verification/verify_geometry_exports.py
```

The 620 mm width variant is an editability probe, not another released design. Geometry changes require regenerated exports, source-stable reviews, drawing projections and website QA. STEP export timestamps may change file hashes on a rebuild.

## Candidate geometric evidence and full-width repair

This candidate was repaired after independent review found that the earlier 580 mm balance catch and 290 mm concentrate chute did not cover the nominal 600 mm belt through controlled downstream routing. The previous gate's limited transverse reach left both branch destinations connected in either nominal state. Previous source-hashed receipts remain historical evidence only.

The rebuilt candidate contains 494 valid named solids and 204,200 mesh triangles. The repair adds full-width intake mouths, explicit transverse convergence, an upstream-facing gate blade at the downstream branch root, and separate branch boundaries. Current source-solid results are recorded in `verification/full_width_routing_review.json`; the preserved predecessor regression is included there. `verification/discharge_independent_review.json` separately addresses motion and illustrative corridor clearance. A nominal contact or selected geometric corridor is not a validated physical seal or an accepted-fragment size.

Gate sealing, manufacturing tolerances, feed thickness/height/mass limits, friction, bridging, bounce, jet trajectories, flow capacity, residence/clearing time and control behavior remain engineering holds. The conical chamber floor and matching blade underside are preliminary surfaces requiring manufacturability and wear review. No physical material routing has been tested.

`verification/cad_export_validation.json` records the rebuilt STEP round trip and component count. `verification/geometry_export_consistency.json` checks indexed geometry, normals and GLB coordinate conversion against that source identity. `verification/interfaces_review.json` checks documented interfaces, cassette-core withdrawal and conservative +800 mm sweeps for actual bin components. These are scoped geometric checks, not complete machine assurance.

`design_basis/requirements_coverage.json` maps requirements to modeled provisions and holds. The cassette height-adjustment mechanism, complete guarding/interlock architecture, selected hardware and physical sorting tests remain unfinished engineering work.

## Receiving capture hold — IR01-R1

Moving-particle capture is a design hold. A gravity-only 1.5 m/s horizontal point launch at x=3000, z=1000 mm and y=275 mm crosses the converging cheek at x=3174.64 mm, z=933.51 mm; the wall top is 863.21 mm (about 70 mm below). Existing side guards at y=±525 mm do not collect that interior path. This analytical counterexample is not a measured trial. Intake width does not prove capture. No operating speed or full-width no-jet capture route is approved; all displayed paths and motion speeds are schematic until receiving containment and physical trials resolve this hold.
