"""Checks for units, baseline values, revisions and loss of routing constraints."""

import copy
import json
from pathlib import Path
import unittest

from calculate import compute, displacement_per_frame_mm, render_report, travel_time_s

ROOT = Path(__file__).resolve().parent


class ConceptCalculationTests(unittest.TestCase):
    def setUp(self):
        self.parameters = json.loads((ROOT / "parameters.json").read_text())
        self.basis = json.loads((ROOT / "design_basis.json").read_text())

    def test_authorized_reference_values_and_unit_conversion(self):
        result = compute(self.parameters, self.basis)
        self.assertEqual(result["distances_mm"]["last_sensing_to_lip"], 1250)
        expected = [(0.5, 50 / 3, 2.5), (1.0, 100 / 3, 1.25), (2.0, 200 / 3, 0.625)]
        for row, (speed, displacement, time) in zip(result["speed_cases"], expected):
            self.assertEqual(row["belt_speed_m_s"], speed)
            self.assertAlmostEqual(row["belt_displacement_per_frame_mm"], displacement)
            self.assertEqual(row["travel_times_s"]["last_sensing_to_lip"], time)
        self.assertAlmostEqual(result["pilot_feed_ramp_conversion"]["minimum_g_s"], 125 / 9)
        self.assertAlmostEqual(result["pilot_feed_ramp_conversion"]["maximum_g_s"], 500 / 9)

    def test_enclosure_and_datum_remain_distinct(self):
        derived = compute(self.parameters, self.basis)["derived_geometry"]
        self.assertEqual(derived["induction_cassette_x_min_mm"], 1425)
        self.assertEqual(derived["induction_cassette_x_max_mm"], 1775)
        self.assertEqual(derived["cassette_trailing_edge_beyond_last_sensing_datum_mm"], 25)
        self.assertEqual(derived["hood_stabilization_longitudinal_overlap_mm"], 50)

    def test_report_updates_with_calculation_inputs(self):
        updated = copy.deepcopy(self.parameters)
        updated["geometry_mm"]["sensing"]["last_sensing_datum_x"] = 1800
        updated["operating_conditions"]["camera_frame_rate_fps"]["reference"] = 25
        result = compute(updated, self.basis)
        self.assertEqual(result["speed_cases"][1]["belt_displacement_per_frame_mm"], 40)
        self.assertEqual(result["speed_cases"][1]["travel_times_s"]["last_sensing_to_lip"], 1.2)
        report = render_report(result, updated)
        self.assertIn("Motion per 25 fps frame", report)
        self.assertIn("leaves 1200 mm", report)
        self.assertIn("datum is -25 mm", report)
        self.assertNotIn("Motion per 30 fps frame", report)

    def test_nonpositive_nonfinite_or_boolean_inputs_fail(self):
        for value in (0, -1, float("inf"), float("nan"), True, "1"):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    displacement_per_frame_mm(value, 30)
                with self.assertRaises(ValueError):
                    travel_time_s(1250, value)

    def test_invalid_station_order_fails(self):
        self.parameters["geometry_mm"]["sensing"]["last_sensing_datum_x"] = 3100
        with self.assertRaisesRegex(ValueError, "Station order"):
            compute(self.parameters, self.basis)

    def test_nominal_deck_length_mismatch_fails(self):
        self.parameters["geometry_mm"]["belt"]["deck_length"] = 3200
        with self.assertRaisesRegex(ValueError, "Deck length"):
            compute(self.parameters, self.basis)

    def test_review_feedback_cannot_be_silently_removed(self):
        self.basis["routing"]["review_gate"]["position_feedback_required"] = False
        with self.assertRaisesRegex(ValueError, "group/window"):
            compute(self.parameters, self.basis)

    def test_cassette_gap_must_match_the_model_stack(self):
        self.parameters["modeled_configuration_mm"]["nonconductive_window"]["bottom_z"] = 987
        with self.assertRaisesRegex(ValueError, "housing-to-window gap"):
            compute(self.parameters, self.basis)

    def test_service_reservations_must_preserve_clearance(self):
        self.parameters["modeled_configuration_mm"]["side_service_reservations"]["positive_y_max"] = 1340
        with self.assertRaisesRegex(ValueError, "service zones"):
            compute(self.parameters, self.basis)

    def test_unknown_sensor_gap_stays_unknown(self):
        result = compute(self.parameters, self.basis)
        self.assertIsNone(self.parameters["adjustable_parameters"]["sensor_to_belt_gap_mm"]["value"])
        self.assertIsNone(self.parameters["width_assumptions_mm"]["usable_sensing_width"])
        self.assertEqual(result["modeled_configuration_checks"]["housing_top_to_window_underside_gap_mm"], 8)
        self.assertIn("Neither gap is the active sensor standoff", result["modeled_configuration_checks"]["status"])


if __name__ == "__main__":
    unittest.main()
