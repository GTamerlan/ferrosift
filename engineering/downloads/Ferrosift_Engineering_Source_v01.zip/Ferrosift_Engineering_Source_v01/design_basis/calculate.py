#!/usr/bin/env python3
"""Generate deterministic concept calculations; Python standard library only.

Run from any directory:
    python3 path/to/design_basis/calculate.py
Check committed/generated output without changing it:
    python3 path/to/design_basis/calculate.py --check

This program provides ideal geometry/kinematics, never measured performance.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def positive(value: float, label: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{label} must be a real number")
    if not math.isfinite(value) or value <= 0:
        raise ValueError(f"{label} must be finite and greater than zero")
    return float(value)


def displacement_per_frame_mm(speed_m_s: float, frame_rate_fps: float) -> float:
    return 1000.0 * positive(speed_m_s, "speed_m_s") / positive(frame_rate_fps, "frame_rate_fps")


def travel_time_s(distance_mm: float, speed_m_s: float) -> float:
    return positive(distance_mm, "distance_mm") / (1000.0 * positive(speed_m_s, "speed_m_s"))


def compute(parameters: dict, basis: dict) -> dict:
    geometry = parameters["geometry_mm"]
    belt, sensing = geometry["belt"], geometry["sensing"]
    hood, cassette = geometry["optical_hood"], geometry["induction_cassette"]
    operations = parameters["operating_conditions"]
    if parameters["geometry_unit"] != "mm":
        raise ValueError("This calculation source expects millimetre geometry")
    if belt["discharge_lip_x"] - belt["inlet_x"] != belt["deck_length"]:
        raise ValueError("Deck length must match inlet-to-lip distance")
    if not belt["inlet_x"] < sensing["rgb_center_x"] < sensing["induction_center_x"] < sensing["last_sensing_datum_x"] < belt["discharge_lip_x"]:
        raise ValueError("Station order must be inlet, RGB, induction, last sensing, lip")
    if cassette["center_x"] != sensing["induction_center_x"]:
        raise ValueError("Induction cassette centre must match the sensing station")
    if not hood["x_min"] < sensing["rgb_center_x"] < sensing["induction_center_x"] < hood["x_max"]:
        raise ValueError("RGB and induction study centres must lie within the hood envelope")
    if positive(hood["width"], "hood width") < positive(belt["active_width"], "active belt width"):
        raise ValueError("Reserved hood width must cover active belt width")
    if parameters["width_assumptions_mm"]["nominal_belt_width"] != belt["active_width"]:
        raise ValueError("Nominal width assumption must agree with belt geometry")
    model = parameters["modeled_configuration_mm"]
    modeled_cassette, window = model["induction_cassette"], model["nonconductive_window"]
    if modeled_cassette["top_z"] - modeled_cassette["bottom_z"] != cassette["height"]:
        raise ValueError("Modeled cassette height must match its reserved envelope")
    if window["bottom_z"] - modeled_cassette["top_z"] != window["housing_top_to_window_underside_gap"]:
        raise ValueError("Modeled housing-to-window gap must agree with z positions")
    if not modeled_cassette["bottom_z"] < modeled_cassette["top_z"] < window["bottom_z"] < window["top_z"] < belt["top_z"]:
        raise ValueError("Concept vertical stack must have positive clearances and thicknesses")
    zones = model["side_service_reservations"]
    if zones["positive_y_max"] - zones["positive_y_min"] != geometry["service"]["side_clearance"] or zones["negative_y_max"] - zones["negative_y_min"] != geometry["service"]["side_clearance"]:
        raise ValueError("Both modeled service zones must retain the selected clearance")
    if zones["positive_y_min"] != zones["reference_outer_width"] / 2 or zones["negative_y_max"] != -zones["reference_outer_width"] / 2:
        raise ValueError("Service-zone starts must match their reference outer width")
    for name, envelope in (("feeder", geometry["feeder"]), ("stabilization", geometry["stabilization"]), ("optical_hood", hood)):
        positive(envelope["x_max"] - envelope["x_min"], f"{name} length")
    if geometry["feeder"]["x_max"] != belt["inlet_x"]:
        raise ValueError("Feeder outlet datum must meet belt inlet datum")
    if geometry["stabilization"]["x_min"] != belt["inlet_x"]:
        raise ValueError("Stabilization zone must begin at belt inlet datum")
    positive(cassette["length"], "cassette length")
    positive(cassette["height"], "cassette height")
    positive(geometry["service"]["side_clearance"], "side service clearance")
    speed_spec = operations["belt_speed_m_s"]
    speeds = [positive(value, "study speed") for value in speed_spec["study_values"]]
    if not speeds or len(set(speeds)) != len(speeds) or speeds != sorted(speeds):
        raise ValueError("Study speeds must be nonempty, unique and ascending")
    if speed_spec["reference"] not in speeds:
        raise ValueError("Reference speed must be included in study values")
    fps = positive(operations["camera_frame_rate_fps"]["reference"], "frame rate")
    feed = operations["pilot_feed_rate_kg_h"]
    feed_min = positive(feed["test_ramp_min"], "minimum feed ramp")
    feed_max = positive(feed["test_ramp_max"], "maximum feed ramp")
    if feed_min > feed_max:
        raise ValueError("Feed ramp minimum must not exceed maximum")
    gate = basis["routing"]["review_gate"]
    if gate["control_mode"] != "group_window" or not gate["position_feedback_required"] or not gate["clear_gap_or_feed_inhibit_required"] or gate["exact_item_timing_claimed"]:
        raise ValueError("Review routing must retain the approved group/window constraints")

    distances = {
        "rgb_to_lip": belt["discharge_lip_x"] - sensing["rgb_center_x"],
        "induction_center_to_lip": belt["discharge_lip_x"] - sensing["induction_center_x"],
        "last_sensing_to_lip": belt["discharge_lip_x"] - sensing["last_sensing_datum_x"],
        "rgb_to_induction_center": sensing["induction_center_x"] - sensing["rgb_center_x"],
        "deck_inlet_to_lip": belt["deck_length"]
    }
    rows = []
    for speed in speeds:
        row = {
            "belt_speed_m_s": speed,
            "belt_displacement_per_frame_mm": displacement_per_frame_mm(speed, fps),
            "nominal_frame_period_s": 1.0 / fps,
            "travel_times_s": {name: travel_time_s(distance, speed) for name, distance in distances.items()},
            "nominal_frame_periods_last_sensing_to_lip": travel_time_s(distances["last_sensing_to_lip"], speed) * fps,
            "status": "calculated_estimate"
        }
        rows.append(row)
    derived = {
        "feeder_length_mm": geometry["feeder"]["x_max"] - geometry["feeder"]["x_min"],
        "stabilization_length_mm": geometry["stabilization"]["x_max"] - geometry["stabilization"]["x_min"],
        "optical_hood_length_mm": hood["x_max"] - hood["x_min"],
        "optical_hood_top_z_mm": belt["top_z"] + hood["height_above_deck"],
        "induction_cassette_x_min_mm": cassette["center_x"] - cassette["length"] / 2,
        "induction_cassette_x_max_mm": cassette["center_x"] + cassette["length"] / 2,
        "cassette_trailing_edge_beyond_last_sensing_datum_mm": cassette["center_x"] + cassette["length"] / 2 - sensing["last_sensing_datum_x"],
        "hood_stabilization_longitudinal_overlap_mm": max(0, min(hood["x_max"], geometry["stabilization"]["x_max"]) - max(hood["x_min"], geometry["stabilization"]["x_min"])),
        "nominal_feed_inlet_to_belt_lip_length_mm": belt["discharge_lip_x"] - geometry["feeder"]["x_min"],
        "status": "derived_geometry",
        "cautions": [
            "A nominated sensing datum is not a housing edge; use the calculated cassette trailing-edge offset and verify the physical detection footprint during calibration.",
            "Any hood/stabilization overlap is an overlap of reserved envelopes/process zones, not proof of a physical interference.",
            "The feed-inlet-to-lip length excludes discharge equipment, bins, longitudinal access and downstream transfers.",
            "Hood top z is a reserved-envelope limit; wall geometry and camera mounting height are not specified.",
            "Modeled cassette z and service-zone lateral boundaries are adjustable concept selections; their validity depends on the eventual sensor, belt/support stack and actual outer-machine envelope."
        ]
    }
    return {
        "schema_version": "1.0.0",
        "concept_id": parameters["concept_id"],
        "revision": parameters["revision"],
        "status": "Ideal calculations only; no throughput, latency, recognition or sorting performance demonstrated.",
        "formulas": {
            "displacement_per_frame_mm": "1000 * belt_speed_m_s / camera_frame_rate_fps",
            "travel_time_s": "distance_mm / (1000 * belt_speed_m_s)",
            "nominal_frame_periods_in_travel": "travel_time_s * camera_frame_rate_fps",
            "feed_rate_g_s": "feed_rate_kg_h * 1000 / 3600"
        },
        "assumptions": basis["kinematic_assumptions"],
        "frame_rate_reference_fps": fps,
        "distances_mm": distances,
        "derived_geometry": derived,
        "modeled_configuration_checks": {
            "window_thickness_mm": window["top_z"] - window["bottom_z"],
            "housing_top_to_window_underside_gap_mm": window["bottom_z"] - modeled_cassette["top_z"],
            "carrying_surface_to_window_top_distance_mm": belt["top_z"] - window["top_z"],
            "status": "Arithmetic checks of adjustable model selections only. Neither gap is the active sensor standoff; carrying-surface distance includes any intervening belt/support geometry."
        },
        "speed_cases": rows,
        "pilot_feed_ramp_conversion": {
            "minimum_g_s": feed_min * 1000 / 3600,
            "maximum_g_s": feed_max * 1000 / 3600,
            "status": "Unit conversion of an unvalidated test ramp; not a capacity calculation."
        },
        "not_calculated": [
            "Mass throughput capability, item rate or belt occupancy.",
            "Image resolution, blur, recognition performance or full-width sensor coverage.",
            "Processing/actuation latency budget, nozzle firing times or pneumatic demand.",
            "Airborne trajectories, ejection accuracy, chute residence time or exact item-level review timing.",
            "Drive torque/power, belt tension, structural strength or safety performance."
        ]
    }


def fmt(value: float, digits: int = 3) -> str:
    return f"{value:.{digits}f}".rstrip("0").rstrip(".")


def render_report(result: dict, parameters: dict) -> str:
    rows = result["speed_cases"]
    geometry = parameters["geometry_mm"]
    belt, sensing = geometry["belt"], geometry["sensing"]
    feeder, stabilization = geometry["feeder"], geometry["stabilization"]
    hood, cassette = geometry["optical_hood"], geometry["induction_cassette"]
    derived, operations = result["derived_geometry"], parameters["operating_conditions"]
    fps = result["frame_rate_reference_fps"]
    feed = operations["pilot_feed_rate_kg_h"]
    frame_counts = ", ".join(fmt(row["nominal_frame_periods_last_sensing_to_lip"]) for row in rows)
    study_speeds = ", ".join(fmt(row["belt_speed_m_s"]) for row in rows)
    size_classes = " and ".join(f"{fmt(campaign['lower'])}–{fmt(campaign['upper'])} mm" for campaign in operations["size_campaigns_sieve_mm"])
    model = parameters["modeled_configuration_mm"]
    model_cassette, model_window = model["induction_cassette"], model["nonconductive_window"]
    zones = model["side_service_reservations"]
    widths = parameters["width_assumptions_mm"]
    lines = [
        "# Ferrosift PCB-rich recovery conveyor — v0 calculation note",
        "",
        "Generated from `parameters.json` and `design_basis.json` by `calculate.py`. Geometry is a frozen study assumption; results below are ideal kinematic calculations, not measured sorting performance. This is a concept coordination package, not a fabrication or operating release.",
        "",
        "## Frozen geometry and scope",
        "",
        f"The active belt is {fmt(belt['active_width'])} mm wide over a {fmt(belt['deck_length'])} mm inlet-to-lip deck, with the carrying surface at z={fmt(belt['top_z'])} mm. RGB is centred at x={fmt(sensing['rgb_center_x'])} mm; the induction cassette at x={fmt(sensing['induction_center_x'])} mm; the last-sensing datum is x={fmt(sensing['last_sensing_datum_x'])} mm; discharge lip is x={fmt(belt['discharge_lip_x'])} mm. The selected datum therefore leaves {fmt(result['distances_mm']['last_sensing_to_lip'])} mm of nominal belt travel.",
        "",
        f"The concept targets already depolluted, liberated, dry screened WEEE after ferrous removal and before an existing eddy-current separator. Initial campaigns are {size_classes} sieve classes. Batteries, whole devices, hazardous feed, tangles and out-of-limit heavy/oversized pieces are excluded. Numeric maximum mass, thickness and longest-dimension limits still require definition; a sieve class does not establish them.",
        "",
        "## Ideal belt kinematics",
        "",
        f"Assume steady speed and material moving with the belt, without slip or collision. At the {fmt(fps)} fps calculation reference, displacement per frame is `1000 × speed / {fmt(fps)}` mm. Time to lip is `distance_mm / (1000 × speed_m_s)`.",
        "",
        f"| Belt speed (m/s) | Motion per {fmt(fps)} fps frame (mm) | Last datum → lip (s) | RGB → lip (s) | Induction centre → lip (s) | Full deck travel (s) |",
        "|---:|---:|---:|---:|---:|---:|"
    ]
    for row in rows:
        times = row["travel_times_s"]
        lines.append(f"| {fmt(row['belt_speed_m_s'])} | {row['belt_displacement_per_frame_mm']:.1f} | {fmt(times['last_sensing_to_lip'])} | {fmt(times['rgb_to_lip'])} | {fmt(times['induction_center_to_lip'])} | {fmt(times['deck_inlet_to_lip'])} |")
    lines += [
        "",
        f"The {fmt(operations['belt_speed_m_s']['reference'])} m/s case is the calculation reference. The {fmt(min(operations['belt_speed_m_s']['study_values']))}–{fmt(max(operations['belt_speed_m_s']['study_values']))} m/s range is a study range, not a demonstrated operating range. The frame period is {1000 / fps:.1f} ms. Nominal frame periods during the last-datum-to-lip travel are {frame_counts} at {study_speeds} m/s respectively; these are not guaranteed useful images or inference opportunities.",
        "",
        "Travel time to lip is not a validated processing budget. Acquisition phase, exposure, inference, tracking, communications, pneumatic response, jitter, nozzle position and airborne motion remain unspecified. Displacement per frame says nothing by itself about blur, pixel resolution or recognition quality.",
        "",
        "## Envelope checks",
        "",
        "| Reserved item | Extent or derived dimension | Interpretation |",
        "|---|---|---|",
        f"| Feeder/spreader | x={fmt(feeder['x_min'])}…{fmt(feeder['x_max'])} mm; {fmt(derived['feeder_length_mm'])} mm long | Width, height and feed mechanism unresolved |",
        f"| Stabilization | x={fmt(stabilization['x_min'])}…{fmt(stabilization['x_max'])} mm | Process-zone label; effectiveness unvalidated |",
        f"| Optical hood | x={fmt(hood['x_min'])}…{fmt(hood['x_max'])} mm; {fmt(hood['width'])} mm wide; {fmt(hood['height_above_deck'])} mm above deck; top z={fmt(derived['optical_hood_top_z_mm'])} mm | Reserved envelope; camera height and field of view adjustable |",
        f"| Induction cassette | x={fmt(derived['induction_cassette_x_min_mm'])}…{fmt(derived['induction_cassette_x_max_mm'])} mm; {fmt(cassette['width'])} × {fmt(cassette['length'])} × {fmt(cassette['height'])} mm | Adjustable under-belt configuration; no sensing coverage guarantee |",
        f"| Side service space | {fmt(geometry['service']['side_clearance'])} mm beyond each side of the final equipment envelope | Layout reservation; no regulatory compliance claim |",
        f"| Feeder inlet to lip | {fmt(derived['nominal_feed_inlet_to_belt_lip_length_mm'])} mm | Excludes discharge chutes, bins, end access and downstream transfers |",
        "",
        f"The cassette trailing edge minus the last-sensing datum is {fmt(derived['cassette_trailing_edge_beyond_last_sensing_datum_mm'])} mm (positive means the housing continues downstream). Treat x={fmt(sensing['last_sensing_datum_x'])} mm as a nominated measurement/tracking datum, not the enclosure edge or a calibrated detection boundary. The hood overlaps the named stabilization zone by {fmt(derived['hood_stabilization_longitudinal_overlap_mm'])} mm in x; detailed component placement must resolve physical clearances.",
        "",
        f"The chosen model places the cassette enclosure at z={fmt(model_cassette['bottom_z'])}–{fmt(model_cassette['top_z'])} mm and the nonconductive window at z={fmt(model_window['bottom_z'])}–{fmt(model_window['top_z'])} mm. The {fmt(model_window['housing_top_to_window_underside_gap'])} mm enclosure-to-window gap is adjustable and is not the active sensor standoff. Side service reservations are y={fmt(zones['positive_y_min'])}–{fmt(zones['positive_y_max'])} mm and y={fmt(zones['negative_y_min'])}–{fmt(zones['negative_y_max'])} mm; move their boundaries outward wherever actual hardware exceeds the reference envelope.",
        "",
        f"Keep three width assumptions distinct: nominal belt width {fmt(widths['nominal_belt_width'])} mm, research effective-width case {fmt(widths['research_throughput_effective_width'])} mm, and independent camera-FOV example {fmt(widths['camera_field_of_view_example'])} mm. The latter two are separate study examples; calibrated usable sensing width is unresolved and neither establishes full belt coverage.",
        "",
        "## Feed ramp and routing limits",
        "",
        f"The proposed {fmt(feed['test_ramp_min'])}–{fmt(feed['test_ramp_max'])} kg/h pilot ramp converts to {fmt(result['pilot_feed_ramp_conversion']['minimum_g_s'])}–{fmt(result['pilot_feed_ramp_conversion']['maximum_g_s'])} g/s. This is only a unit conversion; no machine capacity, item rate or belt occupancy is established.",
        "",
        "One proposed airjet stage separates target from balance. The downstream balance-path gate diverts conservative groups/windows to review, with feed inhibit or a verified clear gap, allowance for chute residence uncertainty and gate-position feedback. A single air bar does not establish precise three-way sorting. A software stop and ordinary review bin are not safety-rated controls or battery containment.",
        "",
        "The existing recorded steel/copper model demo remains separate from proposed PCB sensing. No PCB inference accuracy, recovery, purity, economic advantage or competitor failure rate is asserted.",
        "",
        "## Reproduction and remaining inputs",
        "",
        "Run `python3 calculate.py` in this directory to regenerate `calculations.json` and this note. Run `python3 calculate.py --check` to verify that generated outputs match the current inputs. The JSON output records SHA-256 digests of both input manifests.",
        "",
        "Complete feed acceptance limits, device selection, optical/sensing calibration, end-to-end timing, ejection and review trials, mechanical sizing and a competent machinery risk assessment before any operational release. See `design_basis.json` for the explicit validation gates and `parameters.json` for unresolved inputs.",
        ""
    ]
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="Fail if generated files differ, without writing")
    args = parser.parse_args()
    paths = {"parameters": ROOT / "parameters.json", "design_basis": ROOT / "design_basis.json"}
    raw = {name: path.read_bytes() for name, path in paths.items()}
    data = {name: json.loads(contents) for name, contents in raw.items()}
    result = compute(data["parameters"], data["design_basis"])
    result["input_sha256"] = {paths[name].name: hashlib.sha256(contents).hexdigest() for name, contents in raw.items()}
    outputs = {
        ROOT / "calculations.json": json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
        ROOT / "CALCULATIONS.md": render_report(result, data["parameters"])
    }
    for path, content in outputs.items():
        if args.check:
            if not path.exists() or path.read_text(encoding="utf-8") != content:
                raise SystemExit(f"Generated output is stale or missing: {path}")
        else:
            path.write_text(content, encoding="utf-8")
    print("Verified generated calculations and report" if args.check else "Generated calculations.json and CALCULATIONS.md")


if __name__ == "__main__":
    main()
