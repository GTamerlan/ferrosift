# Ferrosift PCB-rich recovery conveyor — v0 calculation note

Generated from `parameters.json` and `design_basis.json` by `calculate.py`. Geometry is a frozen study assumption; results below are ideal kinematic calculations, not measured sorting performance. This is a concept coordination package, not a fabrication or operating release.

## Frozen geometry and scope

The active belt is 600 mm wide over a 3000 mm inlet-to-lip deck, with the carrying surface at z=1000 mm. RGB is centred at x=1300 mm; the induction cassette at x=1600 mm; the last-sensing datum is x=1750 mm; discharge lip is x=3000 mm. The selected datum therefore leaves 1250 mm of nominal belt travel.

The concept targets already depolluted, liberated, dry screened WEEE after ferrous removal and before an existing eddy-current separator. Initial campaigns are 12.5–25 mm and 25–50 mm sieve classes. Batteries, whole devices, hazardous feed, tangles and out-of-limit heavy/oversized pieces are excluded. Numeric maximum mass, thickness and longest-dimension limits still require definition; a sieve class does not establish them.

## Ideal belt kinematics

Assume steady speed and material moving with the belt, without slip or collision. At the 30 fps calculation reference, displacement per frame is `1000 × speed / 30` mm. Time to lip is `distance_mm / (1000 × speed_m_s)`.

| Belt speed (m/s) | Motion per 30 fps frame (mm) | Last datum → lip (s) | RGB → lip (s) | Induction centre → lip (s) | Full deck travel (s) |
|---:|---:|---:|---:|---:|---:|
| 0.5 | 16.7 | 2.5 | 3.4 | 2.8 | 6 |
| 1 | 33.3 | 1.25 | 1.7 | 1.4 | 3 |
| 2 | 66.7 | 0.625 | 0.85 | 0.7 | 1.5 |

The 1 m/s case is the calculation reference. The 0.5–2 m/s range is a study range, not a demonstrated operating range. The frame period is 33.3 ms. Nominal frame periods during the last-datum-to-lip travel are 75, 37.5, 18.75 at 0.5, 1, 2 m/s respectively; these are not guaranteed useful images or inference opportunities.

Travel time to lip is not a validated processing budget. Acquisition phase, exposure, inference, tracking, communications, pneumatic response, jitter, nozzle position and airborne motion remain unspecified. Displacement per frame says nothing by itself about blur, pixel resolution or recognition quality.

## Envelope checks

| Reserved item | Extent or derived dimension | Interpretation |
|---|---|---|
| Feeder/spreader | x=-1400…0 mm; 1400 mm long | Width, height and feed mechanism unresolved |
| Stabilization | x=0…1100 mm | Process-zone label; effectiveness unvalidated |
| Optical hood | x=1050…1950 mm; 900 mm wide; 850 mm above deck; top z=1850 mm | Reserved envelope; camera height and field of view adjustable |
| Induction cassette | x=1425…1775 mm; 600 × 350 × 200 mm | Adjustable under-belt configuration; no sensing coverage guarantee |
| Side service space | 900 mm beyond each side of the final equipment envelope | Layout reservation; no regulatory compliance claim |
| Feeder inlet to lip | 4400 mm | Excludes discharge chutes, bins, end access and downstream transfers |

The cassette trailing edge minus the last-sensing datum is 25 mm (positive means the housing continues downstream). Treat x=1750 mm as a nominated measurement/tracking datum, not the enclosure edge or a calibrated detection boundary. The hood overlaps the named stabilization zone by 50 mm in x; detailed component placement must resolve physical clearances.

The chosen model places the cassette enclosure at z=780–980 mm and the nonconductive window at z=988–994 mm. The 8 mm enclosure-to-window gap is adjustable and is not the active sensor standoff. Side service reservations are y=450–1350 mm and y=-1350–-450 mm; move their boundaries outward wherever actual hardware exceeds the reference envelope.

Keep three width assumptions distinct: nominal belt width 600 mm, research effective-width case 500 mm, and independent camera-FOV example 400 mm. The latter two are separate study examples; calibrated usable sensing width is unresolved and neither establishes full belt coverage.

## Feed ramp and routing limits

The proposed 50–200 kg/h pilot ramp converts to 13.889–55.556 g/s. This is only a unit conversion; no machine capacity, item rate or belt occupancy is established.

One proposed airjet stage separates target from balance. The downstream balance-path gate diverts conservative groups/windows to review, with feed inhibit or a verified clear gap, allowance for chute residence uncertainty and gate-position feedback. A single air bar does not establish precise three-way sorting. A software stop and ordinary review bin are not safety-rated controls or battery containment.

The existing recorded steel/copper model demo remains separate from proposed PCB sensing. No PCB inference accuracy, recovery, purity, economic advantage or competitor failure rate is asserted.

## Reproduction and remaining inputs

Run `python3 calculate.py` in this directory to regenerate `calculations.json` and this note. Run `python3 calculate.py --check` to verify that generated outputs match the current inputs. The JSON output records SHA-256 digests of both input manifests.

Complete feed acceptance limits, device selection, optical/sensing calibration, end-to-end timing, ejection and review trials, mechanical sizing and a competent machinery risk assessment before any operational release. See `design_basis.json` for the explicit validation gates and `parameters.json` for unresolved inputs.
