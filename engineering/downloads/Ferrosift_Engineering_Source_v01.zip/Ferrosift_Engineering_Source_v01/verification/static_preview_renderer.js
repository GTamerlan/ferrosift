/* Offscreen CAD illustration: exact source triangles, orthographic camera,
 * per-fragment depth test, individual-triangle-sorted transparent surfaces.
 * No UI, external library, geometry simplification, pose change or remeshing.
 */
'use strict';
(function(){
const W=2400,H=1440,VP={x:70,y:170,w:2260,h:1090};
const dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0),cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],norm=a=>{const s=Math.hypot(...a);return a.map(v=>v/s);},rgb=s=>[0,2,4].map(i=>parseInt(s.replace('#','').slice(i,i+2),16)/255);
const canvas=document.createElement('canvas');canvas.width=VP.w;canvas.height=VP.h;
const gl=canvas.getContext('webgl2',{alpha:false,antialias:true,depth:true,preserveDrawingBuffer:true});
if(!gl)throw Error('WebGL2 is required for static depth-buffer previews.');
const VS=`#version 300 es
in vec3 position;in vec3 normal;uniform mat4 vp;out vec3 world;out vec3 n;
void main(){world=position;n=normal;gl_Position=vp*vec4(position,1.0);}`;
const FS=`#version 300 es
precision highp float;in vec3 world;in vec3 n;uniform vec3 color;uniform float alpha;uniform float unlit;uniform vec3 viewDirection;uniform vec3 clipMin;uniform vec3 clipMax;out vec4 pixel;
void main(){if(any(lessThan(world,clipMin))||any(greaterThan(world,clipMax)))discard;
vec3 nn=normalize(n);if(!gl_FrontFacing)nn=-nn;vec3 key=normalize(vec3(-.35,-.65,1.));vec3 fill=normalize(vec3(.65,.5,.6));
float light=.46+.40*max(0.,dot(nn,key))+.14*max(0.,dot(nn,fill));float spec=.045*pow(max(0.,dot(reflect(-key,nn),viewDirection)),24.);
pixel=vec4(mix(color*light+vec3(spec),color,unlit),alpha);}`;
function shader(type,src){const s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s;}
const program=gl.createProgram();gl.attachShader(program,shader(gl.VERTEX_SHADER,VS));gl.attachShader(program,shader(gl.FRAGMENT_SHADER,FS));gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(program));
const loc={};for(const name of ['vp','color','alpha','unlit','viewDirection','clipMin','clipMax'])loc[name]=gl.getUniformLocation(program,name);loc.position=gl.getAttribLocation(program,'position');loc.normal=gl.getAttribLocation(program,'normal');
let assembly,meshes;
function buffer(values){const b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(values),gl.STATIC_DRAW);return b;}
function mesh(object){if(!object.vertices||!object.indices||!object.normals)throw Error('Incomplete mesh '+object.id);
 const v=new Float32Array(object.indices.length*3),n=new Float32Array(v.length);object.indices.forEach((index,k)=>{v.set(object.vertices.slice(index*3,index*3+3),k*3);n.set(object.normals.slice(index*3,index*3+3),k*3);});
 const bounds=object.bbox||{min:[Infinity,Infinity,Infinity],max:[-Infinity,-Infinity,-Infinity]};if(!object.bbox)for(let i=0;i<v.length;i+=3)for(let k=0;k<3;k++){bounds.min[k]=Math.min(bounds.min[k],v[i+k]);bounds.max[k]=Math.max(bounds.max[k],v[i+k]);}
 return{object,v,n,positionBuffer:buffer(v),normalBuffer:buffer(n),bounds,color:rgb(object.color),opacity:object.opacity??1,count:v.length/3};}
function bind(m){gl.bindBuffer(gl.ARRAY_BUFFER,m.positionBuffer);gl.enableVertexAttribArray(loc.position);gl.vertexAttribPointer(loc.position,3,gl.FLOAT,false,0,0);gl.bindBuffer(gl.ARRAY_BUFFER,m.normalBuffer);gl.enableVertexAttribArray(loc.normal);gl.vertexAttribPointer(loc.normal,3,gl.FLOAT,false,0,0);}
function draw(m,unlit=0){bind(m);gl.uniform3fv(loc.color,m.color);gl.uniform1f(loc.alpha,m.opacity);gl.uniform1f(loc.unlit,unlit);gl.drawArrays(gl.TRIANGLES,0,m.count);}
function visible(m,s){return!m.object.default_hidden&&(!s.categories||s.categories.includes(m.object.category))&&m.bounds.min.every((v,k)=>v<=s.clipMax[k])&&m.bounds.max.every((v,k)=>v>=s.clipMin[k]);}
function camera(items,s){const az=s.azimuth*Math.PI/180,el=s.elevation*Math.PI/180,direction=[Math.cos(az)*Math.cos(el),Math.sin(az)*Math.cos(el),Math.sin(el)],right=norm(cross([0,0,1],direction)),up=cross(direction,right),lo=[Infinity,Infinity,Infinity],hi=[-Infinity,-Infinity,-Infinity];
 for(const m of items){const a=m.bounds.min.map((v,k)=>Math.max(v,s.clipMin[k])),b=m.bounds.max.map((v,k)=>Math.min(v,s.clipMax[k]));if(a.some((v,k)=>v>b[k]))continue;
  for(const x of[a[0],b[0]])for(const y of[a[1],b[1]])for(const z of[a[2],b[2]]){const p=[x,y,z],q=[dot(p,right),dot(p,up),dot(p,direction)];q.forEach((v,k)=>{lo[k]=Math.min(lo[k],v);hi[k]=Math.max(hi[k],v);});}}
 const center=lo.map((v,k)=>(v+hi[k])/2);let spanX=(hi[0]-lo[0])*1.09,spanY=(hi[1]-lo[1])*1.10;if(spanX/spanY>VP.w/VP.h)spanY=spanX*VP.h/VP.w;else spanX=spanY*VP.w/VP.h;
 const depth=(hi[2]-lo[2])/2+1000,sx=spanX/2,sy=spanY/2,matrix=new Float32Array([right[0]/sx,up[0]/sy,-direction[0]/depth,0,right[1]/sx,up[1]/sy,-direction[1]/depth,0,right[2]/sx,up[2]/sy,-direction[2]/depth,0,-center[0]/sx,-center[1]/sy,center[2]/depth,1]);
 return{direction,right,up,matrix,spanX,spanY,viewBounds:{min:lo,max:hi}};}
function transparentPass(items,cam){const tris=[];for(const m of items)for(let i=0;i<m.v.length;i+=9){let d=0;for(let k=0;k<3;k++)d+=dot(Array.from(m.v.slice(i+k*3,i+k*3+3)),cam.direction)/3;tris.push({m,i,d});}tris.sort((a,b)=>a.d-b.d);
 const batches=[];for(const t of tris){let b=batches.at(-1);if(!b||b.mesh!==t.m){b={mesh:t.m,v:[],n:[]};batches.push(b);}b.v.push(...t.m.v.slice(t.i,t.i+9));b.n.push(...t.m.n.slice(t.i,t.i+9));}
 gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);gl.depthMask(false);for(const b of batches){const m={...b.mesh,positionBuffer:buffer(b.v),normalBuffer:buffer(b.n),count:b.v.length/3};draw(m);gl.deleteBuffer(m.positionBuffer);gl.deleteBuffer(m.normalBuffer);}gl.depthMask(true);gl.disable(gl.BLEND);return tris.length;}
function routeMeshes(s,cam){if(!s.routes)return[];const colors={target:'#c97e29',balance:'#34799b',review:'#995e47'},result=[];
 for(const[name,path]of Object.entries(assembly.routes||{})){const v=[],n=[];for(let i=1;i<path.length;i++){const a=path[i-1],b=path[i],delta=b.map((x,k)=>x-a[k]),len=Math.hypot(...delta),dir=delta.map(x=>x/len),side=norm(cross(dir,cam.direction)).map(x=>x*5.5);
  for(let start=0;start<len;start+=46){const end=Math.min(start+27,len),p=a.map((x,k)=>x+dir[k]*start),q=a.map((x,k)=>x+dir[k]*end),corners=[p.map((x,k)=>x+side[k]),p.map((x,k)=>x-side[k]),q.map((x,k)=>x-side[k]),q.map((x,k)=>x+side[k])];for(const k of[0,1,2,0,2,3]){v.push(...corners[k]);n.push(...cam.direction);}}}
 result.push({positionBuffer:buffer(v),normalBuffer:buffer(n),count:v.length/3,color:rgb(colors[name]),opacity:1});}return result;}
function axes(ctx,cam){const ox=2200,oy=1310,colors=['#ad754e','#5c8770','#507d9c'];ctx.lineCap='round';ctx.lineWidth=3;ctx.font='600 20px Arial';
 for(let k=0;k<3;k++){const dx=cam.right[k]*67,dy=-cam.up[k]*67;ctx.strokeStyle=colors[k];ctx.fillStyle=colors[k];ctx.beginPath();ctx.moveTo(ox,oy);ctx.lineTo(ox+dx,oy+dy);ctx.stroke();ctx.fillText(['X','Y','Z'][k],ox+dx+7,oy+dy+6);}ctx.font='18px Arial';ctx.fillStyle='#9cafbd';ctx.fillText('CAD axes',2163,1374);}
function compose(s,cam,count){const sheet=document.createElement('canvas');sheet.width=W;sheet.height=H;const ctx=sheet.getContext('2d');ctx.fillStyle='#101923';ctx.fillRect(0,0,W,H);ctx.drawImage(canvas,VP.x,VP.y);
 ctx.fillStyle='#eef4f7';ctx.font='600 54px Arial';ctx.fillText(s.title,70,86);ctx.font='22px Arial';ctx.fillStyle='#a1b3c0';ctx.fillText('PARAMETRIC SOLID CAD  /  INVESTOR CANDIDATE v01  /  PRELIMINARY DESIGN',72,126);
 ctx.fillStyle='#849aa9';ctx.font='600 21px Arial';ctx.textAlign='right';ctx.fillText(s.code,2325,85);ctx.textAlign='left';ctx.strokeStyle='#304554';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(70,151);ctx.lineTo(2330,151);ctx.stroke();
 ctx.font='23px Arial';ctx.fillStyle='#c1d0d9';ctx.fillText(`${count} named components shown  •  Units: mm  •  Orthographic ${s.cropped?'cropped view; cuts uncapped':'assembly view'}`,72,1304);
 ctx.font='21px Arial';ctx.fillStyle='#9cafbd';ctx.fillText(s.contextNote||'Removable covers omitted for clarity. Unselected devices are concept envelopes; optional depth is hidden.',72,1340);ctx.fillText('Not for fabrication. Strength, sensing, material flow, actuation and safeguarding remain unvalidated.',72,1375);axes(ctx,cam);
 if(s.routes){let x=85;for(const[color,label]of[['#c97e29','PCB-rich target'],['#34799b','Balance'],['#995e47','Review group']]){ctx.strokeStyle=color;ctx.lineWidth=4;ctx.setLineDash([13,9]);ctx.beginPath();ctx.moveTo(x,192);ctx.lineTo(x+58,192);ctx.stroke();ctx.setLineDash([]);ctx.font='22px Arial';ctx.fillStyle='#c1d0d9';ctx.fillText(label,x+72,200);x+=310;}ctx.font='20px Arial';ctx.fillStyle='#9cafbd';ctx.fillText('Dashed overlays show routing intent, not measured trajectories.',85,233);}return sheet.toDataURL('image/png').split(',')[1];}
window.depthProbe=function(){const c=document.createElement('canvas');c.width=c.height=16;const g=c.getContext('webgl2',{depth:true,antialias:false,preserveDrawingBuffer:true});
 const compile=(type,src)=>{const s=g.createShader(type);g.shaderSource(s,src);g.compileShader(s);if(!g.getShaderParameter(s,g.COMPILE_STATUS))throw Error(g.getShaderInfoLog(s));return s;};const p=g.createProgram();g.attachShader(p,compile(g.VERTEX_SHADER,'#version 300 es\nin vec3 p;void main(){gl_Position=vec4(p,1.);}'));g.attachShader(p,compile(g.FRAGMENT_SHADER,'#version 300 es\nprecision highp float;uniform vec3 c;out vec4 outColor;void main(){outColor=vec4(c,1.);}'));g.linkProgram(p);g.useProgram(p);
 const pl=g.getAttribLocation(p,'p'),cl=g.getUniformLocation(p,'c'),b=g.createBuffer();g.bindBuffer(g.ARRAY_BUFFER,b);g.enableVertexAttribArray(pl);g.vertexAttribPointer(pl,3,g.FLOAT,false,0,0);g.enable(g.DEPTH_TEST);g.depthFunc(g.LESS);g.viewport(0,0,16,16);
 const draw=(z,color)=>{g.bufferData(g.ARRAY_BUFFER,new Float32Array([-1,-1,z,3,-1,z,-1,3,z]),g.STREAM_DRAW);g.uniform3fv(cl,color);g.drawArrays(g.TRIANGLES,0,3);};const tests=[];
 for(const reversed of[false,true]){g.clear(g.COLOR_BUFFER_BIT|g.DEPTH_BUFFER_BIT);if(reversed){draw(.5,[1,0,0]);draw(-.5,[0,1,0]);}else{draw(-.5,[0,1,0]);draw(.5,[1,0,0]);}const px=new Uint8Array(4);g.readPixels(8,8,1,1,g.RGBA,g.UNSIGNED_BYTE,px);tests.push(Array.from(px));}
 const passed=tests.every(px=>px[0]===0&&px[1]===255&&px[2]===0);if(!passed)throw Error('Depth occlusion probe failed.');return{passed,near_triangle_visible_in_both_draw_orders:tests,depth_bits:g.getParameter(g.DEPTH_BITS)};};
window.renderStaticPreview=function(s){const shown=meshes.filter(m=>visible(m,s));if(!shown.length)throw Error('Empty preview '+s.name);const cam=camera(shown,s),opaque=shown.filter(m=>m.opacity>=1),transparent=shown.filter(m=>m.opacity<1);
 gl.viewport(0,0,VP.w,VP.h);gl.clearColor(16/255,25/255,35/255,1);gl.clearDepth(1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.useProgram(program);gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LESS);gl.disable(gl.CULL_FACE);gl.disable(gl.BLEND);gl.depthMask(true);
 gl.uniformMatrix4fv(loc.vp,false,cam.matrix);gl.uniform3fv(loc.viewDirection,cam.direction);gl.uniform3fv(loc.clipMin,s.clipMin);gl.uniform3fv(loc.clipMax,s.clipMax);for(const m of opaque)draw(m);const transparentTriangles=transparentPass(transparent,cam);
 const overlays=routeMeshes(s,cam);gl.depthMask(false);for(const m of overlays)draw(m,1);gl.depthMask(true);gl.finish();const error=gl.getError();if(error!==gl.NO_ERROR)throw Error('WebGL error '+error);
 const png=compose(s,cam,shown.length);for(const m of overlays){gl.deleteBuffer(m.positionBuffer);gl.deleteBuffer(m.normalBuffer);}
 return{png,metadata:{name:s.name,width:W,height:H,visible_components:shown.length,visible_source_triangles:shown.reduce((v,m)=>v+m.count/3,0),opaque_components:opaque.length,transparent_components:transparent.length,triangle_sorted_transparent_triangles:transparentTriangles,source_component_ids:shown.map(m=>m.object.id),depth_test_enabled:gl.isEnabled(gl.DEPTH_TEST),depth_write_restored:gl.getParameter(gl.DEPTH_WRITEMASK),depth_bits:gl.getParameter(gl.DEPTH_BITS),antialias:gl.getContextAttributes().antialias,renderer:gl.getParameter(gl.RENDERER),version:gl.getParameter(gl.VERSION),gl_error:error,clip_min_mm:s.clipMin,clip_max_mm:s.clipMax,camera:{azimuth_deg:s.azimuth,elevation_deg:s.elevation,projection:'orthographic',view_plane_span_mm:[cam.spanX,cam.spanY],view_bounds:cam.viewBounds},capture:'Raw WebGL canvas drawn onto a captioned 2D canvas; no UI screenshot',geometry:'Exactly expanded source indices/vertices/normals; no simplification, remeshing or pose changes',routes:s.routes?'Depth-tested dashed routing-intent overlays, not CAD bodies':false}};};
window.previewReady=fetch('/mesh.json').then(r=>{if(!r.ok)throw Error('Mesh fetch failed');return r.json();}).then(data=>{assembly=data;if(data.units!=='mm')throw Error('Expected millimetre mesh');meshes=data.objects.map(mesh);return{objects:meshes.length,triangles:meshes.reduce((s,m)=>s+m.count/3,0)};});
})();
