"""Reproduce the targeted mechanical interface review from executed CAD solids.

From the concept project directory:
    XDG_CACHE_HOME=/tmp/ferrosift-cad-cache .venv-cad/bin/python verification/run_interface_review.py

Requires the pinned CadQuery environment and design_basis/parameters.json.
Writes verification/interfaces_review.json; does not modify CAD geometry.
Geometric PASS does not establish structural, sensing, flow or safety approval.
"""
import sys,json,hashlib,itertools,datetime
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'cad'))
import cadquery as cq
from build_conveyor import build
params=json.loads((BASE/'design_basis/parameters.json').read_text())
source_hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (BASE/'cad').glob('*.py')}
parts=build(params); by={p['id']:p for p in parts}
mechanical=parts[:next(i for i,p in enumerate(parts) if p['id']=='feed_hopper_shell')]
others=parts[len(mechanical):]
def box(x0,x1,y0,y1,z0,z1):return cq.Solid.makeBox(x1-x0,y1-y0,z1-z0,cq.Vector(x0,y0,z0))
def volume(a,b):
 ba,bb=a.BoundingBox(),b.BoundingBox()
 if min(min(getattr(ba,k+'max'),getattr(bb,k+'max'))-max(getattr(ba,k+'min'),getattr(bb,k+'min')) for k in ('x','y','z'))<=1e-5:return 0.
 return a.intersect(b).Volume()
def hits(shape,candidates):
 result=[]
 for r in candidates:
  v=volume(shape,r['shape'])
  if v>.1:result.append({'id':r['id'],'intersection_volume_mm3':v,'removable':r.get('removable',False)})
 return result
cross=[]
for a in mechanical:
 for b in others:
  v=volume(a['shape'],b['shape'])
  if v>.1:cross.append({'a':a['id'],'b':b['id'],'intersection_volume_mm3':v})
print('CROSS',json.dumps(cross),flush=True)
belt_hits=hits(by['belt_loop']['shape'],[r for r in parts if r['id']!='belt_loop'])
window_hits=hits(by['sensing_window']['shape'],[r for r in parts if r['id']!='sensing_window'])
window=by['sensing_window']['shape'];cap=by['induction_nonconductive_cap']['shape']
# The core-housing swept envelope deliberately includes its internal empty space.
core=box(1425,1775,-1200,300,780,980)
moving_prefixes=('induction_cassette','induction_nonconductive','sensor_drawer_handle','sensor_handle_pad','sensor_connector','sensor_mount_tab')
fixed=[r for r in parts if not r['id'].startswith(moving_prefixes)]
core_hits=hits(core,fixed)
core_blockers=[h for h in core_hits if h['id']!='access_panel_left']
# Review surrounding metal structural supports directly below the sliding window.
structural_categories={'frame','deck','bearing','fasteners','roller','drive','encoder','cable','hood','camera','light','airjet','guard','controls','research'}
aperture=box(1350,1850,-300,300,980,994)
metal_hits=hits(aperture,[r for r in parts if r['category'] in structural_categories])
# Modeled nonconductive end beams bear on posts that contact the base rails.
contacts=[]
for end in ('in','out'):
 beam=by['window_end_beam_'+end]['shape'];contacts.append({'a':'sensing_window','b':'window_end_beam_'+end,'distance_mm':window.distance(beam),'nominal_contact_area_mm2':30*600})
 for side in ('near','far'):
  ident=f'window_support_pedestal_{end}_{side}';post=by[ident]['shape']
  rail='frame_rail_left_drop' if side=='near' else 'frame_rail_right'
  b=post.BoundingBox()
  contacts.append({'a':'window_end_beam_'+end,'b':ident,'distance_mm':beam.distance(post),'nominal_contact_area_mm2':30*40})
  contacts.append({'a':ident,'b':rail,'distance_mm':post.distance(by[rail]['shape']),'nominal_contact_area_mm2':b.xlen*b.ylen})
# Exact occupied-section sweep for +800 mm straight bin removal. Pull distance
# exceeds bin length, so the translated front/back walls overlap in this prism.
binchecks=[]
for name,y in [('review',-340),('concentrate',0),('balance',340)]:
 # Conservative union of every actual named bin part's occupied bounding box,
 # extruded along the full +800 mm pull. Covers new rims/handles as well as feet.
 sections=[]
 for component in parts:
  if component['id'].startswith('bin_'+name):
   b=component['shape'].BoundingBox()
   sections.append(box(b.xmin,b.xmax+800,b.ymin,b.ymax,b.zmin,b.zmax))
 sweep=cq.Compound.makeCompound(sections)
 obstruction=hits(sweep,[r for r in parts if not r['id'].startswith('bin_'+name)])
 assembled=hits(by['bin_'+name]['shape'],[r for r in parts if not r['id'].startswith('bin_'+name)])
 binchecks.append({'bin':name,'status':'PASS' if not obstruction and not assembled else 'FAIL','translation_mm':[800,0,0],'occupied_sweep_intersections':obstruction,'as_assembled_shell_intersections':assembled,'scope':'Conservative occupied AABB union for every actual bin component, swept +800 mm; includes rim and handle projections. Empty bin-shell space is conservatively filled. Manual handling, loads, brakes, accessibility and downstream free aisle unvalidated.'})
 print('BIN',name,json.dumps(obstruction),flush=True)
ground=[]
for r in parts:
 if r['id'].startswith(('feed_floor_pad','cabinet_foot','foot_pad_','discharge_foot')) or (r['id'].startswith('bin_') and '_foot_' in r['id']):
  z=r['shape'].BoundingBox().zmin;ground.append({'id':r['id'],'z_min_mm':z,'status':'PASS' if abs(z)<1e-5 else 'FAIL'})
service_prereq=['Stop feed and follow a separately designed isolation procedure before service; this model does not specify a certified safe stop.','Remove left access panel before cassette withdrawal.','Withdraw/retract all four vertical locating pins and release retention before sliding the cassette; disconnect external connectors.','Support the withdrawn cassette externally. Drawer rail reach, load capacity, pull force, hose slack and human handling are unvalidated.']
report={'schema_version':1,'review':'Current-candidate targeted mechanical assembly interface review','verification_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'parameters_sha256':hashlib.sha256((BASE/'design_basis/parameters.json').read_bytes()).hexdigest(),'reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Exact BRep intersections at relevant module interfaces, conservative cassette-core sweep, occupied-section bin sweeps, geometric window support contacts and floor contacts. Not an exhaustive same-module interference or engineering assurance review.','source_hashes':source_hashes,'component_count':len(parts),'method':{'engine':'CadQuery '+cq.__version__+' / OpenCascade','intersection_threshold_mm3':.1,'broadphase':'Axis-aligned bounding-box rejection; touching joints permitted','geometric_contact_tolerance_mm':1e-5},'checks':{'mechanical_to_other_modules':{'status':'PASS' if not cross else 'FAIL','overlaps':cross},'belt_to_entire_assembly':{'status':'PASS' if not belt_hits else 'FAIL','overlaps':belt_hits,'window_contact':'Nominal sliding contact; zero geometric clearance is intentional. Wear/friction/deflection not validated.'},'window_to_entire_assembly':{'status':'PASS' if not window_hits else 'FAIL','overlaps':window_hits},'window_housing_gap':{'status':'PASS' if abs(window.distance(cap)-8)<1e-5 else 'FAIL','gap_mm':window.distance(cap),'meaning':'Housing cap to support-window underside only; active coil-to-material standoff remains unknown.'},'metal_structural_supports_in_window_gap':{'status':'PASS' if not metal_hits else 'FAIL','volume_test_mm':{'x':[1350,1850],'y':[-300,300],'z':[980,994]},'overlaps':metal_hits,'limitation':'Absence of a metal support in this volume does not establish an interference-free sensing field. Cassette internals, nearby metals and static-control needs remain unvalidated.'},'window_support_contact_continuity':{'status':'PASS' if all(c['distance_mm']<1e-5 for c in contacts) else 'FAIL','contacts':contacts,'limitation':'Nominal geometric contact only. Material, creep, stiffness, fastening and load distribution are unvalidated.'},'cassette_core_withdrawal':{'status':'PASS' if not core_blockers else 'FAIL','translation_mm':[0,-900,0],'swept_volume_mm':{'x':[1425,1775],'y':[-1200,300],'z':[780,980]},'intersections_before_service_preparation':core_hits,'fixed_blockers_after_left_panel_removed':core_blockers,'prerequisites':service_prereq,'scope_limit':'Core housing envelope only; full removable-tab/connector motion requires the stated release steps. No safe service approval.'},'bin_straight_withdrawal':binchecks,'floor_contacts':{'status':'PASS' if ground and all(x['status']=='PASS' for x in ground) else 'FAIL','parts':ground}},'inherited_interface_design_details':['Negative-y window support pedestals narrowed in x40→30 to clear steel drop links.','Left access-panel clearance slots added for the two fixed drawer rails; panel still removed for cassette withdrawal.','Feeder floor pads added and cabinet pedestals extended to nominal floor.','Airbar brackets, pneumatic device envelopes and enclosure geometry relocated to resolve eight cross-module interferences.','Outer enclosure posts shifted to y±525 to clear outer collection bins.'],'unverified':['Strength, bearing life, drive torque, belt tracking and tension.','Window wear/deflection, sensing performance, active coil placement and material conductivity.','Chute flow, bounce, jet trajectories, gate timing and throughput.','Compliant guarding, interlocks, emergency stop, isolation, dust/fire engineering or battery containment.','Fully constrained moving-joint CAD, manufactured fits, fasteners and weld details.','Physical bin/cassette handling, clear external floor aisle and service loads.']}
fail=bool(cross or belt_hits or window_hits or metal_hits or core_blockers or any(x['status']=='FAIL' for x in binchecks) or any(x['status']=='FAIL' for x in ground) or any(c['distance_mm']>=1e-5 for c in contacts))
current={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (BASE/'cad').glob('*.py')}
report['source_changed_during_review']=current!=source_hashes
report['overall_geometric_status']='FAIL' if fail else ('UNVERIFIED' if current!=source_hashes else 'PASS')
report['inherited_interface_design_details'].append('Pneumatic supply route raised fromz910 toroutecentre z915; its Ø24 outer envelope now clears upperrailz900 by3 mm at the transverse crossing.')
for item in report['checks']['bin_straight_withdrawal']:
    if item['bin'] in ('review','balance'):
        bin_parts=[r['shape'].BoundingBox() for r in parts if r['id'].startswith('bin_'+item['bin'])]
        extent=max(b.ymax for b in bin_parts) if item['bin']=='balance' else -min(b.ymin for b in bin_parts)
        item['outer_bin_to_post_nominal_lateral_clearance_mm']=507.5-extent
(BASE/'verification'/'interfaces_review.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'status':report['overall_geometric_status'],'components':len(parts),'cross_count':len(cross),'belt_hits':belt_hits,'window_hits':window_hits,'metal_hits':metal_hits,'core_hits':core_hits,'source_changed':current!=source_hashes},indent=2),flush=True)

raise SystemExit(0 if report['overall_geometric_status']=='PASS' else 1)
