"""Read-only gravity-point counterexample; does not validate a flow envelope."""
from pathlib import Path
import sys, json, math, hashlib
from datetime import datetime, timezone

ENG=Path(__file__).resolve().parents[1]
ROOT=ENG.parent
sys.path.insert(0,str(ENG/'cad'))
import cadquery as cq
from build_conveyor import build

OUT=Path(__file__).parent
p=json.loads((ENG/'design_basis/parameters.json').read_text())
parts=build(p)
g=9810.0
v=1500.0

def z_at(x,z0): return z0-g*(x-3000)**2/(2*v*v)
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def bbox_overlap(part,y,z0,xend):
    b=part['shape'].BoundingBox()
    lo=max(3001,b.xmin);hi=min(xend,b.xmax)
    return lo<=hi and b.ymin-1e-7<=y<=b.ymax+1e-7 and z_at(lo,z0)>=b.zmin-1e-7 and z_at(hi,z0)<=b.zmax+1e-7

trajectories=[]
for z0 in (1000.0,1014.0):
  for y in (-300.0,-275.0,-150.0,0.0,150.0,275.0,300.0):
    t0=1/v
    tend=math.sqrt(2*z0/g)
    duration=tend-t0
    a=cq.Vector(3000+v*t0,y,z0-g*t0*t0/2)
    b=cq.Vector(a.x+v*duration/2,y,a.z-g*t0*duration/2)
    c=cq.Vector(3000+v*tend,y,0)
    # Three poles give an exact quadratic Bezier, hence an exact parabola.
    curve=cq.Edge.makeBezier([a,b,c])
    cases=[]
    for angle in (-.45,.45):
      intersections=[]
      candidate_distances=[]
      for part in parts:
        shape=part['shape']
        if part['id']=='review_gate_plate':
          shape=shape.rotate((3560,0,740),(3560,0,741),math.degrees(angle))
          part={**part,'shape':shape}
        if not bbox_overlap(part,y,z0,c.x):continue
        d=curve.distance(shape)
        candidate_distances.append({'part_id':part['id'],'distance_mm':d})
        common=shape.intersect(curve)
        if common.Edges() or common.Vertices():
          xs=[q.X for q in common.Vertices()]
          intersections.append({'part_id':part['id'],'first_x_mm':min(xs) if xs else None,'intersection_edges':len(common.Edges()),'intersection_vertices':len(common.Vertices())})
      intersections.sort(key=lambda r:r['first_x_mm'] if r['first_x_mm'] is not None else 1e10)
      cases.append({'gate_angle_rad':angle,'intersections_of_unperturbed_path':intersections,'broad_phase_candidate_distances':candidate_distances})
    trajectories.append({'launch_z_mm':z0,'lane_y_mm':y,'ground_x_mm':c.x,'ground_time_s':tend,'states':cases})

crossings=[]
for z0 in (1000.,1014.):
  for y in (68.,100.,150.,200.,250.,275.,300.):
    x=3140+(330-y)*165/262
    floor=780-(x-3140)*80/165
    top=floor+100
    # The rod radius adds at most 6 mm vertically; this is a conservative bound.
    crossings.append({'launch_z_mm':z0,'abs_lane_y_mm':y,'inner_cheek_crossing_x_mm':x,'time_s':(x-3000)/v,'trajectory_z_mm':z_at(x,z0),'floor_base_z_mm':floor,'sheet_top_z_mm':top,'height_above_sheet_mm':z_at(x,z0)-top,'height_above_top_plus_full_rod_radius_mm':z_at(x,z0)-(top+6),'speed_at_sheet_top_crossing_m_s':(x-3000)/math.sqrt(2*(z0-top)/g)/1000})

report={
 'status':'DYNAMIC_CAPTURE_DESIGN_HOLD_CONFIRMED',
 'generated_utc':datetime.now(timezone.utc).isoformat(),
 'cadquery':cq.__version__,
 'geometry_changed':False,
 'source_identity':{str(f.relative_to(ROOT)):digest(f) for f in (ENG/'cad/discharge.py',ENG/'cad/build_conveyor.py',ENG/'design_basis/parameters.json',ENG/'exports/assembly_manifest.json',ENG/'exports/conveyor_assembly.step')},
 'scope':{'units':'mm; seconds; speeds explicitly labelled m/s','launch_x_mm':3000,'launch_z_mm':[1000,1014],'initial_horizontal_speed_m_s':1.5,'initial_lateral_velocity_m_s':0,'initial_vertical_velocity_m_s':0,'gravity_m_s2':9.81,'point_particle':True,'ignores':['drag','lift','tumbling','finite particle size','collisions after first contact','rebound','friction','air jets','material interactions'],'curve':'Exact quadratic Bezier for z=z0-9810*(x-3000)^2/(2*1500^2), from x3001 to nominal ground z0; source-solid Boolean intersections, both stable gate states. First millimetre excluded only to avoid prescribed belt-release contact.'},
 'physical_geometry':{'balance_intake_width_mm':660,'balance_throat_width_mm':136,'taper_x_mm':[3140,3305],'cheek_height_mm':100,'cheek_top_end_z_mm':[880,800],'rolled_edge_outer_radius_mm':6,'guard_side_panel_abs_y_mm':[523.5,526.5],'guard_side_panel_bottom_z_mm':695,'roof_bottom_z_mm':1218.5,'front_or_rear_receiving_panel_present':False,'continuous_bottom_capture_floor_present':False},
 'analytic_cheek_crossings':crossings,
 'continuous_source_solid_checks':trajectories,
 'findings':[
  'At both belt-surface and marker launch heights, y=+/-300 mm gravity-only 1.5 m/s paths pass over the tapered balance cheek and its rolled edge.',
  'The exact continuous outer-lane paths have no source-solid contact before nominal ground in either stable gate state. They miss the receiving floor, gate and side bins; zero lateral velocity never brings them to the enclosure side windows.',
  'The positive static-width and nominal gate-connectivity receipts remain scoped static geometry checks and do not establish moving-particle capture.',
  'A slower speed is not automatically safe: it can underthrow the catch or hit air hardware, and no rebound/flow envelope has been validated. The sheet-top crossing threshold is a diagnostic calculation only, not an operating limit.'
 ],
 'recommended_illustration_restriction':{
  'speed':'Do not label 1.5 m/s (or any selected speed) as an accepted routing/production speed. If retaining a belt speed control, label it kinematic transport illustration only and exclude downstream scripted routes from its physical meaning.',
  'route':'Disable animated material on balance/review/concentrate paths by default until trajectory/capture validation, or clearly display those paths only as intended routing schematics independent of belt speed. Do not use them as measured or simulated particle paths.',
  'publication_copy':'Dynamic capture unresolved: a gravity-only 1.5 m/s point path from an outer belt lane clears the balance funnel wall and is not contained by the modeled enclosure. The 660 mm inlet width is nominal geometry only. Intended route curves do not demonstrate particle capture, throughput or safe operation.',
  'engineering_hold':'Provide and review a bounded receiver/containment design for the accepted speed, size, mass, shape and rebound envelope, including access, guarding, clean-out and pneumatic-route compatibility; validate before operational claims.'
 },
 'limitation':'A counterexample under ideal gravity assumptions identifies a design hold. This is not a physical test, validated DEM/CFD model, safety assessment, certified operating envelope or proof that any other launch condition is captured.'
}
for traj in trajectories:
 if abs(traj['lane_y_mm'])==300:
  assert all(not s['intersections_of_unperturbed_path'] for s in traj['states']),traj
OUT.mkdir(parents=True,exist_ok=True)
(OUT/'dynamic_capture_review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'outer_lane_trajectories':len([r for r in trajectories if abs(r['lane_y_mm'])==300]),'source_parts':len(parts),'report':str(OUT/'dynamic_capture_review.json')}))
