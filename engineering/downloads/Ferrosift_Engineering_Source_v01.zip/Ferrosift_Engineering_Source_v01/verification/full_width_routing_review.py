"""Independent source-solid review of full-width discharge capture and branch control.

Run with the preserved local CadQuery Python; writes full_width_routing_review.json.
This is a geometric review of chosen solids, never a particle/flow simulation.
"""
from __future__ import annotations
import hashlib
import json
import math
import sys
import zipfile
import types
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "cad"))
import cadquery as cq
import discharge


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def box(x0, x1, y0, y1, z0, z1):
    return cq.Solid.makeBox(x1-x0, y1-y0, z1-z0, cq.Vector(x0,y0,z0))


def bounds(s):
    b=s.BoundingBox()
    return {"min":[b.xmin,b.ymin,b.zmin],"max":[b.xmax,b.ymax,b.zmax]}


def overlap(a,b):
    aa,bb=a.BoundingBox(),b.BoundingBox()
    if any(getattr(aa,k+"max") < getattr(bb,k+"min") or getattr(bb,k+"max") < getattr(aa,k+"min") for k in "xyz"):
        return 0.
    return a.intersect(b).Volume()


def collect(module,parameters):
    shapes,metadata={},{}
    def add(ident,name,category,shape,color=None,**meta):
        shapes[ident]=shape.val() if isinstance(shape,cq.Workplane) else shape
        metadata[ident]={"name":name,"category":category,**meta}
    module.build(add,parameters)
    return shapes,metadata


def hull(points):
    """2D convex hull of an actual convex source panel, no assumed panel width."""
    p=sorted(set((round(float(x),8),round(float(y),8)) for x,y in points))
    def cross(o,a,b):return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
    low=[]
    for v in p:
        while len(low)>1 and cross(low[-2],low[-1],v)<=0:low.pop()
        low.append(v)
    high=[]
    for v in reversed(p):
        while len(high)>1 and cross(high[-2],high[-1],v)<=0:high.pop()
        high.append(v)
    return low[:-1]+high[:-1]


def floor_plan(s,z0=0,z1=1):
    flat=[face for face in s.Faces() if abs(face.normalAt().z)>.999999 and face.BoundingBox().zlen<1e-5]
    if flat:
        face=max(flat,key=lambda f:f.Area())
        z=face.BoundingBox().zmin
        return cq.Solid.extrudeLinear(face.outerWire(),face.innerWires(),cq.Vector(0,0,z1-z0)).translate((0,0,z0-z))
    # Nonhorizontal chute floors are convex planar trapezoidal panels. Their
    # vertical extrusion gives coincident top/bottom XY outlines.
    xy=hull([(v.X,v.Y) for v in s.Vertices()])
    return cq.Workplane("XY").polyline(xy).close().extrude(z1-z0).translate((0,0,z0)).val()


def section(s,x,epsilon=.005):
    b=s.BoundingBox()
    cut=s.intersect(box(x-epsilon,x+epsilon,b.ymin-1,b.ymax+1,b.zmin-1,b.zmax+1))
    return bounds(cut) if cut.Solids() else None


def baseline_findings():
    backup=ROOT.parent/"verification"/"repair_20261014"/"engineering_before_repair.zip"
    portable=ROOT/"verification"/"repair_baseline"
    provenance=json.loads((portable/"provenance.json").read_text())
    if backup.exists():
        with zipfile.ZipFile(backup) as z:
            src=z.read("engineering/cad/discharge.py")
            parameter_bytes=z.read("engineering/design_basis/parameters.json")
        if digest(backup)!=provenance["archive_sha256"]:raise ValueError("Preserved archive identity mismatch")
    else:
        src=(portable/"discharge.py").read_bytes()
        parameter_bytes=(portable/"parameters.json").read_bytes()
    if hashlib.sha256(src).hexdigest()!=provenance["files"]["discharge.py"] or hashlib.sha256(parameter_bytes).hexdigest()!=provenance["files"]["parameters.json"]:
        raise ValueError("Portable predecessor source identity mismatch")
    params=json.loads(parameter_bytes)
    old=types.ModuleType("preserved_candidate_discharge")
    exec(compile(src,"preserved engineering_before_repair.zip/cad/discharge.py","exec"),old.__dict__)
    shapes,meta=collect(old,params)
    blade=shapes["review_gate_plate"].BoundingBox()
    floor=shapes["review_gate_floor"].BoundingBox()
    bcatch=shapes["balance_catch_floor"].BoundingBox()
    target=shapes["concentrate_chute_floor"].BoundingBox()
    animation=meta["review_gate_plate"]["animation"]
    radial=max(abs(blade.xmin-animation["pivot"][0]),abs(blade.xmax-animation["pivot"][0]))
    old_connectivity=gate_connectivity(shapes,meta,["review_gate_floor"],
        ["review_gate_plate","review_gate_shaft"],[(floor.xmin+10,y) for y in (-250,-125,0,125,250)],
        {"balance":[(floor.xmax-20,200)],"review":[(floor.xmax-20,-200)]},
        [645,660,750,810],[floor.xmin,floor.xmax])
    return {"preserved_archive":str(backup.relative_to(ROOT.parent)),"archive_sha256":provenance["archive_sha256"],
        "portable_source_snapshot":"verification/repair_baseline",
        "portable_source_hashes_verified":True,
        "parameters_sha256":hashlib.sha256(parameter_bytes).hexdigest(),
        "discharge_source_sha256":hashlib.sha256(src).hexdigest(),
        "belt_active_width_mm":params["geometry_mm"]["belt"]["active_width"],
        "balance_catch_width_mm":bcatch.ylen,"gate_chamber_width_mm":floor.ylen,
        "blade_radial_length_mm":radial,"stable_tip_lateral_centerline_reach_mm":radial*math.sin(abs(animation["angle"])),
        "blade_bottom_to_floor_top_gap_mm":blade.zmin-floor.zmax,
        "concentrate_catch_width_mm":target.ylen,
        "gate_source_solid_connectivity":old_connectivity,
        "conclusion":"Both reported full-width geometry gaps are present in the preserved source. Centerline clearance cases did not prove transverse capture or closure. No tapered focusing floor/cheeks or downstream splitter were present."}



def capture_and_focusing(shapes, belt_width, ident, sample_count=21):
    floor=shapes[ident+"_floor"]
    b=floor.BoundingBox()
    cheeks=[(name,value) for name,value in shapes.items() if name.startswith(ident+"_side_")]
    rows=[]
    for i in range(sample_count):
        x=b.xmin+.01+(b.xlen-.02)*i/(sample_count-1)
        sec=section(floor,x)
        # Slice z bounds differ slightly because of the 0.01-mm slice thickness.
        z=(sec["min"][2]+sec["max"][2])/2
        edges=[]
        for y in (sec["min"][1],sec["max"][1]):
            vertex=cq.Vertex.makeVertex(x,y,z)
            distances=[(name,vertex.distance(value)) for name,value in cheeks]
            nearest=min(distances,key=lambda row:row[1]) if distances else (None,None)
            edges.append({"point_mm":[x,y,z],"nearest_side_cheek":nearest[0],"distance_mm":nearest[1]})
        rows.append({"x_mm":x,"width_mm":sec["max"][1]-sec["min"][1],"y_interval_mm":[sec["min"][1],sec["max"][1]],"edge_contacts":edges})
    inlet_vertices=[v.Y for v in floor.Vertices() if abs(v.X-b.xmin)<1e-6]
    outlet_vertices=[v.Y for v in floor.Vertices() if abs(v.X-b.xmax)<1e-6]
    start=[min(inlet_vertices),max(inlet_vertices)]
    end=[min(outlet_vertices),max(outlet_vertices)]
    capture=start[0]<=-belt_width/2 and start[1]>=belt_width/2
    edges_contained=all(edge["distance_mm"] is not None and edge["distance_mm"]<.05 for row in rows for edge in row["edge_contacts"])
    monotonic=all(rows[i+1]["width_mm"] <= rows[i]["width_mm"]+.02 for i in range(len(rows)-1))
    return {"status":"PASS" if capture and edges_contained and monotonic else "FAIL",
      "floor_id":ident+"_floor","side_cheek_ids":[n for n,_ in cheeks],
      "method":"Exact BRep intersection of floor with 0.01-mm x slabs at 21 longitudinal stations; shortest BRep distance from each floor cross-section edge midpoint to an actual side cheek. Width is measured, not copied from metadata.",
      "nominal_belt_width_mm":belt_width,"inlet_y_interval_mm":start,"outlet_y_interval_mm":end,
      "inlet_capture_margin_each_side_mm":[-belt_width/2-start[0],start[1]-belt_width/2],
      "full_belt_width_capture":capture,"all_sampled_edges_contained":edges_contained,
      "width_monotonically_nonincreasing":monotonic,"stations":rows,
      "limitation":"Floor/cheek existence and continuity do not establish capture of unknown ballistic trajectories, bounce or successful focusing."}


def outlet_bin_capture(shapes, ident, bin_name):
    """Vertical-drop aperture probe of the entire actual floor outlet edge."""
    floor=shapes[ident+"_floor"]
    vertices=floor.Vertices()
    lowest=min(v.Z for v in vertices)
    edge_points=[(v.X,v.Y,v.Z) for v in vertices if abs(v.Z-lowest)<1e-6]
    # A downward planar chute has exactly two lower outlet-edge vertices.
    if len(edge_points)!=2:
        return {"status":"HOLD","floor_id":ident+"_floor","reason":"Outlet edge not uniquely identifiable from the actual lowest floor vertices."}
    a,b=edge_points
    bin_ids=[n for n in shapes if n.startswith("bin_"+bin_name) and "_foot_" not in n and "_handle_" not in n]
    bin_floor=shapes["bin_"+bin_name].BoundingBox().zmin+10
    bin_top=max(shapes[n].BoundingBox().zmax for n in bin_ids)
    samples=[]
    for i in range(21):
        t=i/20
        x,y,z=[a[k]+(b[k]-a[k])*t for k in range(3)]
        # Downward probe begins above the rim and stops above the bin bottom.
        probe=cq.Solid.makeCylinder(.05,bin_top+20-bin_floor,cq.Vector(x,y,bin_floor),cq.Vector(0,0,1))
        hits=[{"id":n,"volume_mm3":overlap(probe,shapes[n])} for n in bin_ids]
        hits=[row for row in hits if row["volume_mm3"]>1e-7]
        samples.append({"outlet_point_mm":[x,y,z],"downward_aperture_collisions":hits})
    dx,dy=b[0]-a[0],b[1]-a[1]
    length=math.hypot(dx,dy)
    nx,ny=-dy/length*.05,dx/length*.05
    xy=[(a[0]+nx,a[1]+ny),(a[0]-nx,a[1]-ny),(b[0]-nx,b[1]-ny),(b[0]+nx,b[1]+ny)]
    curtain=cq.Workplane("XY").polyline(xy).close().extrude(bin_top+20-bin_floor).translate((0,0,bin_floor)).val()
    curtain_hits=[{"id":n,"volume_mm3":overlap(curtain,shapes[n])} for n in bin_ids]
    curtain_hits=[row for row in curtain_hits if row["volume_mm3"]>1e-7]
    aperture_slab=cq.Workplane("XY").polyline(xy).close().extrude(4).translate((0,0,bin_top-4)).val()
    rim_clearance=aperture_slab.distance(shapes["bin_"+bin_name+"_rim"])
    good=not curtain_hits and all(not row["downward_aperture_collisions"] for row in samples)
    return {"status":"PASS" if good else "FAIL","floor_id":ident+"_floor","bin_id":"bin_"+bin_name,
      "method":"Continuous 0.1-mm-thick vertical curtain across the entire actual lowest floor edge, plus 21 vertical point probes, checked against source bin shell and rim. A vertical projection check, not a fragment trajectory claim.",
      "continuous_outlet_edge_projection_collisions":curtain_hits,"minimum_projected_outlet_edge_to_rim_clearance_mm":rim_clearance,
      "outlet_edge_mm":edge_points,"bin_rim_top_z_mm":bin_top,"floor_outlet_z_mm":lowest,
      "vertical_drop_gap_mm":lowest-bin_top,"samples":samples}



def floor_transfer_projection(shapes, source_id, receiving_ids):
    floor=shapes[source_id]
    zmin=floor.BoundingBox().zmin
    outlet=[(v.X,v.Y,v.Z) for v in floor.Vertices() if abs(v.Z-zmin)<1e-6]
    if len(outlet)!=2:
        return {"status":"HOLD","source_floor":source_id,"reason":"Actual outlet edge not unique at minimum floor elevation."}
    a,b=outlet
    line=cq.Edge.makeLine(cq.Vector(a[0]+1e-4,a[1],.5),cq.Vector(b[0]+1e-4,b[1],.5))
    plans=[floor_plan(shapes[n]) for n in receiving_ids]
    receiver=plans[0].fuse(*plans[1:]) if len(plans)>1 else plans[0]
    coverage=sum(e.Length() for e in line.intersect(receiver).Edges())
    length=line.Length()
    return {"status":"PASS" if abs(coverage-length)<1e-4 else "FAIL",
      "source_floor":source_id,"receiving_floors":receiving_ids,"outlet_edge_mm":outlet,
      "outlet_edge_length_mm":length,"projected_length_over_receiving_floor_mm":coverage,
      "unsupported_outlet_edge_length_mm":max(0,length-coverage),
      "method":"Exact source outlet edge projected onto the actual receiver floor plan at z0.5, with a 0.0001-mm downstream nudge to avoid coincident-boundary ambiguity. Checks the entire edge, not selected center points.",
      "limitation":"Vertical plan capture only; transfer drop, rebound, hang-up, allowed feed geometry and floor/cheek attachments require physical engineering."}


def above_floor(s,height):
    from OCP.BRepPrimAPI import BRepPrimAPI_MakePrism
    from OCP.gp import gp_Vec
    top_faces=[f for f in s.Faces() if f.normalAt().z>1e-5]
    volumes=[cq.Shape.cast(BRepPrimAPI_MakePrism(f.wrapped,gp_Vec(0,0,height)).Shape()) for f in top_faces]
    if not volumes:raise ValueError("No upward-facing floor surfaces")
    return volumes[0].fuse(*volumes[1:]) if len(volumes)>1 else volumes[0]


def floor_z(shapes,floor_ids,x,y):
    bs=[shapes[n].BoundingBox() for n in floor_ids]
    ray=cq.Edge.makeLine(cq.Vector(x,y,min(b.zmin for b in bs)-10),cq.Vector(x,y,max(b.zmax for b in bs)+10))
    hits=[]
    for name in floor_ids:
        hits.extend(v.Z for v in ray.intersect(shapes[name]).Vertices())
    return max(hits) if hits else None


def gate_volume_connectivity(shapes,metadata,floor_ids,barrier_ids,inlet_points,outlet_points,x_clip,height=80,inlet_y_interval=None):
    animation=metadata["review_gate_plate"]["animation"]
    pivot=animation["pivot"]
    bands=[above_floor(shapes[n],height) for n in floor_ids]
    domain=bands[0].fuse(*bands[1:]).clean() if len(bands)>1 else bands[0]
    b=domain.BoundingBox()
    domain=domain.intersect(box(x_clip[0],x_clip[1],b.ymin-1,b.ymax+1,b.zmin-1,b.zmax+1))
    rows=[]
    for state,key in (("balance","balanceAngle"),("review","angle")):
        angle=animation[key]
        blade=shapes["review_gate_plate"].rotate(tuple(pivot),(pivot[0],pivot[1],pivot[2]+1),math.degrees(angle))
        barriers=[blade if n=="review_gate_plate" else shapes[n] for n in barrier_ids]
        free=domain.cut(*barriers).clean()
        cells=free.Solids()
        def locate(point):
            z=floor_z(shapes,floor_ids,*point)
            if z is None:return {"xy_mm":list(point),"status":"no_floor","regions":[]}
            z+=min(20,height/2)
            return {"point_mm":[*point,z],"regions":[i for i,cell in enumerate(cells) if cell.isInside(cq.Vector(*point,z),1e-6)]}
        inlet=[locate(p) for p in inlet_points]
        outlets={name:[locate(p) for p in points] for name,points in outlet_points.items()}
        inlet_regions=set(i for row in inlet for i in row["regions"])
        reachable={name:any(set(row["regions"]) & inlet_regions for row in points) for name,points in outlets.items()}
        wrong="review" if state=="balance" else "balance"
        all_valid=all(row["regions"] for row in inlet)
        all_intended=all(any(set(row["regions"]) & set(out["regions"]) for out in outlets[state]) for row in inlet)
        continuous=None
        continuous_good=True
        if inlet_y_interval:
            ix=inlet_points[0][0]
            inlet_slab=box(ix-.005,ix+.005,*inlet_y_interval,b.zmin-1,b.zmax+1)
            inlet_volumes=[overlap(cell,inlet_slab) for cell in cells]
            inlet_region_ids={i for i,v in enumerate(inlet_volumes) if v>1e-6}
            outlet_volumes={}
            for name,points in outlet_points.items():
                ox=points[0][0]
                yl,yh=(0,b.ymax+1) if name=="balance" else (b.ymin-1,0)
                slab=box(ox-.005,ox+.005,yl,yh,b.zmin-1,b.zmax+1)
                outlet_volumes[name]=[overlap(cell,slab) for cell in cells]
            continuous_reachable={name:any(v>1e-6 and i in inlet_region_ids for i,v in enumerate(volumes)) for name,volumes in outlet_volumes.items()}
            continuous_good=bool(inlet_region_ids) and continuous_reachable[state] and not continuous_reachable[wrong]
            continuous={"inlet_y_interval_mm":inlet_y_interval,"inlet_band_volume_by_region_mm3":inlet_volumes,
               "outlet_band_volume_by_region_mm3":outlet_volumes,"continuous_outlet_reachability":continuous_reachable,
               "method":"Exact 0.01-mm source-flow-band cross-section volumes across the complete stated inlet width and complete positive/negative branch width. Any common connected free-space region establishes a passage; no sparse lane sampling is needed for this result.","status":"PASS" if continuous_good else "FAIL"}
        good=all_valid and all_intended and not reachable[wrong] and continuous_good
        rows.append({"state":state,"angle_rad":angle,"status":"PASS" if good else "FAIL","free_space_region_count":len(cells),
          "continuous_full_throat_connectivity":continuous,
          "all_inlet_points_in_floor_domain":all_valid,"all_inlet_points_reach_intended_outlet":all_intended,
          "outlet_reachable_from_any_inlet_lane":reachable,"inlet_lanes":inlet,"outlet_lanes":outlets,
          "minimum_blade_to_chamber_floor_distance_mm":blade.distance(shapes["review_gate_floor"])})
    return {"status":"PASS" if all(row["status"]=="PASS" for row in rows) else "FAIL",
      "method":"Upward-facing source floor faces are swept vertically by the stated height using OpenCascade prisms, preserving their actual sloping/curved surfaces. Combined, x-clipped flow bands are cut by the actual stable blade and fixed barriers. Connected 3D BRep solids identify any passage between all inlet lanes and either branch, including low bypass within the tested band.",
      "floor_ids":floor_ids,"barrier_ids":barrier_ids,"x_clip_mm":x_clip,"test_band_height_above_local_floor_mm":height,
      "test_band_is_validated_feed_envelope":False,"flow_band_solid_valid":domain.isValid(),"cases":rows,
      "limitation":"The 80-mm geometric test band is an explicit review probe, not a maximum fragment-height specification. Open space above it, free-flight trajectories, tolerances, flex, contact, particle orientation, collisions, bridging and flow dynamics remain unvalidated."}

def gate_connectivity(shapes,metadata, floor_ids, barrier_ids, inlet_points, outlet_points, heights, x_clip):
    animation=metadata["review_gate_plate"]["animation"]
    pivot=animation["pivot"]
    rows=[]
    for state,key in (("balance","balanceAngle"),("review","angle")):
        angle=animation[key]
        blade=shapes["review_gate_plate"].rotate(tuple(pivot),(pivot[0],pivot[1],pivot[2]+1),math.degrees(angle))
        for height in heights:
            parts=[floor_plan(shapes[n],height-.005,height+.005) for n in floor_ids]
            domain=parts[0].fuse(*parts[1:]) if len(parts)>1 else parts[0]
            bb=domain.BoundingBox()
            domain=domain.intersect(box(x_clip[0],x_clip[1],bb.ymin-1,bb.ymax+1,height-.005,height+.005))
            active_barriers=[(n,blade if n=="review_gate_plate" else shapes[n]) for n in barrier_ids]
            cut=domain.cut(*[s for n,s in active_barriers]).clean()
            cells=cut.Solids()
            def cell_for(point):
                return [i for i,cell in enumerate(cells) if cell.isInside(cq.Vector(point[0],point[1],height),1e-6)]
            inlet=[{"xy_mm":list(p),"regions":cell_for(p)} for p in inlet_points]
            outlets={name:[{"xy_mm":list(p),"regions":cell_for(p)} for p in points] for name,points in outlet_points.items()}
            inlet_regions=set(i for row in inlet for i in row["regions"])
            reachable={name:any(set(row["regions"]) & inlet_regions for row in points) for name,points in outlets.items()}
            wrong="review" if state=="balance" else "balance"
            all_inlet_admitted=all(row["regions"] for row in inlet)
            all_inlet_reaches_intended=all(any(set(row["regions"]) & set(out["regions"]) for out in outlets[state]) for row in inlet)
            good=all_inlet_admitted and all_inlet_reaches_intended and not reachable[wrong]
            rows.append({"state":state,"angle_rad":angle,"slice_z_mm":height,"status":"PASS" if good else "FAIL",
              "free_space_region_count":len(cells),"all_inlet_points_in_floor_domain":all_inlet_admitted,
              "all_inlet_points_reach_intended_outlet":all_inlet_reaches_intended,
              "outlet_reachable_from_any_inlet_lane":reachable,"inlet_lanes":inlet,"outlet_lanes":outlets})
    return {"status":"PASS" if all(row["status"]=="PASS" for row in rows) else "FAIL",
      "method":"Actual horizontal floor face outlines (including holes) or convex sloping panel plan footprints, combined and clipped to the stated gate region, form a 0.01-mm horizontal slab. Actual source gate/wall/splitter solids are subtracted at each height and stable pose. Connected BRep solids identify passage from all inlet sample lanes to branch outlet sample lanes. Floor plan boundaries constrain the slab; wall presence and edge containment are separately checked.",
      "floor_ids":floor_ids,"barrier_ids":barrier_ids,"x_clip_mm":x_clip,"cases":rows,
      "limitation":"A static horizontal point-passage test. Gaps under/over the tested height interval, tolerances, flex, fragments with unknown thickness/shape, climbing, bounce, blockage and dynamics are not validated."}

def main():
    source=ROOT/"cad"/"discharge.py"
    parameter_path=ROOT/"design_basis"/"parameters.json"
    hashes={str(p.relative_to(ROOT)):digest(p) for p in (source,parameter_path)}
    parameters=json.loads(parameter_path.read_text())
    shapes,metadata=collect(discharge,parameters)
    # Geometry contract is intentionally stated in this independent checker;
    # it is not a CAD-authored assertion of its own validity.
    report={"schema_version":1,"reviewed_utc":datetime.now(timezone.utc).isoformat(),
      "status":"IN_PROGRESS", "scope":"Source-solid geometry: full-width inlet capture, focusing floor/cheek continuity, gate barrier connectivity, edge-lane geometric corridors and bin aperture capture. No physical flow, safety or performance validation.",
      "source_sha256":hashes,"verification_script_sha256":digest(Path(__file__)),
      "engine":"CadQuery "+cq.__version__+" / OpenCascade", "preserved_candidate_findings":baseline_findings(),
      "checks":{},"limitations":[
       "600 mm is the nominal belt width, not calibrated sensing or jet coverage.",
       "Lateral focusing is represented by floor and cheek geometry; friction, impact, bounce, bridging and hang-up are unvalidated.",
       "Neither sieve class nor this review supplies accepted maximum dimension, minimum thickness, shape, mass or loading limits.",
       "Plan-slab connectivity is a static geometric passage test at stated heights, not 3D dynamics or guaranteed material routing.",
       "Gate operation requires feed inhibit, measured clearing, position verification and controls that remain unimplemented and unvalidated.",
       "Physical hardware, pneumatic impulse/coverage, structural adequacy, manufactured tolerances, guarding and safety are unvalidated."
      ]}
    width=parameters["geometry_mm"]["belt"]["active_width"]
    report["checks"]["balance_full_width_capture_and_focusing"]=capture_and_focusing(shapes,width,"balance_catch")
    report["checks"]["concentrate_full_width_capture_and_focusing"]=capture_and_focusing(shapes,width,"concentrate_chute")
    report["checks"]["outlet_to_bin_apertures"]=[outlet_bin_capture(shapes,ident,bin_name) for ident,bin_name in
        (("concentrate_chute","concentrate"),("balance_branch","balance"),("review_branch","review"))]
    report["checks"]["catch_to_chamber_transfer"]=floor_transfer_projection(shapes,"balance_catch_floor",["review_gate_floor"])
    barrier_ids=[n for n in shapes if n.startswith(("gate_chamber_side_","gate_inlet_shoulder_"))]
    barrier_ids += ["review_gate_plate","review_gate_shaft","gate_inlet_step","gate_branch_splitter",
        "balance_branch_side_L","balance_branch_side_R","review_branch_side_L","review_branch_side_R"]
    source_lanes=sorted(set([-width/2,0,width/2]+list(range(-275,276,50))))
    throat_lanes=[y*68/330 for y in source_lanes]
    report["checks"]["gate_transverse_connectivity"]=gate_volume_connectivity(shapes,metadata,
      ["review_gate_floor","balance_branch_floor","review_branch_floor"],barrier_ids,
      [(3310,y) for y in throat_lanes],
      {"balance":[(3570,y) for y in (30,60,90)],"review":[(3570,y) for y in (-30,-60,-90)]},
      [3306,3580],height=80,inlet_y_interval=(-68,68))
    report["checks"]["gate_transverse_connectivity"]["illustrative_lane_mapping"]={
      "belt_y_mm":source_lanes,"throat_y_mm":throat_lanes,
      "meaning":"Linear coordinate mapping is only a choice of source-solid passage probes. It is not a prediction of object motion through the funnel. Continuous full-throat cross-section connectivity is checked separately."}
    report["checks"]["gate_vertical_envelope"]={
       "nominal_blade_to_chamber_floor_distance_mm":shapes["review_gate_plate"].distance(shapes["review_gate_floor"]),
       "floor_geometry":"Actual source conical top face; no global z-box gap is used for this sloping floor.",
       "minimum_admitted_fragment_thickness_mm":None,"maximum_admitted_fragment_height_mm":None,
       "status":"DESIGN_HOLD","reason":"Nominal exact CAD contact is not a physical seal. Manufacturing clearance, compliant seals, wear, flex, jams and accepted feed thickness/height/shape remain unspecified and must be validated before operation."}
    report["source_unchanged_during_review"]=all(digest(ROOT/name)==sha for name,sha in hashes.items())
    checks=report["checks"]
    required=[checks["balance_full_width_capture_and_focusing"],checks["concentrate_full_width_capture_and_focusing"],
        checks["catch_to_chamber_transfer"],checks["gate_transverse_connectivity"],*checks["outlet_to_bin_apertures"]]
    report["status"]="PASS_NOMINAL_GEOMETRY_WITH_DESIGN_HOLDS" if report["source_unchanged_during_review"] and all(row["status"]=="PASS" for row in required) else "FAILED_GEOMETRIC_CHECKS"
    report["gate_sweep_scope_note"]="This report verifies capture and nominal routing connectivity; gate transition interference and illustrative trajectories are separately reviewed in discharge_independent_review.json against the same source hash."
    (ROOT/"verification"/"full_width_routing_review.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps({"status":report["status"],"source_sha256":hashes,"checks":{name:([row["status"] for row in value] if isinstance(value,list) else value["status"]) for name,value in checks.items()}},indent=2))
    raise SystemExit(0 if report["status"]=="PASS_NOMINAL_GEOMETRY_WITH_DESIGN_HOLDS" else 1)


if __name__=="__main__":main()
