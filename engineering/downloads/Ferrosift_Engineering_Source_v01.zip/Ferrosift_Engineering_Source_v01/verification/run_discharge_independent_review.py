"""Independent discharge-only geometric checks; does not modify CAD source.

Checks exact capsule solids around route segments rather than sampled points.
Checks 37 gate poses plus a conservative bound on the entire rigid blade sweep.
"""
from __future__ import annotations
import hashlib
import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "cad"))
import cadquery as cq
import discharge


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bbox_overlap(a, b, tolerance=1e-7):
    aa, bb = a.BoundingBox(), b.BoundingBox()
    return all((getattr(aa, axis + "min") <= getattr(bb, axis + "max") + tolerance
                and getattr(bb, axis + "min") <= getattr(aa, axis + "max") + tolerance)
               for axis in "xyz")


def overlap_volume(a, b):
    return a.intersect(b).Volume() if bbox_overlap(a, b) else 0.0


def main():
    source = ROOT / "cad" / "discharge.py"
    parameters_path = ROOT / "design_basis" / "parameters.json"
    input_hashes = {str(path.relative_to(ROOT)): digest(path) for path in (source, parameters_path)}
    params = json.loads(parameters_path.read_text())
    shapes, metadata = {}, {}
    def add(ident, name, category, shape, color=None, **meta):
        shapes[ident] = shape.val() if isinstance(shape, cq.Workplane) else shape
        metadata[ident] = {"name": name, "category": category, **meta}
    discharge.build(add, params)
    animation = metadata["review_gate_plate"]["animation"]
    if animation["axis"] != "z":
        raise ValueError("Independent check expects the revised vertical-axis blade")
    pivot = animation["pivot"]
    review_angle = animation["angle"]
    balance_angle = animation["balanceAngle"]
    if review_angle * balance_angle >= 0:
        raise ValueError("Expected opposed stable gate positions")
    def blade(angle):
        return shapes["review_gate_plate"].rotate(tuple(pivot), (pivot[0], pivot[1], pivot[2]+1), math.degrees(angle))

    collision_tolerance_mm3 = 1e-5
    sweep_rows = []
    # Plate/shaft overlap is the intended attachment envelope, explicitly retained.
    intentional_mating_pairs = [["review_gate_plate", "review_gate_shaft"]]
    low_pose, high_pose = sorted((review_angle, balance_angle))
    angles = [low_pose + index * (high_pose-low_pose)/36 for index in range(37)]
    for angle in angles:
        current = blade(angle)
        collisions, mating = [], []
        minimum_clearance = None
        for ident, other in shapes.items():
            if ident == "review_gate_plate":
                continue
            volume = overlap_volume(current, other)
            if ident == "review_gate_shaft":
                mating.append({"part": ident, "overlap_mm3": volume})
            elif volume > collision_tolerance_mm3:
                collisions.append({"part": ident, "overlap_mm3": volume})
            elif metadata[ident]["category"] in ("chute", "gate"):
                distance = current.distance(other)
                if minimum_clearance is None or distance < minimum_clearance["distance_mm"]:
                    minimum_clearance = {"part": ident, "distance_mm": distance}
        sweep_rows.append({"angle_rad": angle, "collisions": collisions,
                           "intentional_mating_overlaps": mating,
                           "nearest_nonshaft_chute_or_gate": minimum_clearance})

    # Every blade point is within half-thickness of a radial centreline point.
    # The sector swept by that centreline, expanded by half-thickness in XY,
    # therefore encloses the continuous rigid blade sweep. This includes extra
    # space at the root, tip and angular ends and is deliberately conservative.
    bb = shapes["review_gate_plate"].BoundingBox()
    half_thickness = max(abs(bb.ymin-pivot[1]), abs(bb.ymax-pivot[1]))
    negative_reach, positive_reach = pivot[0]-bb.xmin, bb.xmax-pivot[0]
    if negative_reach > positive_reach:
        radial_direction, radius_to_tip = math.pi, negative_reach
        stub_vertices=[v for v in shapes["review_gate_plate"].Vertices() if v.X>pivot[0]]
        root_extension=max(0,positive_reach)
    else:
        radial_direction, radius_to_tip = 0.0, positive_reach
        stub_vertices=[v for v in shapes["review_gate_plate"].Vertices() if v.X<pivot[0]]
        root_extension=max(0,negative_reach)
    if root_extension>2*half_thickness+1e-6:
        raise ValueError("Sweep bound supports a predominantly one-sided radial blade, not a second long arm")
    root_stub_radius=max((math.hypot(v.X-pivot[0],v.Y-pivot[1]) for v in stub_vertices),default=0)
    blade_z_interval = [bb.zmin, bb.zmax]
    low_angle, high_angle = min(angles)+radial_direction, max(angles)+radial_direction
    middle_angle = (low_angle+high_angle)/2
    sector = (cq.Workplane("XY").moveTo(0, 0)
              .lineTo(radius_to_tip*math.cos(low_angle), radius_to_tip*math.sin(low_angle))
              .threePointArc((radius_to_tip*math.cos(middle_angle), radius_to_tip*math.sin(middle_angle)),
                             (radius_to_tip*math.cos(high_angle), radius_to_tip*math.sin(high_angle)))
              .close().offset2D(half_thickness).extrude(bb.zmax-bb.zmin)
              .translate((pivot[0], pivot[1], bb.zmin)).val())
    if root_stub_radius:
        stub=cq.Solid.makeCylinder(root_stub_radius,bb.zmax-bb.zmin,cq.Vector(pivot[0],pivot[1],bb.zmin),cq.Vector(0,0,1))
        sector=sector.fuse(stub).clean()
    # A coaxial conical underside is invariant under the gate rotation. Derive
    # it from the actual blade face, verify the full blade lies inside its upper
    # volume, then intersect the XY sweep bound with that same volume. This
    # removes physically impossible below-cone volume from the conservative
    # bound without widening any fixed obstacle or hiding an intersection.
    cone_bound=None
    underside=[face for face in shapes["review_gate_plate"].Faces() if face.geomType()=="CONE" and face.normalAt().z<0]
    if underside:
        if len(underside)!=1:raise ValueError("Expected one conical underside")
        cone=underside[0]._geomAdaptor().Cone()
        apex=cone.Apex();axis=cone.Axis().Direction();semi_angle=cone.SemiAngle()
        if math.hypot(apex.X()-pivot[0],apex.Y()-pivot[1])>1e-6 or abs(axis.Z()-1)>1e-6:
            raise ValueError("Conical underside must be coaxial with vertical gate rotation")
        height=bb.zmax-apex.Z()+100
        upper=cq.Solid.makeCone(0,height*math.tan(semi_angle),height,cq.Vector(apex.X(),apex.Y(),apex.Z()),cq.Vector(0,0,1))
        outside=shapes["review_gate_plate"].cut(upper).Volume()
        if outside>collision_tolerance_mm3:raise ValueError("Source blade is not contained by its inferred upper cone")
        sector=sector.intersect(upper).clean()
        cone_bound={"method":"Actual downward-facing conical blade face; coaxial upper-cone clipping is invariant under every rotation about the shaft", "apex_mm":[apex.X(),apex.Y(),apex.Z()],"semi_angle_rad":semi_angle,"source_blade_volume_outside_upper_cone_mm3":outside}
    # Exact coordinate extrema of the rotating convex XY footprint provide
    # a tighter invariant box. This matters for a bevelled tip that just touches
    # a fixed side wall: the broad capsule expansion otherwise protrudes past
    # a wall even though no rigid blade pose does. Check the source is contained
    # in its convex vertex footprint before using this analytic bound.
    from full_width_routing_review import hull
    xy=hull([(v.X,v.Y) for v in shapes["review_gate_plate"].Vertices()])
    footprint=cq.Workplane("XY").polyline(xy).close().extrude(bb.zmax-bb.zmin+2).translate((0,0,bb.zmin-1)).val()
    outside_footprint=shapes["review_gate_plate"].cut(footprint).Volume()
    if outside_footprint>collision_tolerance_mm3:raise ValueError("Source blade leaves its assumed polygonal XY footprint")
    extrema={"x":[],"y":[]}
    for x,y in xy:
        dx,dy=x-pivot[0],y-pivot[1]
        for axis,critical in (("x",math.atan2(-dy,dx)),("y",math.atan2(dx,dy))):
            candidates=[min(angles),max(angles)]
            candidates += [critical+k*math.pi for k in range(-3,4) if min(angles)<=critical+k*math.pi<=max(angles)]
            for a in candidates:
                value=(dx*math.cos(a)-dy*math.sin(a)+pivot[0]) if axis=="x" else (dx*math.sin(a)+dy*math.cos(a)+pivot[1])
                extrema[axis].append(value)
    xy_limits={axis:[min(values),max(values)] for axis,values in extrema.items()}
    xb,yb=xy_limits["x"],xy_limits["y"]
    exact_xy_box=cq.Solid.makeBox(xb[1]-xb[0],yb[1]-yb[0],bb.zmax-bb.zmin,cq.Vector(xb[0],yb[0],bb.zmin))
    sector=sector.intersect(exact_xy_box).clean()
    bound_containment=[]
    for angle in angles:
        outside=blade(angle).cut(sector).Volume()
        bound_containment.append({"angle_rad":angle,"blade_volume_outside_bound_mm3":outside})
    continuous_collisions = []
    continuous_nearest = None
    for ident, other in shapes.items():
        if ident in ("review_gate_plate", "review_gate_shaft"):
            continue
        volume = overlap_volume(sector, other)
        if volume > collision_tolerance_mm3:
            continuous_collisions.append({"part": ident, "overlap_mm3": volume})
        distance = sector.distance(other)
        if continuous_nearest is None or distance < continuous_nearest["distance_mm"]:
            continuous_nearest = {"part": ident, "distance_mm": distance}

    gate_positions = {"review": review_angle, "balance": balance_angle}
    # Target flow should remain clear for either stable gate state and transition pose.
    route_cases = [("review", gate_positions["review"]), ("balance", gate_positions["balance"]),
                   ("target", balance_angle), ("target", 0.0), ("target", review_angle)]
    radius = 8.0
    ox = params["geometry_mm"]["belt"]["discharge_lip_x"] - 3000
    oz = params["geometry_mm"]["belt"]["top_z"] - 1000
    routes = {name: [[x+ox, y, z+oz] for x,y,z in values] for name, values in discharge.ROUTES.items()}
    route_rows = []
    for name, angle in route_cases:
        obstacles = dict(shapes)
        obstacles["review_gate_plate"] = blade(angle)
        components = []
        for index, (a, b) in enumerate(zip(routes[name], routes[name][1:])):
            start, end = cq.Vector(*a), cq.Vector(*b)
            delta = end-start
            if delta.Length <= 0:
                raise ValueError("Zero-length routing segment")
            components.append(("segment", index, cq.Solid.makeCylinder(radius, delta.Length, start, delta.normalized())))
        for index, point in enumerate(routes[name]):
            # OCP's default sphere latitude starts at 0: request both hemispheres.
            components.append(("vertex", index, cq.Solid.makeSphere(radius, cq.Vector(*point), angleDegrees1=-90, angleDegrees2=90)))
        collisions = []
        for kind, index, capsule_component in components:
            for ident, obstacle in obstacles.items():
                volume = overlap_volume(capsule_component, obstacle)
                if volume > collision_tolerance_mm3:
                    collisions.append({"component": kind, "index": index, "part": ident, "overlap_mm3": volume})
        route_rows.append({"route": name, "gate_angle_rad": angle, "radius_mm": radius,
                           "segment_count": len(routes[name])-1,
                           "endcap_count": len(routes[name]), "collisions": collisions})

    ground_contacts = []
    for ident, shape in shapes.items():
        if (ident.startswith("bin_") and "_foot_" in ident) or ident.startswith("discharge_foot_"):
            bb = shape.BoundingBox()
            ground_contacts.append({"part": ident, "z_min_mm": bb.zmin,
                                    "on_nominal_floor": abs(bb.zmin) < 1e-7})
    post_connections = []
    for ident, shape in shapes.items():
        if ident.startswith("discharge_post_"):
            foot_id = ident.replace("discharge_post_", "discharge_foot_")
            gap = shape.distance(shapes[foot_id])
            post_connections.append({"post": ident, "foot": foot_id, "gap_mm": gap, "touching": gap < 1e-7})
    hashes_stable = all(digest(ROOT / name) == sha for name, sha in input_hashes.items())
    all_solids_valid = all(shape.isValid() and shape.Volume() > 0 for shape in shapes.values())
    passed = (hashes_stable and all_solids_valid and sector.isValid()
              and not continuous_collisions and all(row["blade_volume_outside_bound_mm3"]<=collision_tolerance_mm3 for row in bound_containment)
              and not any(row["collisions"] for row in sweep_rows+route_rows)
              and all(row["on_nominal_floor"] for row in ground_contacts)
              and all(row["touching"] for row in post_connections))
    report = {
        "status": "passed_geometric_checks" if passed else "failed_geometric_checks",
        "scope": "Discharge module only; independent check of the current vertical swing blade and illustrated routes.",
        "cadquery_version": cq.__version__,
        "source_sha256": input_hashes,
        "qa_source_sha256": digest(Path(__file__)),
        "qa_helper_sha256": {"verification/full_width_routing_review.py":digest(ROOT/"verification"/"full_width_routing_review.py")},
        "source_unchanged_during_review": hashes_stable,
        "discharge_component_count": len(shapes),
        "all_discharge_solids_valid": all_solids_valid,
        "collision_volume_reporting_threshold_mm3": collision_tolerance_mm3,
        "gate_axis": {"axis": "z", "pivot_mm": pivot, "review_angle_rad": review_angle,
                      "balance_angle_rad": balance_angle,
                      "neutral_is_feed_state": False},
        "gate_sweep": {"method": "37 rigid blade poses across the source-declared stable angle interval. Exact BRep intersection per pose.",
                       "intentional_mating_pairs": intentional_mating_pairs,
                       "cases": sweep_rows},
        "continuous_gate_sweep_bound": {
            "method": "Radial sector from pivot to tip across the entire angle interval, expanded by half-thickness, with an invariant root-stub cylinder if needed. A source-derived coaxial upper cone clips any conical underside. Rotation invariance preserves a conservative bound; analytic rotated XY extrema tighten its box and 37 additional source-solid containment checks verify implementation.",
            "radial_length_mm": radius_to_tip,
            "root_stub_invariant_cylinder_radius_mm": root_stub_radius,
            "conical_underside_constraint": cone_bound,
            "analytic_rotated_xy_limits_mm": xy_limits,
            "source_blade_volume_outside_convex_xy_footprint_mm3": outside_footprint,
            "sampled_bound_containment": bound_containment,
            "xy_expansion_mm": half_thickness,
            "blade_pose_interval_rad": [min(angles), max(angles)],
            "sector_azimuth_interval_rad": [low_angle, high_angle],
            "neutral_blade_azimuth_rad": radial_direction,
            "z_interval_mm": blade_z_interval,
            "bound_solid_valid": sector.isValid(),
            "collisions": continuous_collisions,
            "nearest_nonshaft_discharge_solid": continuous_nearest,
            "continuous_geometric_clearance_bounded": sector.isValid() and not continuous_collisions,
            "excluded_intentional_mating_pairs": intentional_mating_pairs
        },
        "route_corridors": {"method": "Union coverage of radius-8 mm cylinders along every polyline segment and full spheres at all route vertices; each component independently tested against all discharge solids with the matching blade pose. Volumes are not additive because capsule components overlap.",
                            "cases": route_rows},
        "ground_contacts": ground_contacts,
        "post_to_foot_connections": post_connections,
        "limitations": [
            "The continuous check uses a conservative bound on ideal rigid blade motion; manufacturing tolerances, flex and actuator overtravel are excluded.",
            "An 8 mm spherical clearance envelope is a selected visualization check, not the maximum size, shape or orientation of admitted WEEE feed.",
            "Routes are chosen polylines, not measured or simulated ballistic, contact, pneumatic or chute-flow trajectories.",
            "These five centerline corridor cases do not establish full-width capture or gate branch closure. See full_width_routing_review.json for its separate geometric scope.",
            "No friction, bounce, bridging, dwell time, grouping quality, gate cycle time, fail-to-review behaviour or sorting performance is validated.",
            "Neutral blade position is an inhibited transition configuration, not an operating feed state.",
            "This discharge-only check does not establish complete-machine interference clearance, structural sufficiency, compliant guarding or any certified safety function."
        ]
    }
    output = ROOT / "verification" / "discharge_independent_review.json"
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"status": report["status"], "source_sha256": input_hashes,
                      "gate_collision_cases": sum(bool(row["collisions"]) for row in sweep_rows),
                      "continuous_sweep_bound_collisions": len(continuous_collisions),
                      "route_collision_cases": sum(bool(row["collisions"]) for row in route_rows),
                      "ground_contacts": len(ground_contacts), "post_connections": len(post_connections)}, indent=2))
    for kind, rows in (("gate", sweep_rows), ("route", route_rows)):
        for row in rows:
            if row["collisions"]:
                print(json.dumps({"kind": kind, **row}))


if __name__ == "__main__":
    main()
