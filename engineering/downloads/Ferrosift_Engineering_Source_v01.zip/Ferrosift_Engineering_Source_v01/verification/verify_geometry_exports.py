"""Verify this candidate's indexed CAD/STEP/GLB/web exports and review identity.

Checks are geometric/data-consistency evidence only, not physical validation.
"""
from datetime import datetime, timezone
from pathlib import Path
import hashlib,json,struct
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
receipt=read(ROOT/'verification/cad_export_validation.json')
manifest=read(ROOT/'exports/assembly_manifest.json')
web=read(ROOT/'web/conveyor-assembly.json')
count=manifest['part_count']
assert receipt['status']=='passed' and count>380
assert manifest['release_id']==receipt['release_id']=='investor_package_20261014_v01'
assert receipt['source_unchanged_during_build']
for name,h in receipt['input_sha256'].items():assert sha(ROOT/name)==h,name
step_hash=sha(ROOT/'exports/conveyor_assembly.step')
assert step_hash==manifest['step_sha256']==web['provenance']['stepSha256']
assert sha(ROOT/'design_basis/parameters.json')==manifest['parameters_sha256']
assert len({p['id'] for p in manifest['parts']})==count
for name,h in receipt['source_sha256'].items():assert sha(ROOT/'cad'/name)==h, name
for name,r in receipt['files'].items():
    assert sha(ROOT/('web' if name.endswith('.json') else 'exports')/name)==r['sha256'], name
interfaces=read(ROOT/'verification/interfaces_review.json')
for name,h in interfaces['source_hashes'].items():assert sha(ROOT/'cad'/name)==h,name
assert interfaces['overall_geometric_status']=='PASS'
discharge=read(ROOT/'verification/discharge_independent_review.json')
for name,h in discharge['source_sha256'].items():assert sha(ROOT/name)==h,name
assert discharge['source_unchanged_during_review']
assert discharge['status']=='passed_geometric_checks'

raw=(ROOT/'exports/conveyor_assembly.glb').read_bytes()
magic,version,total=struct.unpack_from('<4sII',raw)
assert magic==b'glTF' and version==2 and total==len(raw)
n,kind=struct.unpack_from('<I4s',raw,12);assert kind==b'JSON'
g=json.loads(raw[20:20+n]);off=20+n
nn,kind=struct.unpack_from('<I4s',raw,off);assert kind==b'BIN\0'
binary=raw[off+8:off+8+nn]
assert len(g['nodes'])==len(g['meshes'])==len(web['objects'])==count

def accessor(i):
    a=g['accessors'][i];v=g['bufferViews'][a['bufferView']]
    k={'VEC3':3,'SCALAR':1}[a['type']]
    return np.frombuffer(binary,dtype={5126:'<f4',5125:'<u4'}[a['componentType']],count=a['count']*k,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape((-1,k))

max_error=0;triangles=0;vertices=0;min_normal_agreement=1.;min_normal_length=1.;max_normal_length=1.
for i,ob in enumerate(web['objects']):
    node=g['nodes'][i];assert node['name']==ob['id']
    p=g['meshes'][node['mesh']]['primitives'][0]
    pos=accessor(p['attributes']['POSITION']);norm=accessor(p['attributes']['NORMAL']);ind=accessor(p['indices']).ravel()
    source=np.asarray(ob['vertices']).reshape((-1,3));source_n=np.asarray(ob['normals']).reshape((-1,3))
    expected=np.column_stack((source[:,0],source[:,2],-source[:,1]))*.001
    max_error=max(max_error,float(np.abs(expected-pos).max()));assert max_error<1e-6
    assert np.isfinite(pos).all() and np.isfinite(norm).all() and ind.max()<len(pos)
    assert np.array_equal(ind,np.asarray(ob['indices']))
    lengths=np.linalg.norm(norm,axis=1)
    assert np.max(np.abs(lengths-1))<2e-6,ob['id']
    min_normal_length=min(min_normal_length,float(lengths.min()));max_normal_length=max(max_normal_length,float(lengths.max()))
    t=ind.reshape((-1,3));v=source[t]
    area=np.cross(v[:,1]-v[:,0],v[:,2]-v[:,0]);area_length=np.linalg.norm(area,axis=1)
    assert (area_length>1e-8).all(),ob['id']
    agreement=(area*source_n[t].mean(axis=1)).sum(axis=1)/area_length
    min_normal_agreement=min(min_normal_agreement,float(agreement.min()))
    assert agreement.min()>0,('Reversed normal',ob['id'],float(agreement.min()))
    triangles+=len(ind)//3;vertices+=len(pos)
assert triangles==receipt['triangle_count'] and vertices==receipt['vertex_count']

by={p['id']:p for p in web['objects']}
for ident in ('depth_optional_housing','depth_optional_mount','depth_optional_front'):
    assert by[ident]['optional'] is True and by[ident]['installed'] is False and by[ident]['default_hidden'] is True
assert set(web['routes'])=={'target','balance','review'}
variant=read(ROOT/'verification/parameter_variant_620.json')
assert variant['components']==count and variant['all_valid'] and variant['belt_width_input']==620
assert any(abs(p['bbox']['max'][1]-p['bbox']['min'][1]-620)<1e-5 for p in variant['parts'])
report={'status':'PASS','release_id':manifest['release_id'],'verified_utc':datetime.now(timezone.utc).isoformat(),'step_sha256':step_hash,'part_count':count,'triangle_count':triangles,'indexed_vertex_count':vertices,'glb_mesh_to_source_max_error_m':max_error,'cad_step_bounds_difference_mm':receipt['bbox_max_difference_mm'],'minimum_winding_to_surface_normal_agreement':min_normal_agreement,'normal_length_range':[min_normal_length,max_normal_length],'parameter_variant_belt_width_mm':620,'all_export_and_review_source_hashes_current':True,'optional_depth_hidden_and_uninstalled':True,'limitations':['Concept geometry and export consistency only. Manufacturing, physical performance and machinery safety remain unverified.','Targeted interface/sweep checks are not an exhaustive assembly or service-safety assessment.','GLB animation extras describe intended motion; they are not a rigid-body or pneumatic simulation.','Drawings, BOM and website require their own recorded validation.']}
(ROOT/'verification/geometry_export_consistency.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
