"""Package editable CAD sources and current geometric evidence, without old assets."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib,json,zipfile

ROOT=Path(__file__).resolve().parents[1]
PACKAGE=ROOT.parent
DELIVERY=PACKAGE/'deliverables';DELIVERY.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
selected=[ROOT/'README.md',ROOT/'requirements.lock.txt']
selected+=sorted((ROOT/'cad').glob('*.py'))+sorted((ROOT/'cad').glob('*.json'))
selected+=sorted(p for p in (ROOT/'design_basis').iterdir() if p.is_file() and p.suffix in ('.py','.json','.md'))
qa_names=[
 'run_interface_review.py','run_discharge_independent_review.py','verify_geometry_exports.py',
 'package_engineering_sources.py','cad_export_validation.json','interfaces_review.json',
 'discharge_independent_review.json','parameter_variant_620.json','geometry_export_consistency.json',
 'numerical_basis_checks.json','repair_source_selfcheck.json','cone_apex_mesh_repair.json','full_width_routing_review_portability.json',
 'render_previews.cjs','static_preview_renderer.js','static_preview_validation.json',
 'run_dynamic_capture_review.py','dynamic_capture_review.json',
]
selected+=[ROOT/'verification'/name for name in qa_names]
selected += sorted((ROOT/'verification').glob('*width*review*.py'))
selected += sorted((ROOT/'verification').glob('*width*review*.json'))
selected += sorted(p for p in (ROOT/'verification/repair_baseline').glob('*') if p.is_file())
selected=list(dict.fromkeys(selected))
for p in selected:assert p.is_file(),p
prefix='Ferrosift_Engineering_Source_v01/'
entries={str(p.relative_to(ROOT)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in selected}
provenance={'release_id':'investor_package_20261014_v01','packaged_utc':datetime.now(timezone.utc).isoformat(),
 'scope':'Editable CAD sources, design basis and executed geometric evidence; STEP/GLB, drawing PDF/SVG, rendered illustrations and website are delivered separately.',
 'geometry_status':'Unvalidated prototype design. No fabrication, procurement, safety or physical-performance approval.',
 'environment':'CadQuery 2.8.0; pinned dependencies in requirements.lock.txt. No virtual environment or downloaded dependency is included.',
 'rebuild':'Follow README.md. Rebuild before rerunning export checks; STEP timestamp metadata may change hashes. Included QA receipts record this frozen build, not a future changed source.',
 'files':entries}
output=DELIVERY/'Ferrosift_Engineering_Source_v01.zip'
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in selected:z.write(p,prefix+str(p.relative_to(ROOT)))
 z.writestr(prefix+'PROVENANCE.json',json.dumps(provenance,indent=2)+'\n')
with zipfile.ZipFile(output) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(selected)+1
 for name,entry in entries.items():assert hashlib.sha256(z.read(prefix+name)).hexdigest()==entry['sha256']
 assert not any('__pycache__' in n or '.venv' in n or n.endswith('.pyc') for n in z.namelist())
export_paths=[ROOT/'exports/conveyor_assembly.step',ROOT/'exports/conveyor_assembly.brep',ROOT/'exports/conveyor_assembly.glb',ROOT/'exports/assembly_manifest.json',ROOT/'web/conveyor-assembly.json']
images=sorted((ROOT/'verification/previews').glob('*.png'))
current_assembly=json.loads((ROOT/'exports/assembly_manifest.json').read_text())
current_export=json.loads((ROOT/'verification/cad_export_validation.json').read_text())
manifest={'release_id':provenance['release_id'],'frozen_utc':provenance['packaged_utc'],'part_count':current_assembly['part_count'],'triangle_count':current_export['triangle_count'],
 'coordinate_contract':{'native':'mm; x travel, y transverse, z up','glb':'metres; x travel, y up, z=-native_y','web_schemaVersion':1,'web_schema':'Existing object IDs/categories/routes retained; indexed vertex arrays with per-vertex source-surface normals.'},
 'sources_archive':{'path':str(output.relative_to(PACKAGE)),'bytes':output.stat().st_size,'sha256':sha(output),'file_count':len(selected)+1,'zip_integrity':'PASS'},
 'exports':[{'path':str(p.relative_to(PACKAGE)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in export_paths],
 'portable_images':[{'path':str(p.relative_to(PACKAGE)),'width':2400,'height':1440,'bytes':p.stat().st_size,'sha256':sha(p)} for p in images],
 'qa':['engineering/verification/geometry_export_consistency.json','engineering/verification/cad_export_validation.json','engineering/verification/interfaces_review.json','engineering/verification/discharge_independent_review.json','engineering/verification/numerical_basis_checks.json','engineering/verification/static_preview_validation.json'],
 'open_design_holds':'engineering/design_basis/design_freeze.json',
 'claims_boundary':'All checks are limited to stated geometric/numerical/export scopes. No physical hardware, sorting performance, safety, certification or operating capacity was validated.',
 'handoff':'Use exports with this exact web mesh and current candidate drawings. Preserve predecessor public af611cd and old engineering release separately. Drawing/BOM/browser verification are separate workstreams.'}
(ROOT/'integration_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(ROOT/'verification/source_archive_verification.json').write_text(json.dumps({'status':'PASS',**manifest['sources_archive'],'verified_entries':entries,'excluded':['virtual environments','bytecode','old frozen CAD/PDF/ZIP files','model weights','training data','unexecuted Fusion probe','legacy frozen-release scripts']},indent=2)+'\n')
print(json.dumps({'archive':manifest['sources_archive'],'exports':manifest['exports']},indent=2))
