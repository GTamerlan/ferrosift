#!/usr/bin/env python3
"""Check issued PDF, ten SVG sources and every rendered page; retain QA evidence."""
from pathlib import Path
import argparse, hashlib, json
import fitz

ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--visual-reviewed',action='store_true',help='Use only after inspecting all current page PNGs')
    args=ap.parse_args()
    path=ROOT/'Ferrosift_Investor_Engineering_Drawings_IR01.pdf';doc=fitz.open(path)
    manifest=json.loads((ROOT.parent/'exports/assembly_manifest.json').read_text())
    pages=[];failures=[]
    if len(doc)!=10:failures.append('PDF does not contain ten pages')
    for i,page in enumerate(doc):
        text=page.get_text(); spans=[]
        for block in page.get_text('dict')['blocks']:
            for line in block.get('lines',[]):spans+=line.get('spans',[])
        bad=[]
        for span in spans:
            bb=fitz.Rect(span['bbox'])
            if not page.rect.contains(bb):bad.append({'text':span['text'],'bbox':list(bb)})
        if bad:failures.append(f'Page {i+1}: text outside media box')
        for marker in ('CONCEPT ONLY','NOT FOR FABRICATION','INVESTOR DESIGN REVIEW'):
            if marker not in text:failures.append(f'Page {i+1}: missing {marker}')
        for marker in (manifest['step_sha256'][:16],f"{manifest['part_count']} part instances"):
            if marker not in text:failures.append(f'Page {i+1}: source footer missing {marker}')
        png=ROOT/'previews'/f'FS-CV-{i+1:02d}.png';svg=ROOT/f'FS-CV-{i+1:02d}.svg'
        for f in (png,svg):
            if not f.exists():failures.append(f'Missing {f.name}')
        pages.append({'sheet':i+1,'width_pt':page.rect.width,'height_pt':page.rect.height,
          'text_spans':len(spans),'text_outside_media_box':bad,
          'smallest_text_size_pt':min(s['size'] for s in spans),
          'svg_sha256':sha(svg),'render_png_sha256':sha(png),
          'visual_review':'PASS - current page rendered and inspected' if args.visual_reviewed else 'UNVERIFIED'})
    for name in ('sensor_section_a','sensor_section_b','routing_section_c','routing_section_d'):
        section=json.loads((ROOT/'projections'/f'{name}.json').read_text())
        if not section.get('section_face_count',0) or not section.get('fill_triangles'):failures.append('Missing actual section geometry: '+name)
        if name.startswith('sensor_section'):
            for feature,z0,z1 in [('belt',994,1000),('nonmetallic window',988,994),('cassette tray',780,976)]:
                found=any(abs(c['bbox_mm']['min'][2]-z0)<1e-4 and abs(c['bbox_mm']['max'][2]-z1)<1e-4 for c in section['section_contributions'])
                if not found:failures.append(f'{name}: missing actual {feature} cross-section')
        if name=='routing_section_d':
            # Require the real 660 mm inlet floor section at the leading edge,
            # not merely an overall assembly bounding box or a text label.
            found=any(abs(c['bbox_mm']['min'][1]+330)<1e-4 and abs(c['bbox_mm']['max'][1]-330)<1e-4
                and abs(c['bbox_mm']['min'][2]-820)<1e-4 and abs(c['bbox_mm']['max'][2]-823)<1e-4
                for c in section['section_contributions'])
            if not found:failures.append('D-D: missing exact 660 mm concentrate inlet floor cut at z820..823')
    bom=json.loads((ROOT.parent/'bom/bom_and_assumptions.json').read_text())
    if bom['part_instances']!=manifest['part_count']:failures.append('BOM count mismatch')
    if sum(g['modeled_part_instances'] for g in bom['groups'])!=manifest['part_count']:failures.append('BOM group mismatch')
    text='\n'.join(p.get_text() for p in doc)
    for token in ['400 CAMERA FOV EXAMPLE','600 NOMINAL BELT','1750','1775','1250','16.7','33.3','66.7','0.625','transition position','withdraw locating pins','disconnect connectors','engineered isolation','660 CONCENTRATE INLET','136 mm','260 mm','D-D / x3610','nominal contact']:
        if token not in text:failures.append('Missing required dimension/caution: '+token)
    result={'status':'PASS' if not failures and args.visual_reviewed else 'FAIL' if failures else 'UNVERIFIED',
      'pdf_sha256':sha(path),'page_count':len(doc),'pages':pages,'failures':failures,
      'projection_method':'Exact visible-edge OpenCascade HLR and solid-plane intersections from checked generated STEP sources',
      'verified_scope':'PDF/vector layout, stated basis, print scale and source traceability',
      'unverified_scope':['structural adequacy','mechanical safety','sensor response/coverage','pneumatic/ejection performance','chute flow and gate timing','production fabrication readiness']}
    (ROOT/'drawing_layout_qa.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'pages':len(doc),'failures':failures},indent=2))
    if failures:raise SystemExit(1)
    if args.visual_reviewed:
        q=ROOT/'drawing_verification.json';info=json.loads(q.read_text())
        info['checks']['visual_layout_review']='PASS - all ten current PNG pages inspected'
        info['layout_qa_sha256']=sha(ROOT/'drawing_layout_qa.json')
        q.write_text(json.dumps(info,indent=2)+'\n')

if __name__=='__main__':main()
