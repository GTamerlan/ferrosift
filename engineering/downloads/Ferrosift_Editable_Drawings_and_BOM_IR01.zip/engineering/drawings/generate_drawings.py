#!/usr/bin/env python3
"""Compose A3 concept drawings from cached exact STEP projections.

Requires project_views.py outputs. SVGs stay editable vector source; PDF is generated
from the same pages. Dimensions are CAD/source millimetres. No approved fabrication tolerance,
structural rating, detection coverage or measured performance is implied.
"""
from pathlib import Path
from collections import Counter
import hashlib, html, json, math, re, textwrap, csv
import fitz

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'drawings'; PROJ=OUT/'projections'
INK='#17282d'; MUTED='#52686f'; TEAL='#087f80'; LIGHT='#d6e1e4'; PALE='#edf5f5'; AMBER='#a35b12'
FONT='Arial,Helvetica,sans-serif'
P=json.loads((ROOT/'design_basis/parameters.json').read_text())
G=P['geometry_mm']; B=G['belt']; S=G['sensing']; H=G['optical_hood']; C=G['induction_cassette']
CAL=json.loads((ROOT/'design_basis/calculations.json').read_text()) if (ROOT/'design_basis/calculations.json').exists() else None
MAN=json.loads((ROOT/'exports/assembly_manifest.json').read_text())
DISCHARGE=json.loads((ROOT/'cad/discharge_geometry_contract.json').read_text())
PARTS=MAN['parts']
SHEETS=[]; CHECKS=[]
SHEET_COUNT=10

def esc(t):return html.escape(str(t))
def n(v):return f'{v:.3f}'.rstrip('0').rstrip('.') if isinstance(v,float) else str(v)
def bpoints(part):
    bb=part['bbox'];return bb['min'],bb['max']
def bounds(parts):
    coords=[bpoints(p) for p in parts]
    return [min(v[0][i] for v in coords) for i in range(3)], [max(v[1][i] for v in coords) for i in range(3)]
def catparts(*cats):return [p for p in PARTS if p['category'] in cats]
def findparts(s):return [p for p in PARTS if s.lower() in (p['id']+' '+p['name']).lower()]
def part(ident):return next(p for p in PARTS if p['id']==ident)
def center(ident):
    lo,hi=bpoints(part(ident));return [(a+b)/2 for a,b in zip(lo,hi)]
def norm(v):
    l=math.sqrt(sum(x*x for x in v));return [x/l for x in v]
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def dot(a,b):return sum(x*y for x,y in zip(a,b))

class Page:
    def __init__(self,num,title,subtitle):
        self.num=num;self.title=title;self.a=[]
        self.a.append('<svg xmlns="http://www.w3.org/2000/svg" width="420mm" height="297mm" viewBox="0 0 420 297">')
        self.a.append(f'<metadata>Ferrosift investor review v01; model-derived HLR and solid sections; geometry mm; A3 landscape; {esc(title)}</metadata>')
        self.rect(0,0,420,297,'#fff');self.rect(8,8,404,281,'none',LIGHT,.25)
        self.text(14,16,'FERROSIFT / ENGINEERING',3.7,TEAL,bold=True)
        self.text(14,25,title,6.0,INK,bold=True)
        self.text(14,32,subtitle,2.6,MUTED)
        self.text(406,16,'CONCEPT ONLY',3.4,AMBER,bold=True,anchor='end')
        self.text(406,22,'NOT FOR FABRICATION',2.7,AMBER,bold=True,anchor='end')
        self.line(14,36,406,36,TEAL,.6)
    def text(self,x,y,t,size=2.9,color=INK,bold=False,anchor='start',rotation=None):
        transform=f' transform="rotate({rotation} {x} {y})"' if rotation else ''
        self.a.append(f'<text x="{x}" y="{y}" font-family="{FONT}" font-size="{size}" font-weight="{700 if bold else 400}" fill="{color}" text-anchor="{anchor}"{transform}>{esc(t)}</text>')
    def line(self,x1,y1,x2,y2,color=INK,width=.25,dash=None):
        if dash:
            # Explicit vector segments preserve dashes in SVG-to-PDF renderers
            # which otherwise discard SVG stroke-dasharray attributes.
            on,off=[float(x) for x in dash.split()];length=math.hypot(x2-x1,y2-y1)
            if not length:return
            d=0
            while d<length:
                end=min(length,d+on)
                self.line(x1+(x2-x1)*d/length,y1+(y2-y1)*d/length,
                          x1+(x2-x1)*end/length,y1+(y2-y1)*end/length,color,width)
                d+=on+off
            return
        self.a.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="{width}"/>')
    def rect(self,x,y,w,h,fill='none',stroke=None,width=.25,dash=None):
        if dash:
            self.rect(x,y,w,h,fill)
            for a,b in [((x,y),(x+w,y)),((x+w,y),(x+w,y+h)),((x+w,y+h),(x,y+h)),((x,y+h),(x,y))]:self.line(*a,*b,stroke or INK,width,dash)
            return
        self.a.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}" stroke="{stroke or "none"}" stroke-width="{width}"/>')
    def circle(self,x,y,r,fill='none',stroke=INK,width=.25):
        self.a.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{width}"/>')
    def polygon(self,points,fill,stroke=None,width=.25):
        pts=' '.join(f'{x},{y}' for x,y in points)
        self.a.append(f'<polygon points="{pts}" fill="{fill}" stroke="{stroke or "none"}" stroke-width="{width}"/>')
    def paragraph(self,x,y,t,width=80,size=2.8,color=MUTED,lineheight=4.3):
        # Conservative character estimate for Helvetica; no clipping/ellipsis.
        chars=max(12,int(width/(size*.53)))
        lines=[]
        for para in str(t).split('\n'):
            lines+=textwrap.wrap(para,width=chars,break_long_words=False,break_on_hyphens=False) or ['']
        for i,line in enumerate(lines):self.text(x,y+i*lineheight,line,size,color)
        return y+len(lines)*lineheight
    def note(self,x,y,w,title,body):
        self.text(x,y,title,3.1,TEAL,bold=True)
        return self.paragraph(x,y+5,body,w)+3
    def arrow(self,x1,y1,x2,y2,color=TEAL,width=.45):
        self.line(x1,y1,x2,y2,color,width)
        angle=math.atan2(y2-y1,x2-x1);s=2
        self.polygon([(x2,y2),(x2-s*math.cos(angle-.5),y2-s*math.sin(angle-.5)),(x2-s*math.cos(angle+.5),y2-s*math.sin(angle+.5))],color)
    def dimh(self,x1,x2,y,ay1,ay2,label,color=INK):
        self.line(x1,ay1,x1,y+(1 if y>ay1 else -1),LIGHT,.2)
        self.line(x2,ay2,x2,y+(1 if y>ay2 else -1),LIGHT,.2)
        self.line(x1,y,x2,y,color,.2)
        for x,sign in ((x1,1),(x2,-1)):
            self.polygon([(x,y),(x+sign*1.6,y-.5),(x+sign*1.6,y+.5)],color)
        self.text((x1+x2)/2,y-1.3,label,2.7,color,anchor='middle')
    def dimv(self,y1,y2,x,ax1,ax2,label,color=INK):
        self.line(ax1,y1,x-1,y1,LIGHT,.2);self.line(ax2,y2,x-1,y2,LIGHT,.2)
        self.line(x,y1,x,y2,color,.2)
        for y,sign in ((y1,1),(y2,-1)):
            self.polygon([(x,y),(x-.5,y+sign*1.6),(x+.5,y+sign*1.6)],color)
        self.text(x-1.5,(y1+y2)/2,label,2.7,color,anchor='middle',rotation=-90)
    def leader(self,x,y,tx,ty,label,color=TEAL):
        self.circle(x,y,.6,color,color);self.line(x,y,tx,ty-1,color,.2)
        self.text(tx+1,ty,label,2.7,color)
    def table(self,x,y,width,headers,rows,colwidths=None,rowh=7,size=2.7):
        cs=colwidths or [width/len(headers)]*len(headers)
        self.rect(x,y,width,rowh,PALE)
        xx=x
        for h,w in zip(headers,cs):self.text(xx+2,y+rowh*.67,h,size,TEAL,bold=True);xx+=w
        for i,row in enumerate(rows):
            yy=y+rowh*(i+1);self.line(x,yy,x+width,yy,LIGHT,.2);xx=x
            for v,w in zip(row,cs):self.text(xx+2,yy+rowh*.67,v,size,INK);xx+=w
        self.line(x,y+rowh*(len(rows)+1),x+width,y+rowh*(len(rows)+1),LIGHT,.2)
        return y+rowh*(len(rows)+1)
    def view(self,name,box,denom=None,caption=None):
        d=json.loads((PROJ/f'{name}.json').read_text());l,b,r,t=d['bounds'];x,y,w,h=box
        if denom is None:
            need=max((r-l)/w,(t-b)/h)
            denom=next(v for v in [2,5,10,15,20,25,30,40,50,75,100] if v>=need)
        scale=1/denom;dw=(r-l)*scale;dh=(t-b)*scale
        ox=x+(w-dw)/2-l*scale;oy=y+(h-dh)/2+t*scale
        if dw>w+.01 or dh>h+.01:raise ValueError(f'{name} exceeds allocated viewport: {dw}x{dh}, {w}x{h}')
        self.a.append(f'<g transform="translate({ox},{oy}) scale({scale}, {-scale})" fill="none" stroke="{INK}" stroke-width="{.22/scale}" stroke-linecap="round" stroke-linejoin="round">')
        for triangle in d.get('fill_triangles',[]):
            pts=' '.join(f'{px},{py}' for px,py in triangle)
            self.a.append(f'<polygon points="{pts}" fill="#d8eceb" stroke="none"/>')
        self.a.extend(f'<path d="{p}"/>' for p in d['paths']);self.a.append('</g>')
        label=caption or name.upper().replace('_',' ')
        if 'not to scale' not in label.lower() and 'no manufacturing scale' not in label.lower():label+=f' / 1:{denom}'
        self.text(x,y+h+5,label,2.7,TEAL,bold=True)
        CHECKS.append({'sheet':self.num,'view':name,'scale_denominator':denom,'viewport_mm':box,'projected_size_mm':[dw,dh],'projection_input_sha256':d['input_sha256']})
        normal=norm(d['normal']);vx=norm(d['x_direction']);vy=cross(normal,vx)
        def mapping(p):return ox+dot(p,vx)*scale,oy-dot(p,vy)*scale
        mapping.scale=scale;mapping.ox=ox;mapping.oy=oy;mapping.denom=denom
        return mapping
    def finish(self):
        self.line(14,263,406,263,TEAL,.5)
        self.text(14,270,'DIMENSIONS: mm  |  SCALE: PER VIEW AT A3  |  DO NOT SCALE FOR MANUFACTURE',2.7,INK,bold=True)
        self.text(14,276,'Preliminary study geometry. Proposed inspection targets on sheet 8 are unapproved; no load, sensing or safety rating.',2.6,MUTED)
        self.text(14,282,f'Source: conveyor_assembly.step | SHA-256 {MAN["step_sha256"][:16]} | {len(PARTS)} part instances | basis 2026-10-14',2.5,MUTED)
        self.text(405,270,f'FS-CV-{self.num:02d}',4,INK,bold=True,anchor='end')
        self.text(405,276,f'REV IR-01  /  2026-10-14  /  {self.num} OF {SHEET_COUNT}',2.8,MUTED,anchor='end')
        self.text(405,282,'INVESTOR DESIGN REVIEW',2.5,AMBER,bold=True,anchor='end')
        self.a.append('</svg>');path=OUT/f'FS-CV-{self.num:02d}.svg';path.write_text('\n'.join(self.a));SHEETS.append(path)

def overall():
    p=Page(1,'General arrangement','Proposed PCB-rich recovery module / depolluted, liberated, dry screened WEEE / geometry only')
    side=p.view('ga_side',(22,62,274,83),caption='SIDE / actual assembly, covers retained / scale per drawing')
    x0,z0=side((0,0,0));xl,zl=side((3000,0,1000));xf,zf=side((-1400,0,1000))
    a=side((0,0,1000));b=side((3000,0,1000))
    p.dimh(a[0],b[0],48,a[1],b[1],'3000 INLET DATUM TO LIP')
    p.dimh(xf,a[0],56,zf,a[1],'1400 FEED ENVELOPE')
    p.dimv(side((0,0,1000))[1],z0,18,a[0],x0,'1000 BELT TOP')
    p.arrow(a[0]+5,a[1]-7,b[0]-5,a[1]-7)
    p.text((a[0]+b[0])/2,a[1]-10,'BELT TRAVEL +X',2.8,TEAL,anchor='middle')
    p.text(22,156,f'Side scale 1:{side.denom}; nominal floor z=0. Feed and discharge hardware are concept selections.',2.7,MUTED)
    plan=p.view('ga_plan',(22,182,274,65),caption='PLAN / same solid assembly, orthographic +Z view')
    aa=plan((0,-300,1000));bb=plan((0,300,1000))
    p.dimv(bb[1],aa[1],aa[0]-8,aa[0],aa[0],'600 BELT')
    x=310;y=45
    y=p.note(x,y,92,'DESIGN INTENT','One airjet target/balance split; a separate balance-path gate diverts conservative review windows.')
    y=p.note(x,y,92,'COORDINATE DATUMS','x follows belt travel; y is transverse; z is height above floor. Inlet x=0 and lip x=3000 are provisional coordination datums.')
    y=p.table(x,y+1,92,['Station','x (mm)'],[['RGB centre','1300'],['Induction centre','1600'],['Last active datum','1750'],['Cassette edge','1775'],['Discharge lip','3000']],[66,26],rowh=7)
    y=p.note(x,y+9,92,'KEEP THESE DISTINCT','The sensing datum is 25 mm before the enclosure edge. The 1250 mm tracking distance starts at x=1750, not x=1775.')
    p.note(x,y,92,'DRAWING STATUS','STEP-derived views show packaging and mechanical intent. Strength, wear, drive sizing, guarding and component selection remain open.')
    p.finish()

def sensing():
    p=Page(2,'Sensing cell and coverage','Adjustable RGB and induction envelopes / optional depth device is unbuilt / opaque hood panels omitted')
    v=p.view('sensor_side',(23,64,176,125),caption='SENSOR SIDE / selected physical solids, covers omitted')
    def hdim(x1,x2,z,y,label):
        a=v((x1,0,z));b=v((x2,0,z));p.dimh(a[0],b[0],y,a[1],b[1],label)
    hdim(1050,1950,1850,50,'900 HOOD LENGTH')
    fov_a=v((1150,0,1000));fov_b=v((1450,0,1000))
    p.line(*fov_a,*fov_b,TEAL,1.1)
    hdim(1150,1450,1000,58,'300 FOV EXAMPLE')
    hdim(1425,1775,780,202,'350 CASSETTE LENGTH')
    a=v((1775,0,980));b=v((1775,0,780));p.dimv(a[1],b[1],195,a[0],b[0],'200 HOUSING')
    cut=v((1600,0,1000));p.line(cut[0],70,cut[0],190,AMBER,.25,'3 1');p.text(cut[0]+2,67,'A-A / SHEET 6',2.6,AMBER)
    last=v((1750,0,1000));p.line(last[0],58,last[0],194,TEAL,.3,'2 1')
    p.text(last[0]+2,62,'x1750 LAST DATUM',2.7,TEAL)
    p.note(23,213,176,'CONDITIONAL CASSETTE REMOVAL','Remove the left access panel, withdraw locating pins and disconnect connectors. Reserve an engineered isolation procedure. This drawing checks clearance only, not safe servicing.')
    p.note(23,237,176,'LIFT-OFF IS NOT THIS HOUSING GAP','Selected housing-to-window gap: 8 mm, packaging only. Coil plane, belt/window effects and object shape require calibration.')
    end=p.view('sensor_end',(226,61,167,128),caption='TRANSVERSE VIEW / sensor selection, viewed along +X')
    left=end((1600,-300,1000));right=end((1600,300,1000))
    p.dimh(left[0],right[0],201,left[1],right[1],'600 NOMINAL BELT')
    f1=end((1300,-200,1000));f2=end((1300,200,1000))
    p.line(f1[0],f1[1]-1,f2[0],f2[1]-1,TEAL,1.2)
    p.dimh(f1[0],f2[0],213,f1[1],f2[1],'400 CAMERA FOV EXAMPLE',TEAL)
    p.note(224,227,180,'COVERAGE REQUIRES CALIBRATION','400 mm optical coverage is an example, not full 600 mm belt coverage. The separate 500 mm effective-width calculation is an assumption. Usable sensing width is TBD.')
    p.finish()

def base():
    p=Page(3,'Belt path, support and drive','Selected mechanical layout / covers removed for visibility / sizes are not strength-checked')
    v=p.view('base_side',(27,65,257,78),caption='BELT / FRAME / DRIVE SIDE / guards omitted from this view')
    a=v((0,0,944));b=v((3000,0,944));p.dimh(a[0],b[0],50,a[1],b[1],'3000 MAIN DRUM CENTRES')
    a=v((350,0,570));b=v((2650,0,570));p.dimh(a[0],b[0],156,a[1],b[1],'2300 LOWER IDLER CENTRES')
    floor=v((0,0,0));top=v((0,0,1000));p.dimv(top[1],floor[1],18,top[0],floor[0],'1000')
    v2=p.view('base_iso',(26,181,258,66),caption='BASE ISOMETRIC / actual CAD solids / no manufacturing scale')
    x=306;y=46
    y=p.note(x,y,96,'BELT PATH SELECTION','Main drums: diameter 100, centres z=944. Belt thickness 6. Lower idlers: diameter 80, centres z=570. Lower belt outer bottom z=524.')
    y=p.note(x,y,96,'SENSOR KEEP-OUT','The lowered return run clears the induction housing at z=780..980. The nonconductive window spans x=1350..1850; placeholder thickness 6 requires deflection and wear tests.')
    y=p.note(x,y,96,'DRIVE AND TENSION','Motor, gearbox, bearings, shafts, tension screws and mounts are modeled packaging selections. Motor torque, belt tension, tracking authority and bearing life are not calculated.')
    y=p.note(x,y,96,'RELEASE INPUTS','Define maximum piece mass, impact/load cases, belt construction and joint, roller crown, shaft/bearing fits, drive duty and restart torque before detailing fabrication.')
    p.note(x,y,96,'PROTECTION','Guard and access-panel geometry is a concept allowance. Nip clearances, interlocks, isolation, emergency functions and dust controls require a competent machinery review.')
    p.finish()

def routing():
    p=Page(4,'Full-width capture and review routing','Repaired collection geometry / one proposed airjet split plus downstream balance-window gate / no measured flow claim')
    side=p.view('routing_side',(24,64,181,102),caption='DISCHARGE SIDE / selected solids, protective shell omitted')
    plan=p.view('routing_plan',(230,64,171,102),caption='DISCHARGE PLAN / physical chute and collection layout')
    for v in (side,plan):
        a=v((3000,0,1000));p.line(a[0],51,a[0],170,TEAL,.25,'2 1');p.text(a[0]+2,56,'x3000 LIP',2.8,TEAL)
    packet=json.loads((ROOT/'web/conveyor-assembly.json').read_text())
    routes=list(packet['routes'].values())
    for v in (side,plan):
        for pts in routes:
            for aa,bb in zip(pts,pts[1:]):
                a=v(aa);b=v(bb);p.line(*a,*b,TEAL,.5,'2 1.4')
    for ident,label in [('bin_balance','BALANCE'),('bin_concentrate','PCB-RICH'),('bin_review','REVIEW')]:
        xx,yy=plan(center(ident));p.text(xx,yy+1,label,2.6,TEAL,bold=True,anchor='middle')
    floor=part('balance_catch_floor');lo,hi=bpoints(floor)
    aa=plan((lo[0],lo[1],hi[2]));bb=plan((lo[0],hi[1],hi[2]))
    p.dimv(min(aa[1],bb[1]),max(aa[1],bb[1]),aa[0]-9,aa[0],bb[0],f'{n(round(hi[1]-lo[1],3))} CAPTURE',TEAL)
    p.text(24,176,'Dashed balance/review paths are alternatives; all paths are intent, not measured trajectories.',2.65,TEAL)
    p.note(24,181,178,'TARGET CAPTURE / TRANSVERSE CONVERGENCE','The 660 mm concentrate inlet spans the nominal 600 mm belt and converges to a 260 mm outlet. Sidewalls provide a physical narrowing path; they do not prove friction, rebound, bridging or recovery. Jet impulse and delay remain test inputs.')
    p.note(230,181,171,'BALANCE CAPTURE / GROUP GATE','A 660 mm catch converges to the 136 mm gate approach. The upstream-pointing blade is shown in transition position: no feed permitted. Inhibit feed, drain, command and verify gate position before resuming. See sheet 10.')
    p.rect(24,229,377,25,PALE)
    p.text(28,235,'ROUTING BOUNDARY',3,TEAL,bold=True)
    p.paragraph(28,241,'Review routing may include neighbouring pieces and cannot recover an unknown already ejected into concentrate. Chute bounce prevents exact item-time assumptions. Feed inhibit and a normal review bin are not certified safety functions or battery containment.',368,size=2.75,lineheight=4.2)
    p.finish()

def assembly():
    p=Page(5,'Assembly groups and concept BOM','Exploded arrangement from the same STEP solids / group translation for visibility only')
    v=p.view('exploded',(20,57,227,188),caption='EXPLODED ISOMETRIC / arbitrary separation / not to scale')
    counts=Counter(item['category'] for item in PARTS)
    groups=[('Base, deck and belt',['frame','belt','roller','deck']),('Drive / bearings / fixings',['drive','encoder','bearing','tensioning','fasteners']),
            ('Feeder / spreader',['feeder']),('Hood, light, camera',['hood','light','camera']),
            ('Sensor and window',['sensor','window']),('Airjet and chutes',['airjet','chute']),
            ('Gate and bins',['gate','bin']),('Guards and cable',['guard','cable']),
            ('Controls / research',['controls','research'])]
    defs=json.loads((OUT/'view_definitions.json').read_text())
    offsets=next(d for d in defs if d['name']=='exploded')['offsets']
    balloon_positions=[(115,244),(230,181),(26,209),(119,53),(232,100),(242,142),(237,225),(24,135),(226,58)]
    for i,((_,cats),(tx,ty)) in enumerate(zip(groups,balloon_positions),1):
        group=catparts(*cats);pts=[]
        for part in group:
            lo,hi=bpoints(part);off=offsets.get(part['category'],[0,0,0])
            pts+=[[value[j]+off[j] for j in range(3)] for value in (lo,hi)]
        if not pts:continue
        mid=[(min(p[j] for p in pts)+max(p[j] for p in pts))/2 for j in range(3)]
        cx,cy=v(mid);p.line(cx,cy,tx,ty,TEAL,.2);p.circle(cx,cy,.65,TEAL,TEAL)
        p.circle(tx,ty,3.1,'#fff',TEAL,.35);p.text(tx,ty+.95,f'{i:02}',2.7,TEAL,bold=True,anchor='middle')
    rows=[]
    for i,(name,cats) in enumerate(groups,1):rows.append([f'{i:02}',name,str(sum(counts[c] for c in cats))])
    if sum(int(row[-1]) for row in rows)!=len(PARTS):raise ValueError('BOM grouping omitted a CAD category')
    y=p.table(263,48,139,['No.','Assembly group','Parts'],rows,[14,106,19],rowh=7,size=2.65)
    total=sum(counts.values());p.text(265,y+7,f'{total} modeled part instances; quantities from manifest.',2.7,TEAL,bold=True)
    y=p.note(263,y+17,136,'BOM INTERPRETATION','Counts describe modeled solid part instances, not purchased assemblies. Sensor, actuator and cabinet internals are envelope models. Fixings shown are illustrative; final fastener schedules remain open.')
    y=p.note(263,y,136,'SOURCE TRACEABILITY','The part manifest retains names, categories, bounding boxes and solid volumes. The parametric CadQuery source is the editable design definition. STEP is the checked exchange solid assembly.')
    p.note(263,y,136,'NOT A PROCUREMENT RELEASE','Material grades, finishes, fabrication details, approved vendors, quantities of unmodeled internals, torque values and acceptance tolerances are not specified.')
    p.finish()

def installation():
    p=Page(9,'Installation envelope and trial gates','Layout reservations, ideal kinematics and tests still needed / no rated machine performance')
    v=p.view('ga_plan',(26,78,231,90),denom=40,caption='PLAN / 900 mm side zones from outer equipment')
    lo,hi=bounds(PARTS)
    a=v((lo[0],lo[1]-900,0));b=v((hi[0],hi[1]+900,0));
    left=min(a[0],b[0]);top=min(a[1],b[1]);width=abs(b[0]-a[0]);height=abs(b[1]-a[1])
    p.rect(left,top,width,height,'none',TEAL,.3,'2 1')
    for edge,clear in ((lo[1],lo[1]-900),(hi[1],hi[1]+900)):
        a1=v((lo[0],edge,0));b1=v((lo[0],clear,0));p.dimv(min(a1[1],b1[1]),max(a1[1],b1[1]),left-7,left,left,'900',TEAL)
    p.note(26,181,230,'SERVICE SPACE IS A RESERVATION','Measure side zones from the outer hardware envelope, including projecting cabinet or drive parts. Door, cassette-withdrawal and bin-exchange sweeps need separate site checks. End access, utilities and actual dust-control connections remain to be designed.')
    p.note(26,218,230,'FEED BOUNDARY','Only depolluted, liberated, dry screened WEEE. Run 12.5-25 and 25-50 mm campaigns separately. Exclude batteries, whole devices, hazards, tangles and oversized/heavy pieces; sieve size does not bound length, thickness or mass.')
    x=276;y=46
    p.text(x,y,'IDEAL KINEMATICS',3.3,TEAL,bold=True)
    rows=[]
    for r in CAL['speed_cases']:
        rows.append([n(r['belt_speed_m_s']),f"{r['belt_displacement_per_frame_mm']:.1f}",n(r['travel_times_s']['last_sensing_to_lip'])])
    y=p.table(x,y+5,128,['m/s','mm/frame*','s to lip**'],rows,[30,49,49],rowh=8,size=2.8)
    y=p.paragraph(x,y+6,'* At 30 fps reference. ** 1250 mm / speed. Assumes steady belt speed, no slip or collision. These are calculated values, not latency or throughput evidence.',128)+5
    y=p.note(x,y,128,'PROPOSED TEST RAMP','50-200 kg/h is an experimental ramp, not rated capacity. Begin slow and sparse at 0.5 m/s; 1 m/s is the calculation reference and 2 m/s is an unvalidated study case.')
    y=p.note(x,y,128,'MEASURE BEFORE CLAIMING','Calibrated sensor coverage and lift-off; presentation/overlap; synchronized tracking/latency; ejection scatter and neighbours; chute dwell and gate feedback; balanced mass, purity, recovery and actual buyer value.')
    p.note(x,y,128,'SEPARATE EXISTING EVIDENCE','The recorded steel/copper YOLO demo remains a separate artifact. It is not PCB inference, physical recovery or evidence of this concept\'s profitability.')
    p.finish()
# Proposed metrology targets, deliberately distinct from released tolerances.
TOLERANCES=[
 {'id':'T01','interface':'Frame coordination lengths','nominal':'Per modeled geometry','target':'+/-2 mm','method':'Measure unloaded against datum A/B/C','gate':'Structural/mechanical design approval'},
 {'id':'T02','interface':'Head/tail shaft parallelism','nominal':'Axes parallel in plan','target':'0.3 mm over 600 mm','method':'Indicator or laser alignment, unloaded','gate':'Belt tracking trial under load'},
 {'id':'T03','interface':'Camera bracket repositioning','nominal':'Calibration origin retained','target':'+/-1 mm translation','method':'Fiducial recheck after repositioning','gate':'Pixel-to-belt calibration and blur test'},
 {'id':'T04','interface':'Cassette mount repositioning','nominal':'Repeat measured reference pose','target':'+/-0.5 mm translation','method':'Gauge installed mount reference points','gate':'Response/repeatability versus lift-off'},
 {'id':'T05','interface':'Nonmetallic window flatness','nominal':'600 mm transverse span','target':'0.5 mm unloaded','method':'Straightedge / indicator on test fixture','gate':'Loaded deflection, wear and EMC trial'},
 {'id':'T06','interface':'Shaft/bearing fits and runout','nominal':'Envelope bores only','target':'TBD - no fit released','method':'Vendor drawing and load calculation','gate':'Bearing life, shaft/fit engineering'},
 {'id':'T07','interface':'Nozzles / splitter / chute angles','nominal':'Adjustable study configuration','target':'TBD after sample tests','method':'High-speed measured trajectories','gate':'Recovery at fixed purity/throughput'},
 {'id':'T08','interface':'Guards / interlocks / air isolation','nominal':'Access concept only','target':'TBD after risk review','method':'Competent machinery safety assessment','gate':'Validated protection and procedures'},
]

def sections():
    p=Page(6,'Actual solid sections / sensing interfaces','A-A at x=1600 / B-B at y=0 / tinted regions are exact intersections with exported solids')
    a=p.view('sensor_section_a',(25,64,165,133),denom=10,caption='A-A / transverse plane x1600 / exact solid cut')
    b=p.view('sensor_section_b',(224,64,166,133),denom=10,caption='B-B / longitudinal centre plane y0 / exact solid cut')
    for v,x,yaxis in [(a,18,True),(b,399,False)]:
        lo=v((1600,0,780));hi=v((1600,0,980))
        p.dimv(hi[1],lo[1],x,hi[0],lo[0],'200 HOUSING')
    aa=a((1600,-300,1000));bb=a((1600,300,1000))
    p.dimh(aa[0],bb[0],53,aa[1],bb[1],'600 BELT / WINDOW')
    aa=b((1425,0,780));bb=b((1775,0,780))
    p.dimh(aa[0],bb[0],207,aa[1],bb[1],'350 CASSETTE')
    for label,z,tx,ty in [('Belt top z1000',1000,350,150),('Window z988..994',991,350,174),('Housing top z980',980,350,194)]:
        xx,yy=b((1640,0,z));p.leader(xx,yy,tx,ty,label)
    p.note(25,218,165,'WHAT THE SECTION PROVES','Actual solid intersections expose the belt, support window, cassette shell and mounting interfaces at these planes. The optional depth envelope is unbuilt. A hollow enclosure is not a coil design or validated sensor field.')
    p.note(224,218,177,'KEEP THE MEASUREMENT REGION NONMETALLIC','No steel slider bed is proposed in the reserved sensing region. Nearby steel, wiring, belt constituents and return geometry still require electromagnetic baseline and interference tests.')
    p.finish()

def interfaces():
    p=Page(7,'Drive, tensioning and control interfaces','Localized views from the same solid assembly / preliminary packaging / no selected manufacturer internals')
    a=p.view('drive_detail',(24,63,171,113),denom=5,caption='DRIVE DETAIL / top view / surrounding geometry cropped')
    b=p.view('tension_detail',(227,63,170,113),denom=5,caption='TAIL DETAIL / side view / surrounding geometry cropped')
    m0=a((3000,-720,944));m1=a((3000,-540,944))
    p.dimv(min(m0[1],m1[1]),max(m0[1],m1[1]),19,m0[0],m1[0],'180 MOTOR BODY')
    t0=b((-120,-365,936));t1=b((-20,-365,936))
    p.dimh(t0[0],t1[0],54,t0[1],t1[1],'100 ADJUSTER ENVELOPE')
    y=p.note(24,192,175,'DRIVE + SHAFT ENCODER','The motor, reducer and coupling indicate an installation concept. Encoder feedback is taken at the head shaft; independent belt-slip measurement remains open. Power, reduction, torque, encoder resolution and duty cycle are not selected.')
    p.note(24,y,175,'METROLOGY INTERFACE','Datum A: nominal floor z0. B: belt centre plane y0. C: inlet plane x0. Map sensor data to the belt frame; keep camera extrinsics and the final sensing datum in the same measured coordinate system.')
    y=p.note(226,192,177,'TENSION + TRACKING','Slotted tail bearing mounts and threaded-adjuster envelopes allow a study of adjustment. The modeled screw is not a thread specification. Usable stroke, locking, pretension and tracking authority must be engineered and tested.')
    p.note(226,y,177,'SERVICE CONNECTIONS','Provide maintainable cable loops, separation from moving parts and a documented disconnect path. Cable fill, bend radii, earthing, ingress, electrical design and air isolation are unresolved.')
    p.finish()

def tolerances():
    p=Page(8,'Proposed inspection targets and release gates','Review assumptions only / values below are proposed prototype metrology targets, not approved manufacturing tolerances')
    y=44
    widths=[14,89,72,108,95]
    headers=['ID','Interface','Proposed target','Verification method','Required release gate']
    total=sum(widths);p.rect(21,y,total,9,PALE);xx=21
    for text,w in zip(headers,widths):p.text(xx+2,y+6,text,2.7,TEAL,True);xx+=w
    y+=9
    for i,row in enumerate(TOLERANCES):
        rh=19
        if i%2==1:p.rect(21,y,total,rh,'#f7f9f9')
        x=21
        vals=[row['id'],row['interface'],row['target'],row['method'],row['gate']]
        for value,w in zip(vals,widths):p.paragraph(x+2,y+5,value,w-5,2.7,lineheight=4.1);x+=w
        p.line(21,y+rh,21+total,y+rh,LIGHT,.2);y+=rh
    p.note(22,219,181,'NO GENERAL +/- TOLERANCE IS RELEASED','Numeric targets T01-T05 are proposed inspection goals for design discussion. They require tolerance-stack review, process capability, calibrated instruments and acceptance approval before any purchase or fabrication order.')
    p.note(224,219,177,'STANDOFFS AND MAXIMUM PIECE SIZE','Camera, depth and induction standoffs remain adjustable. Sieve bands 12.5-25 and 25-50 mm do not specify maximum height, length or mass. Verify the actual sample distribution before freezing clearances or ejection impulse.')
    p.finish()

def generate_bom():
    dest=ROOT/'bom';dest.mkdir(exist_ok=True)
    rows=[]
    for i,part in enumerate(PARTS,1):
        lo,hi=bpoints(part)
        optional=part.get('optional',False) or part['id'].startswith('depth_optional') or part['category']=='research'
        rows.append({'item':i,'part_id':part['id'],'description':part['name'],'category':part['category'],'modeled_quantity':1,
         'status':'optional/unbuilt study item' if optional else 'proposed prototype geometry',
         'material_grade':str(part.get('material','TBD; visual finish is not a procurement specification')),
         'volume_mm3':part.get('volume_mm3'),'mass_kg':'TBD - material/density not assigned',
         'bbox_x_mm':round(hi[0]-lo[0],4),'bbox_y_mm':round(hi[1]-lo[1],4),'bbox_z_mm':round(hi[2]-lo[2],4),
         'vendor_part_number':'TBD - no purchase selection','note':part.get('notes',part.get('note',''))})
    with (dest/'part_instance_bom.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    groups=[]
    for cat,count in sorted(Counter(p['category'] for p in PARTS).items()):
        group=[r for r in rows if r['category']==cat]
        groups.append({'category':cat,'modeled_part_instances':count,'optional_study_instances':sum(r['status'].startswith('optional') for r in group),
          'purchased_quantity':'TBD; one CAD solid does not equal one purchased assembly',
          'material_grade':'TBD','cost_usd':'TBD; do not infer from modeled volume'})
    with (dest/'preliminary_group_bom.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(groups[0]));w.writeheader();w.writerows(groups)
    with (dest/'proposed_tolerance_register.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(TOLERANCES[0]));w.writeheader();w.writerows(TOLERANCES)
    assumptions=[
      ['A01','Transport envelope','600 mm belt; x0..3000; belt surface z1000','Provisional layout','Not a selected production conveyor'],
      ['A02','Sensor datums','RGB x1300; induction x1600; last datum x1750','Provisional layout','Recalibrate installed device poses'],
      ['A03','Measurement window','x1350..1850; z988..994; nonmetallic','Geometric selection','Material, wear, deflection and EM response unverified'],
      ['A04','Housing gap','8 mm housing top to window underside','Geometric selection','Not active coil-to-object lift-off'],
      ['A05','Optical footprint','400 mm transverse by 300 mm travel','Illustrative example','Does not establish full 600 mm belt coverage'],
      ['A06','Design speed cases','0.5, 1.0, 2.0 m/s','Ideal kinematic study','Uncalibrated demo playback speed is separate'],
      ['A07','Pilot feed ramp','50..200 kg/h','Proposed test plan','No rated capacity or achieved recovery'],
      ['A08','Nozzle array','12 modeled positions; 50 mm visual pitch','Packaging choice','Pitch, pressure, impulse and latency await sample trials'],
      ['A09','Three collection bins','Airjet two-way split plus balance-only gate','Two-stage routing concept','Group/window review; cannot recover an already ejected target'],
      ['A10','Side service reservation','900 mm beyond actual outer equipment','Layout assumption','Door and bin sweeps, isolation and safety review still required'],
      ['A11','Fragment campaigns','12.5..25 and 25..50 mm sieve classes','Proposed trials','Maximum length, thickness, mass and hazards separately bounded'],
      ['A12','Drive and bearings','Geometric housings, shafts and brackets','Unselected devices','No power, torque, bearing life or fit rating'],
      ['A13','Depth device','Optional unbuilt envelope','R&D option','No purchased sensor, selected laser or validated benefit'],
      ['A14','Safety and compliance','Concept guard and access provisions','Unvalidated','No certification, containment, safety function or standards claim'],
      ['A15','Full-width discharge capture','660 mm balance and concentrate inlets for a 600 mm belt','Source geometry repair','30 mm nominal edge allowance is not a validated scatter envelope'],
      ['A16','Transverse convergence','Balance to 136 mm gate approach; concentrate to 260 mm outlet','Source geometry repair','Flow, rebound, bridging, wear and maximum accepted fragment size need sample trials'],
    ]
    with (dest/'design_assumption_register.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['id','topic','current_basis','evidence_status','required_boundary']);w.writerows(assumptions)
    report={'status':'preliminary design review only','part_instances':len(rows),'groups':groups,
      'optional_study_instances':sum(r['status'].startswith('optional') for r in rows),
      'source_step_sha256':MAN['step_sha256'],'source_manifest_sha256':hashlib.sha256((ROOT/'exports/assembly_manifest.json').read_bytes()).hexdigest(),
      'proposed_inspection_targets':TOLERANCES,'design_assumptions':assumptions,'limitations':['Not a purchasing BOM','No supplier, load rating or cost selected','No modeled volume-to-mass conversion','Unmodeled internals and final fixing schedules remain TBD']}
    (dest/'bom_and_assumptions.json').write_text(json.dumps(report,indent=2)+'\n')
    (dest/'README.txt').write_text('FERROSIFT INVESTOR REVIEW IR-01 - PRELIMINARY BOM\n\nThe part-instance CSV is an exhaustive count of exported CAD solids, not a procurement schedule.\nGroup counts reconcile to assembly_manifest.json. Optional depth and research devices are unbuilt study items.\nMaterial grades, density, purchased assemblies, approved vendors, costs and final fastener schedules remain unresolved.\nDo not derive mass or costs from the current geometric volumes.\n\nThe proposed tolerance register is a design-review proposal. T01-T05 are metrology goals, not certified or approved manufacturing tolerances. T06-T08 remain TBD.\nReference drawings: ../drawings/Ferrosift_Investor_Engineering_Drawings_IR01.pdf\n')


def discharge_section():
    p=Page(10,'Actual discharge sections / capture repair','C-C at y=0 and D-D at x=3610 / exact solid cuts / geometric coverage does not establish material-flow performance')
    v=p.view('routing_section_c',(24,65,225,120),denom=5,caption='C-C / y0 / flow-zone crop, exact solid cut')
    gate=part('review_gate_plate');pivot3=gate['animation']['pivot'];lip3=(B['discharge_lip_x'],0,B['top_z'])
    lip=v(lip3);pivot=v(pivot3)
    p.dimh(lip[0],pivot[0],51,lip[1],pivot[1],f'{n(pivot3[0]-lip3[0])} LIP TO GATE PIVOT x')
    p.line(lip[0],58,lip[0],183,TEAL,.25,'3 1')
    p.text(lip[0]+2,61,'x3000 LIP',2.7,TEAL)
    p.leader(*pivot,137,179,'Gate pivot '+str(pivot3))
    d=p.view('routing_section_d',(264,65,140,120),denom=5,caption='D-D / x3610 / concentrate inlet solid cut')
    lo,hi=bpoints(part('concentrate_chute_floor'))
    aa=d((3610,lo[1],hi[2]));bb=d((3610,hi[1],hi[2]))
    p.dimh(aa[0],bb[0],53,aa[1],bb[1],f'{n(round(hi[1]-lo[1],3))} CONCENTRATE INLET',TEAL)
    y=p.note(24,205,180,'CAPTURE AND CONVERGENCE','Both 660 mm inlets span the 600 mm belt. Concentrate narrows to 260 mm at x4000. Balance converges to a 136 mm approach before the upstream-pointing gate blade.')
    p.note(24,y+1,180,'GEOMETRY BOUNDARY','Width checks establish only modeled capture and guide surfaces. The 30 mm nominal allowance per belt edge is not a validated trajectory-scatter margin.')
    y=p.note(222,205,181,'BALANCE GATE / CONTROL HOLD','The gate serves balance only and cannot recover already-ejected concentrate. Inhibit feed, verify drain time, command and confirm position, then resume. Transition geometry is not an operating state.')
    p.note(222,y+1,181,'FLOW AND HARDWARE HOLD','Gate seats show nominal contact, not verified closure. Test fragment limits, bounce, jams, leakage and residence time. Actuator, stops, seals, pneumatics and safeguarding remain unresolved.')
    p.finish()


def main():
    def check_projection_freshness():
        for definition in json.loads((OUT/'view_definitions.json').read_text()):
            inputs=b''.join((ROOT/source).read_bytes() for source in definition['sources'])
            expected_digest=hashlib.sha256(inputs+json.dumps(definition,sort_keys=True).encode()+(OUT/'project_views.py').read_bytes()).hexdigest()
            cached=json.loads((PROJ/f"{definition['name']}.json").read_text())
            if cached['input_sha256']!=expected_digest:
                raise ValueError(f"Stale STEP projection: {definition['name']}; rerun project_views.py")
        if MAN['step_sha256']!=hashlib.sha256((ROOT/'exports/conveyor_assembly.step').read_bytes()).hexdigest():
            raise ValueError('STEP changed during drawing generation; rerun after export freezes')
    check_projection_freshness()
    if DISCHARGE['source_sha256']!=hashlib.sha256((ROOT/'cad/discharge.py').read_bytes()).hexdigest():
        raise ValueError('Discharge contract source identity is stale')
    # This release's annotation layout is coordinated to the frozen v0 geometry.
    # Refuse a changed basis instead of silently printing stale dimensions.
    expected={'belt_width':(B['active_width'],600),'deck_length':(B['deck_length'],3000),
      'inlet_x':(B['inlet_x'],0),'lip_x':(B['discharge_lip_x'],3000),
      'belt_top_z':(B['top_z'],1000),'rgb_x':(S['rgb_center_x'],1300),
      'induction_x':(S['induction_center_x'],1600),'last_datum_x':(S['last_sensing_datum_x'],1750),
      'hood_x_min':(H['x_min'],1050),'hood_x_max':(H['x_max'],1950),
      'hood_width':(H['width'],900),'hood_height':(H['height_above_deck'],850),
      'cassette_width':(C['width'],600),'cassette_length':(C['length'],350),
      'cassette_height':(C['height'],200),'service_clearance':(G['service']['side_clearance'],900)}
    for ident in ('balance_catch_floor','concentrate_chute_floor'):
        lo,hi=bpoints(part(ident));expected[ident+'_capture_width']=(round(hi[1]-lo[1],3),660)
        edges=part(ident)['routing_edges_mm']
        expected[ident+'_intake_width']=(round(abs(edges[0][1]-edges[1][1]),3),660)
        expected[ident+'_outlet_width']=(round(abs(edges[2][1]-edges[3][1]),3),136 if ident.startswith('balance') else 260)
    expected['gate_pivot_x']=(part('review_gate_plate')['animation']['pivot'][0],3560)
    expected['concentrate_outlet_floor_base_z']=(part('concentrate_chute_floor')['routing_edges_mm'][2][2],600)
    for name,(actual,required) in expected.items():
        if actual!=required:raise ValueError(f'Revise drawing annotation layout for {name}: {actual} != frozen {required}')
    if MAN['units']!='mm':raise ValueError('Assembly manifest must declare mm')
    if MAN['step_sha256']!=hashlib.sha256((ROOT/'exports/conveyor_assembly.step').read_bytes()).hexdigest():
        raise ValueError('Manifest does not match current assembly STEP')
    OUT.mkdir(exist_ok=True)
    for fn in (overall,sensing,base,routing,assembly,sections,interfaces,tolerances,installation,discharge_section):fn()
    generate_bom()
    pdf=fitz.open()
    for path in SHEETS:
        doc=fitz.open(stream=path.read_bytes(),filetype='svg');converted=fitz.open('pdf',doc.convert_to_pdf());pdf.insert_pdf(converted)
    pdf.set_metadata({'title':'Ferrosift prototype conveyor - investor engineering drawings IR-01','author':'Ferrosift','subject':'Executed CAD geometry; concept coordination only; not for fabrication','keywords':'A3,concept,STEP,CadQuery,dimensioned'})
    pdfpath=OUT/'Ferrosift_Investor_Engineering_Drawings_IR01.pdf';pdf.save(pdfpath,garbage=4,deflate=True)
    previews=OUT/'previews';previews.mkdir(exist_ok=True)
    for i,page in enumerate(pdf):
        if abs(page.rect.width-420*72/25.4)>.1 or abs(page.rect.height-297*72/25.4)>.1:
            raise ValueError('Incorrect A3 page geometry')
        page.get_pixmap(matrix=fitz.Matrix(2.1,2.1),alpha=False).save(previews/f'FS-CV-{i+1:02d}.png')
    check_projection_freshness()
    verification={'pdf':str(pdfpath),'page_count':len(pdf),'a3_landscape_mm':[420,297],
      'source_step_sha256':hashlib.sha256((ROOT/'exports/conveyor_assembly.step').read_bytes()).hexdigest(),
      'source_manifest_sha256':hashlib.sha256((ROOT/'exports/assembly_manifest.json').read_bytes()).hexdigest(),
      'view_checks':CHECKS,'render_backend':'PyMuPDF SVG-to-PDF and raster verification',
      'projection_method':'OpenCascade exact visible-edge HLR and solid-plane intersections from generated STEP solids',
      'scope':'Investor design review; provisional targets are proposed only; no approved fabrication tolerance, operating performance or safety compliance',
      'checks':{'ten_pages':'PASS' if len(pdf)==SHEET_COUNT else 'FAIL','physical_A3_page_size':'PASS',
      'frozen_dimensional_basis_matches_annotations':'PASS', 'STEP_and_manifest_hash_agree':'PASS',
      'all_projection_inputs_match_current_STEP_exports':'PASS',
      'view_geometry_fits_allocated_viewports':'PASS','source_is_generated_STEP_solid_geometry':'PASS','actual_solid_sections_A_B_C_and_D':'PASS',
      'visual_layout_review':'UNVERIFIED until page PNGs inspected',
      'mechanical_safety_and_fabrication_release':'UNVERIFIED - intentionally outside concept release'},
      'annotated_basis_mm':{k:v[0] for k,v in expected.items()}}
    verification['source_files']={
      'STEP':{'file':'exports/conveyor_assembly.step','sha256':verification['source_step_sha256']},
      'manifest':{'file':'exports/assembly_manifest.json','sha256':verification['source_manifest_sha256']},
      'web_packet_routes':{'file':'web/conveyor-assembly.json','sha256':hashlib.sha256((ROOT/'web/conveyor-assembly.json').read_bytes()).hexdigest()},
      'parameters':{'file':'design_basis/parameters.json','sha256':hashlib.sha256((ROOT/'design_basis/parameters.json').read_bytes()).hexdigest()}}
    verification['source_files']['discharge_geometry_contract']={'file':'cad/discharge_geometry_contract.json','sha256':hashlib.sha256((ROOT/'cad/discharge_geometry_contract.json').read_bytes()).hexdigest()}
    verification['part_count']=len(PARTS)
    verification['discharge_annotated_edges_mm']={ident:part(ident)['routing_edges_mm'] for ident in ('balance_catch_floor','concentrate_chute_floor')}
    verification['gate_annotation_basis']={k:part('review_gate_plate').get(k) for k in ('animation','nominal_reach_mm','nominal_tip_and_floor_clearance_mm','notes')}
    verification['assembly_bbox_mm']=MAN['assembly_bbox']
    (OUT/'drawing_verification.json').write_text(json.dumps(verification,indent=2)+'\n')
    print(json.dumps({'pdf':str(pdfpath),'pages':len(pdf),'svgs':len(SHEETS),'views':len(CHECKS)},indent=2))

if __name__=='__main__':main()
