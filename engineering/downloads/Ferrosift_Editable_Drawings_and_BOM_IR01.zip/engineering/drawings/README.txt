FERROSIFT / INVESTOR ENGINEERING DRAWINGS / IR-01 / 14 OCTOBER 2026

This package documents an unvalidated prototype design. It is suitable for coordinated design review and investor explanation, not fabrication, procurement, commissioning or safety approval.

CONTENTS
Ferrosift_Investor_Engineering_Drawings_IR01.pdf - ten A3 landscape sheets.
FS-CV-01.svg through FS-CV-10.svg - editable vector sheet sources.
previews/ - rendered PNG of each issued sheet.
project_views.py - exact OpenCascade visible-edge projections and actual solid sections.
generate_drawings.py - dimensioned layout and source-derived BOM generator.
view_definitions.json - STEP subsets, view orientations, crop envelopes and section planes.
check_drawings.py - source, page-size, text-boundary, section and BOM checks.
drawing_verification.json and drawing_layout_qa.json - issued output receipts.
../bom/ - part-instance BOM, grouped BOM, proposed tolerance and design-assumption registers.

SHEET INDEX
01 General arrangement and provisional process datums.
02 Sensing cell, optical mounting and example field of view.
03 Belt path, support, drive and mechanical design inputs.
04 Primary airjet split plus downstream balance/review gate.
05 Exploded assembly groups and manifest-derived count schedule.
06 Exact solid sections A-A at x1600 and B-B at y0.
07 Local drive, tensioning and control interfaces.
08 Proposed inspection targets and release gates.
09 Service envelope, ideal kinematics and required trials.
10 Actual longitudinal flow-zone and transverse capture sections, repaired widths and control holds.

TRACEABILITY
All illustrated mechanical outlines derive from exported STEP solids. Section tint is a tessellation of the actual solid-plane intersection, with exact projected boundary edges. Dashed route paths are explanatory intent, not measured trajectories. Sections intentionally include the optional depth-study envelope where the plane crosses it; its presence is not installation evidence.

Dimension units are millimetres. View scales apply only when printed at A3 / 100 percent. Source SHA-256 and part count appear on every sheet. No generic manufacturing tolerance is implied; T01-T05 on sheet08 are proposed metrology targets awaiting engineering approval. Material grades, loads, maximum piece dimensions/masses, drive power, nozzle impulse and safety design remain unresolved.

DISCHARGE REPAIR REVIEW
Sheet04 shows the physical full-width capture and transverse convergence. Sheet10 adds exact section D-D at x3610 through the concentrate inlet to C-C at y0. Both 660 mm inlets extend 30 mm beyond each nominal belt edge; this is geometry, not a validated trajectory-scatter allowance. The 136 mm gate approach, 260 mm concentrate outlet and nominal gate seat contact require representative flow, leakage, bridging, wear, actuator and timing tests. Nothing in these drawings is a physical validation or fabrication release.

REBUILD
From investor_package_20261014_v01/engineering, after the CAD export owner freezes a complete exports/assembly_manifest.json:
  <cad-python> drawings/project_views.py
  <cad-python> drawings/generate_drawings.py
  <cad-python> drawings/check_drawings.py
Inspect all ten PNG files. Only after visual inspection:
  <cad-python> drawings/check_drawings.py --visual-reviewed

The existing local CAD Python is engineering/conveyor_concept_20261013/.venv-cad/bin/python at the Ferrosift_Lab root. It provides CadQuery/OpenCascade and PyMuPDF. Set XDG_CACHE_HOME to a writable temporary directory. The generator rejects stale STEP projections or a manifest/STEP mismatch. Original 13 October CAD and the verified af611cd website release remain separate and unchanged.
