"""Independent M01 source spatial review (no edits to source or exports)."""
from pathlib import Path
import hashlib, importlib.util, json, sys
from datetime import datetime, timezone
import cadquery as cq
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1] / 'engineering'
sys.path.insert(0, str(ROOT / 'cad'))

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def bounds(shape):
    b = Bnd_Box(); BRepBndLib.AddOptimal_s(shape.wrapped, b, False, False)
    v = b.Get(); return {'min': list(v[:3]), 'max': list(v[3:])}
def box_of(b):
    sizes = [b['max'][i] - b['min'][i] for i in range(3)]
    mid = [(b['max'][i] + b['min'][i]) / 2 for i in range(3)]
    return cq.Workplane('XY').box(*sizes).translate(mid).val()
def overlap(a, b, tolerance=1e-7):
    return all(a['min'][i] < b['max'][i] - tolerance and
               b['min'][i] < a['max'][i] - tolerance for i in range(3))
def near(a, b, tolerance=1e-5):
    return all(a['min'][i] <= b['max'][i] + tolerance and
               b['min'][i] <= a['max'][i] + tolerance for i in range(3))

def main():
    files = [ROOT/'cad/build_module.py', ROOT/'cad/export_common.py',
             ROOT/'design_basis/parameters.json', ROOT/'design_basis/geometry_contract.json']
    files += [p for p in sorted((ROOT/'cad').glob('*.py')) if p not in files]
    initial = {str(p.relative_to(ROOT)): sha(p) for p in files}
    spec = importlib.util.spec_from_file_location('independent_module_source', files[0])
    source = importlib.util.module_from_spec(spec); spec.loader.exec_module(source)
    p = json.loads(files[2].read_text()); parts = source.build(p)
    rows = {x['id']: x for x in parts}
    bbs = {x['id']: bounds(x['shape']) for x in parts}
    out = {'generated_utc': datetime.now(timezone.utc).isoformat(),
           'source_sha256': initial,
           'scope': 'Nominal geometry only. No loads, wear, fields, capture or safety validation.',
           'part_count': len(parts), 'spatial_checks': {}, 'observations': []}
    coils = []
    for part in parts:
        if 'coil' not in part: continue
        b = bbs[part['id']]; spans = [b['max'][i]-b['min'][i] for i in range(3)]
        expected_axis = 2 if part['coil']['plane'] == 'XY' else 1
        assert spans.index(min(spans)) == expected_axis, (part['id'], spans)
        coils.append({'id': part['id'], 'plane': part['coil']['plane'],
                      'bbox_span_mm': spans, 'normal_axis_verified': 'XYZ'[expected_axis]})
    out['spatial_checks']['coil_planes'] = coils
    assert len(coils) == 6
    bb = bbs
    out['spatial_checks']['nominal_interface_dimensions_mm'] = {
        'host_belt_width': bb['host_carrying_belt']['max'][1]-bb['host_carrying_belt']['min'][1],
        'clear_lane_between_skirts': bb['lane_skirt_1']['min'][1]-bb['lane_skirt_-1']['max'][1],
        'rigid_guide_to_belt_gap': bb['lane_guide_1']['min'][2]-bb['host_carrying_belt']['max'][2],
        'skirt_to_belt_nominal_gap': bb['lane_skirt_1']['min'][2]-bb['host_carrying_belt']['max'][2],
        'belt_thickness': bb['host_carrying_belt']['max'][2]-bb['host_carrying_belt']['min'][2],
        'support_thickness': bb['module_support_window']['max'][2]-bb['module_support_window']['min'][2],
        'head_cover_to_support_gap': bb['module_support_window']['min'][2]-bb['under_cartridge_cover']['max'][2],
        'rx_winding_top_to_belt_top': bb['host_carrying_belt']['max'][2]-bb['under_rx_xy_42']['max'][2],
        'tx_winding_top_to_belt_top': bb['host_carrying_belt']['max'][2]-bb['under_tx_xy']['max'][2],
        'cartridge_to_return_run_gap': bb['under_cartridge_shell']['min'][2]-bb['host_return_belt']['max'][2],
        'side_cover_to_guide_outer_clearance': bb['side_face_cover_1']['min'][1]-bb['lane_guide_1']['max'][1],
        'side_cover_to_lane_boundary_clearance': bb['side_face_cover_1']['min'][1]-bb['lane_skirt_1']['min'][1],
        'scope': 'Unloaded nominal geometry. Tolerance, deflection and physical feed validation remain open.'}
    # Strict positive-volume intersections with the proposed reservation.
    e = p['exclusion_test_envelope']; reservation = box_of(e)
    intersections = []
    for part in parts:
        if not overlap(e, bbs[part['id']]): continue
        volume = part['shape'].intersect(reservation).Volume()
        if volume > 1e-5:
            intersections.append({'id': part['id'], 'material': part['materialClass'],
                                  'scope': part['scope'], 'volume_mm3': volume})
    out['spatial_checks']['reservation_intersections'] = intersections
    out['spatial_checks']['unintended_metal_in_reservation'] = [v for v in intersections
                                                            if v['material'] == 'metal']
    # Conservative swept AABB proves clearance if empty; hits need closer interpretation.
    moving = [v for v in parts if v.get('service_group') == 'under_cartridge']
    travel = p['service']['under_belt_withdrawal_mm']
    mb = {'min': [min(bbs[v['id']]['min'][i] for v in moving) for i in range(3)],
          'max': [max(bbs[v['id']]['max'][i] for v in moving) for i in range(3)]}
    swept = {'min': [mb['min'][i] + min(0, travel[i]) for i in range(3)],
             'max': [mb['max'][i] + max(0, travel[i]) for i in range(3)]}
    sweep_shape = box_of(swept)
    prerequisite_removed = {'cable_under_lead', 'under_cover_retainer_-100',
                            'under_cover_retainer_100'}
    collisions = []
    for part in parts:
        if part in moving or part['id'] in prerequisite_removed: continue
        if not overlap(swept, bbs[part['id']]): continue
        volume = part['shape'].intersect(sweep_shape).Volume()
        if volume > 1e-5: collisions.append({'id': part['id'], 'intersection_mm3': volume})
    out['spatial_checks']['under_cartridge_withdrawal'] = {
        'method': 'Continuous conservative swept bounding box vs retained source solids',
        'travel_mm': travel, 'swept_bbox': swept,
        'removed_before_test': sorted(prerequisite_removed), 'potential_obstructions': collisions}
    extra_sweeps = []
    service_specs = [
        ('optical_lid_removal', ['optical_top_service_cover'], [0, 0, 200], []),
        ('control_front_removal', [v['id'] for v in parts if v.get('service_group') == 'control_front'],
         [0, -350, 0], [v['id'] for v in parts if v['id'].startswith('control_panel_retainer_')])]
    accessories = [v['id'] for v in parts if v.get('calibration_accessory')]
    if accessories:
        service_specs.append(('calibration_accessory_withdrawal', accessories,
                              p['service']['calibration_target_insert_mm'], []))
    for label, selected, delta, removed in service_specs:
        region = {'min': [min(bbs[key]['min'][i] for key in selected) + min(0, delta[i]) for i in range(3)],
                  'max': [max(bbs[key]['max'][i] for key in selected) + max(0, delta[i]) for i in range(3)]}
        swept_shape = box_of(region); hits = []
        for part in parts:
            if part['id'] in selected + removed or not overlap(region, bbs[part['id']]): continue
            volume = part['shape'].intersect(swept_shape).Volume()
            if volume > 1e-5: hits.append({'id': part['id'], 'intersection_mm3': volume})
        extra_sweeps.append({'name': label, 'travel_mm': delta, 'swept_bbox': region,
                            'removed_before_test': removed, 'potential_obstructions': hits})
    out['spatial_checks']['other_removal_sweeps'] = extra_sweeps
    guard_hits = []
    for guard in [v for v in parts if v['id'].startswith('outer_lane_pod_guard_')]:
        for part in [v for v in parts if v['id'].startswith(('side_y_adjust_', 'side_z_adjust_'))]:
            if not overlap(bbs[guard['id']], bbs[part['id']]): continue
            volume = guard['shape'].intersect(part['shape']).Volume()
            if volume > 1e-5:
                guard_hits.append({'guard': guard['id'], 'part': part['id'], 'intersection_mm3': volume})
    out['spatial_checks']['adjustment_hardware_guard_collisions'] = guard_hits
    # Fixed interface crossings are distinct from moving service-path clearance.
    module_host_hits = []
    for part in [v for v in parts if v['scope'] == 'module']:
        for host in [v for v in parts if v['scope'] == 'host_reference']:
            if not overlap(bbs[part['id']], bbs[host['id']]): continue
            volume = part['shape'].intersect(host['shape']).Volume()
            if volume > 1e-4:
                module_host_hits.append({'module': part['id'], 'host': host['id'],
                                        'intersection_mm3': volume,
                                        'interpretation': 'intended_coupling_engagement' if
                                            (part['id'],host['id']) == ('encoder_coupling','host_roller_-1050')
                                            else 'requires_interpretation'})
    out['spatial_checks']['module_host_intersections'] = module_host_hits
    cable_hits = []
    endpoint_pairs = {
        'cable_optical': {'rgb_body','control_connector_optics'},
        'cable_optional_3d': {'optional_3d_body','control_connector_optics'},
        'cable_under_lead': {'under_cartridge_shell','control_connector_coil_A'},
        'cable_side_near': {'side_cartridge_-1','control_connector_coil_B'},
        'cable_side_far': {'side_cartridge_1','control_connector_coil_B'},
        'cable_encoder': {'encoder_body','control_connector_encoder'}}
    for cable in [v for v in parts if v['materialClass'] == 'cable']:
        for fixed in [v for v in parts if v['materialClass'] != 'cable']:
            if not overlap(bbs[cable['id']], bbs[fixed['id']]): continue
            volume = cable['shape'].intersect(fixed['shape']).Volume()
            if volume > 1e-4:
                cable_hits.append({'cable': cable['id'], 'fixed': fixed['id'],
                    'intersection_mm3': volume, 'interpretation': 'intended_device_endpoint' if
                    fixed['id'] in endpoint_pairs.get(cable['id'],set()) else 'requires_interpretation'})
    out['spatial_checks']['cable_structure_intersections'] = cable_hits
    # Contact graph highlights floating assemblies; deliberately separated parts may remain.
    structural = [v for v in parts if v['materialClass'] not in ('cable', 'coil_conductor', 'host_belt_unknown')
                  and 'skirt' not in v['id'] and not v['id'].startswith('column_index_')]
    parent = {v['id']: v['id'] for v in structural}; contacts = []
    def find(i):
        while parent[i] != i: parent[i] = parent[parent[i]]; i = parent[i]
        return i
    for i, a in enumerate(structural):
        for b in structural[i+1:]:
            if not near(bbs[a['id']], bbs[b['id']]): continue
            distance = a['shape'].distance(b['shape'])
            if distance < 1e-5:
                parent[find(a['id'])] = find(b['id'])
                contacts.append([a['id'], b['id']])
    components = {}
    for v in structural: components.setdefault(find(v['id']), []).append(v['id'])
    out['spatial_checks']['contact_components'] = sorted(components.values(), key=len, reverse=True)
    out['spatial_checks']['contact_edges'] = contacts
    # Central sight rays from actual aperture planar face normals, not assumed FOV.
    rays = []
    for ident in ('rgb_lens_glass', 'optional_3d_aperture_130', 'optional_3d_aperture_170'):
        aperture = rows[ident]
        faces = [f for f in aperture['shape'].Faces()
                 if f.geomType() == 'PLANE' and f.normalAt().z < -.5]
        assert len(faces) == 1, ident
        face = faces[0]; origin = face.Center(); direction = face.normalAt()
        length = (1000-origin.z)/direction.z
        end = origin.add(direction.multiply(length))
        ray = cq.Solid.makeCylinder(.1, length, origin, direction)
        rb = bounds(ray); hits = []
        for part in parts:
            if part['id'] in (ident, 'host_carrying_belt') or not overlap(rb, bbs[part['id']]): continue
            volume = part['shape'].intersect(ray).Volume()
            if volume > 1e-6: hits.append({'id': part['id'], 'ray_intersection_mm3': volume})
        rays.append({'id': ident, 'origin_mm': list(origin.toTuple()),
                     'direction': list(direction.toTuple()), 'belt_intersection_mm': list(end.toTuple()),
                     'obstructions': hits, 'scope': 'Central ray only, not calibrated field of view'})
    out['spatial_checks']['optical_central_rays'] = rays
    out['part_bounds'] = bbs
    out['part_volumes_mm3'] = {v['id']: v['shape'].Volume() for v in parts}
    assert initial == {str(f.relative_to(ROOT)): sha(f) for f in files}, 'Source changed during review'
    out['status'] = 'review_observations_require_interpretation'
    (HERE/'SOURCE_SPATIAL_REVIEW.json').write_text(json.dumps(out, indent=2)+'\n')
    print(json.dumps({'part_count': len(parts), 'coil_planes': coils,
        'unintended_metal_in_reservation': out['spatial_checks']['unintended_metal_in_reservation'],
        'withdrawal': out['spatial_checks']['under_cartridge_withdrawal'],
        'contact_components': out['spatial_checks']['contact_components']}, indent=2))

if __name__ == '__main__': main()
