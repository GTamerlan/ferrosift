"""Bind the independently reviewed M01-W1 geometry to its completed exports."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]/'engineering'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((HERE/'SOURCE_SPATIAL_REVIEW.json').read_text())
e=json.loads((HERE/'EXPORT_FILE_REVIEW.json').read_text())
d=json.loads((HERE/'DATUM_PARAMETER_REVIEW.json').read_text())
w=json.loads((ROOT/'web/module-assembly.json').read_text())
wr=json.loads((HERE/'WINDING_GEOMETRY_REVIEW.json').read_text())
s=r['spatial_checks']
assert not r['observations']
for name,value in r['source_sha256'].items():
    assert sha(ROOT/name)==value==w['provenance']['sourceSha256'][name]
assert e['result']=='pass' and e['web_sha256']==sha(ROOT/'web/module-assembly.json')
assert d['result']=='pass' and d['source_sha256']==r['source_sha256']['cad/build_module.py']
assert d['dependency_sha256']==r['source_sha256']==wr['source_sha256']
assert wr['coil_count']==6
for c in wr['coils']:
    assert c['valid'] and c['solid_count']==1 and not c['path_closed']
    assert c['nominal_min_nonlocal_insulation_separation_mm']>1
    assert not c['insulation_intersections']
    assert len(c['terminal_contacts'])==2
    assert all(n['id'] in c['winding_metadata']['terminal_ids'] for n in c['parts_within_5mm'] if n['intersection_mm3']>1e-4)
assert not s['unintended_metal_in_reservation']
assert not s['under_cartridge_withdrawal']['potential_obstructions']
assert all(not x['potential_obstructions'] for x in s['other_removal_sweeps'])
assert not s['adjustment_hardware_guard_collisions']
assert all(not x['obstructions'] for x in s['optical_central_rays'])
assert all(x['interpretation']=='intended_coupling_engagement' for x in s['module_host_intersections'])
assert all(x['interpretation']=='intended_device_endpoint' for x in s['cable_structure_intersections'])
for f in e['files']: assert sha(ROOT/f['path'])==f['sha256']
module_count=sum(p['scope']=='module' for p in w['objects'])
host_count=sum(p['scope']=='host_reference' for p in w['objects'])
text=(HERE/'SUPERSEDED_373c1635_INDEPENDENT_ENGINEERING_REVIEW.md').read_text()
text=text.replace('# Independent M01 engineering review','# Independent M01-W1 engineering review')
text=text.replace('373c16353af5248399f4360ca1be4f5f4e50a58bd4452640f5ae124d43950756',r['source_sha256']['cad/build_module.py'])
text=text.replace('257 module/accessory parts and 14 grey host-reference parts',f'{module_count} module/accessory parts and {host_count} grey host-reference parts')
text=text.replace('## Findings corrected during review',f"The winding helper `cad/windings.py` is also bound, SHA-256 `{r['source_sha256']['cad/windings.py']}`. The previously sealed M01 baseline is preserved under `history/M01_baseline_20261015_0907UTC`.\n\n## Findings corrected during review")
text=text.replace('- The initial cartridge extraction crossed a host side rail. The nominal host and module supports now clear the full removal envelope; retention hardware lies outside it.', '- The initial cartridge extraction crossed a host side rail. Expanded review later found fixed rails/supports also penetrating that host rail. The host reference rail top is now Z=900 mm: the fixed slide rails clear it by 10 mm and the cartridge by 30 mm. All module-vs-host source intersections were tested; only the deliberately represented encoder shaft coupling engagement remains. The earlier 373c1635 verdict was withdrawn and is retained with a SUPERSEDED prefix.')
text=text.replace('- Calibration is represented', '- Explicit cable-versus-fixed-solid checks found routes crossing the host, portal, optical mount, adjacent connector and encoder bracket. Routes and the bracket clearance slot were corrected. The tested routes now intersect only their documented device/connector endpoints; this is envelope routing, not selected connector, bend-radius or wiring qualification. Four supported saddles follow the revised optical routes.\n- Calibration is represented')
text=text.replace('| Cartridge above return run | 64 mm nominal clearance |','| Cartridge above return run | 64 mm nominal clearance |\n| Cartridge / fixed slide rails above host rail | 30 mm / 10 mm |\n| Module versus grey host solids | Only explicit encoder coupling engagement; no other positive-volume intersections |\n| Cable routes versus fixed solids | Only documented device/connector endpoints; no unintended intersections |')
text=text.replace('One Tx and two Rx conductor envelopes in XY planes, normal axis Z','One Tx and two Rx open windings with XY main planes, normal axis Z')
text=text.replace('One Tx and two Rx conductor envelopes in XZ planes, normal axis Y','One Tx and two Rx open windings with XZ main planes, normal axis Y')
text=text.replace('| Rx / Tx winding top to belt top | 28 mm / 35 mm; hidden conductive-feature height adds separation |','| Rx / Tx main conductor top to belt top | 30.85 mm / 37.85 mm; hidden conductive-feature height adds separation |\n| Rx / Tx insulation top to belt top | 30.6 mm / 37.6 mm |\n| Rx / Tx terminal top to belt top | 30.2 mm / 37.2 mm |')
min_gap=min(c['nominal_min_nonlocal_insulation_separation_mm'] for c in wr['coils'])
detail=f'''## Winding-detail revision

Each of the six functional windings is one continuous open conductor solid, with three illustrated nested rectangular perimeter passes, a recessed return and two separately identified contact pins. Independent reconstruction of the actual line/arc path checks its open ends, continuity and sampled containment in the source conductor. Both pins intersect their own conductor only. Terminal bases originally intersected the curved finish lead; the inserts now include the actual lead channel. The initial descent had only 0.108 mm nominal nonlocal insulation separation; moving it inward increased the checked minimum to {min_gap:.5f} mm.

The drawn conductor diameter is 0.9 mm, insulation OD 1.4 mm and main pitch 3.8 mm. Actual minimum bend radius is 1.2 mm. Straight recessed crossings have 1.6 mm insulation separation, which is distinct from the smaller minimum near the curved approach. Exact line probes through the straight-return groove give a 1.0 mm former floor. The insulation is an actual annular solid, touches its intended former and has no positive-volume intersection with fixed parts. The conductor intersects only its two intended pins. Housing and adjacent-former clearances, changed extrema and the reviewed paths are listed in `WINDING_GEOMETRY_REVIEW.json`.

These are illustrated packaging dimensions, not selected electrical turns, wire construction, insulation qualification or a manufacturable winding specification. The open spiral transitions mean three perimeter passes are not three exact closed encirclements. No current, frequency, polarity, balance, parasitic, thermal or electrical-netlist result is established. Internal harness routing from the terminal pairs to the external cartridge cable exits remains unresolved; no closed electrical circuit is claimed. The 180 mm lane and 600 mm host boundary remain unchanged.

'''
text=text.replace('## Export reconciliation',detail+'## Export reconciliation')
max_error=max(x['max_glb_coordinate_error_metres'] for x in e['checks'])*1000
max_volume=max(x['step_independent_source_relative_volume_error'] for x in e['checks'])
text=text.replace('0.000192 mm',f'{max_error:.6f} mm')
text=text.replace('below 1.9×10⁻¹⁰',f'of {max_volume:.3g}')
text=text.replace('Six unoptimized loops do not imply','Six illustrated continuous windings do not imply')
text=text.replace('source hashes, coil planes, measured nominal clearances, reservation intersections, four swept envelopes, optical rays, contact graph, part bounds and volumes.', 'source hashes, coil planes, measured nominal clearances, reservation intersections, four swept envelopes, all module-host intersections, cable-fixed intersections, optical rays, contact graph, part bounds and volumes.')
text=text.replace('The earlier 221-part draft receipt is retained as review history. Final receipts supersede it.', 'The earlier 221-part draft receipt and withdrawn 373c1635 verdict are retained as review history. The sealed 273-part M01 baseline is preserved separately; this report applies to M01-W1. Drawings and figures require their separate source-matched visual/export review.')
text=text.replace('- `DATUM_PARAMETER_REVIEW.json`:', '- `WINDING_GEOMETRY_REVIEW.json` and `WINDING_REVIEW_VERDICT.json`: path reconstruction, turn separation, terminal contacts, groove-floor probes, insulation/housing checks and actual extrema.\n- `DATUM_PARAMETER_REVIEW.json`:')
(HERE/'INDEPENDENT_ENGINEERING_REVIEW.md').write_text(text)
wv={'generated_utc':datetime.now(timezone.utc).isoformat(),'revision':'M01-W1','result':'passed_nominal_winding_geometry_only','source_sha256':wr['source_sha256'],'coil_count':6,'role_counts':{'Tx':2,'Rx':4},'physical_or_electrical_validation':False,'fabrication_release':False,'minimum_nonlocal_insulation_separation_mm':min_gap,'remaining_holds':['Electrical turns, wire/insulation, current/frequency, polarity/balance and thermal/parasitic design unselected','Manufacturing tolerance, insulation retention and bend suitability unqualified','Internal harness/pinout/terminal-to-external-cable route unresolved','No field solution, coverage, sensitivity, cancellation or performance validation'],'evidence':{'WINDING_GEOMETRY_REVIEW.json':{'sha256':sha(HERE/'WINDING_GEOMETRY_REVIEW.json')},'review_winding_geometry.py':{'sha256':sha(HERE/'review_winding_geometry.py')}}}
(HERE/'WINDING_REVIEW_VERDICT.json').write_text(json.dumps(wv,indent=2)+'\n')
v=json.loads((HERE/'SUPERSEDED_373c1635_INDEPENDENT_REVIEW_VERDICT.json').read_text())
v.update(generated_utc=datetime.now(timezone.utc).isoformat(),part_count=r['part_count'],source_sha256=r['source_sha256'],scope_counts={'module_including_calibration_accessory':module_count,'partial_host_reference':host_count})
v['revision']='M01-W1'
v['checked_scope'] += ['all module source solids versus all host source solids','all cable source envelopes versus fixed source solids; explicit endpoint exemptions only']
v['checked_scope'] += ['six continuous open winding paths, intended terminal contacts, nonlocal turn spacing, actual bend radii, groove floors, insulation/former and housing clearances']
v['remaining_holds'] += ['Internal winding-terminal harness, selected electrical turn/wire/insulation/current/frequency design and manufacturing qualification']
v['exceptions'] += ['Encoder coupling engagement overlaps the reference shaft intentionally; shaft/key/bearing manufacturing detail remains unselected.','Cable envelopes deliberately meet device/connector endpoints; terminal internals, bend radii, strain relief and cable specification remain unresolved.']
v['review_history']='Earlier verdict for 373c1635 was withdrawn after fixed host collisions were found; current source and exports pass the expanded checks.'
files=['SOURCE_SPATIAL_REVIEW.json','EXPORT_FILE_REVIEW.json','DATUM_PARAMETER_REVIEW.json','WINDING_GEOMETRY_REVIEW.json','WINDING_REVIEW_VERDICT.json','INDEPENDENT_ENGINEERING_REVIEW.md','review_source_geometry.py','verify_export_files.py','verify_datum_parameter.py','review_winding_geometry.py','seal_review.py']
v['evidence']={f:{'sha256':sha(HERE/f),'bytes':(HERE/f).stat().st_size} for f in files}
(HERE/'INDEPENDENT_REVIEW_VERDICT.json').write_text(json.dumps(v,indent=2)+'\n')
print(json.dumps({k:v[k] for k in ['generated_utc','result','source_sha256','part_count','scope_counts']},indent=2))
