# Independent M01-W1 engineering review

15 October 2026. **The checked nominal research geometry passes this review. It is not a fabrication, installation, safety or sensing-performance release.**

Reviewed source: `cad/build_module.py`, SHA-256 `f2aa1333872c5734805a43a3b2b8d540a62b2c3a9216c2476de2204d26f9e0df`. The final assembly contains 289 module/accessory parts and 14 grey host-reference parts. Source solids, the declared coordination dimensions, web geometry and exported STEP/BREP/GLB were reconciled independently.

The winding helper `cad/windings.py` is also bound, SHA-256 `41bed76bdaede1e66125493240922430088b409d0fb51124effbe857a4553d75`. The previously sealed M01 baseline is preserved under `history/M01_baseline_20261015_0907UTC`.

## Findings corrected during review

- The first rigid guides left a 3 mm belt gap. Nominal-contact flexible skirts now bridge it; containment, wear and entrapment remain unvalidated. Upstream outer-lane masks are physically supported, and guides now meet the inlet without the earlier 60 mm open approach gap. The host must meter material into the lane before these stationary masks.
- The initial cartridge extraction crossed a host side rail. Expanded review later found fixed rails/supports also penetrating that host rail. The host reference rail top is now Z=900 mm: the fixed slide rails clear it by 10 mm and the cartridge by 30 mm. All module-vs-host source intersections were tested; only the deliberately represented encoder shaft coupling engagement remains. The earlier 373c1635 verdict was withdrawn and is retained with a SUPERSEDED prefix.
- Unsupported window bridges, lane supports, transverse heads, optical hardware, cable saddles and enclosure attachments received actual connected support geometry. Coil formers and enclosure mounting spacers were added. This establishes nominal contact, not a qualified load path.
- The optional 3D sensor originally faced down outside the lane. It now points toward the lane. Lighting that would have obstructed one aperture was relocated.
- Mounting clamps now show coherent mating plates, clearance holes and bearing faces. The new adjustment hardware clears the removable pod covers. Actual slot geometry and retained spacer packs are provided, but their full travel and load capacity remain unchecked.
- Explicit cable-versus-fixed-solid checks found routes crossing the host, portal, optical mount, adjacent connector and encoder bracket. Routes and the bracket clearance slot were corrected. The tested routes now intersect only their documented device/connector endpoints; this is envelope routing, not selected connector, bend-radius or wiring qualification. Four supported saddles follow the revised optical routes.
- Calibration is represented by an explicit removable carrier/handle and unselected coupon envelope, separate from the normal operating view.
- A double-applied vertical-datum offset was corrected. The parameter documentation now distinguishes executable host-width/datum inputs from coordination dimensions requiring source edits.

## Independently checked geometry

| Check | Result |
|---|---|
| Host belt / mechanical lane | 600 mm / 180 mm; useful sensing aperture remains unmeasured |
| Under-belt coils | One Tx and two Rx open windings with XY main planes, normal axis Z |
| Transverse coils | One Tx and two Rx open windings with XZ main planes, normal axis Y |
| Belt / support thickness | 4 mm / 6 mm |
| Head cover to support | 10 mm nominal clearance |
| Rx / Tx main conductor top to belt top | 30.85 mm / 37.85 mm; hidden conductive-feature height adds separation |
| Rx / Tx insulation top to belt top | 30.6 mm / 37.6 mm |
| Rx / Tx terminal top to belt top | 30.2 mm / 37.2 mm |
| Cartridge above return run | 64 mm nominal clearance |
| Cartridge / fixed slide rails above host rail | 30 mm / 10 mm |
| Module versus grey host solids | Only explicit encoder coupling engagement; no other positive-volume intersections |
| Cable routes versus fixed solids | Only documented device/connector endpoints; no unintended intersections |
| Side cover to rigid guide / lane boundary | 7 mm / 15 mm |
| Cartridge removal | Continuous conservative swept box clears 850 mm negative-Y travel after documented disconnection/retainer release |
| Optical lid removal | Continuous conservative swept box clears 200 mm upward travel |
| Control front removal | Continuous conservative swept box clears 350 mm negative-Y travel after four panel retainers are removed |
| Calibration accessory removal | Continuous conservative swept box clears 450 mm upstream travel through the inlet |
| Optical central sight lines | RGB reaches belt at Y=0; optional 3D apertures reach Y=−36.71 and +5.47 mm, with no obstruction |
| Generic structural metal inside reserved test box | None; intended coils/leads and both unknown-composition host belt runs remain inside |
| Structural contact graph | Connected installed rigid assembly; separate removable calibration accessory; one explicitly partial host roller has omitted bearing support |
| Datum change | Every part translates exactly +100 mm when the belt datum changes from 1000 to 1100 mm |

The contact graph excludes flexible belts/skirts, cable paths, coil envelopes and offset graphical markers. A touching graph cannot establish strength, fastening adequacy or manufacturing fit. Optical checks use actual aperture-face normals and central rays only; they do not validate the full field of view or accepted object heights.

## Winding-detail revision

Each of the six functional windings is one continuous open conductor solid, with three illustrated nested rectangular perimeter passes, a recessed return and two separately identified contact pins. Independent reconstruction of the actual line/arc path checks its open ends, continuity and sampled containment in the source conductor. Both pins intersect their own conductor only. Terminal bases originally intersected the curved finish lead; the inserts now include the actual lead channel. The initial descent had only 0.108 mm nominal nonlocal insulation separation; moving it inward increased the checked minimum to 1.14558 mm.

The drawn conductor diameter is 0.9 mm, insulation OD 1.4 mm and main pitch 3.8 mm. Actual minimum bend radius is 1.2 mm. Straight recessed crossings have 1.6 mm insulation separation, which is distinct from the smaller minimum near the curved approach. Exact line probes through the straight-return groove give a 1.0 mm former floor. The insulation is an actual annular solid, touches its intended former and has no positive-volume intersection with fixed parts. The conductor intersects only its two intended pins. Housing and adjacent-former clearances, changed extrema and the reviewed paths are listed in `WINDING_GEOMETRY_REVIEW.json`.

These are illustrated packaging dimensions, not selected electrical turns, wire construction, insulation qualification or a manufacturable winding specification. The open spiral transitions mean three perimeter passes are not three exact closed encirclements. No current, frequency, polarity, balance, parasitic, thermal or electrical-netlist result is established. Internal harness routing from the terminal pairs to the external cartridge cable exits remains unresolved; no closed electrical circuit is claimed. The 180 mm lane and 600 mm host boundary remain unchanged.

## Export reconciliation

- GLB binary positions, triangle indices, normals, scope and optional-part metadata match the browser mesh. Maximum coordinate discrepancy from floating-point conversion is 0.000187 mm.
- Source part bounds and volumes agree with the manifest. STEP/BREP reopen, and STEP volumes agree with the independent source rebuild to relative error of 6.94e-10.
- Module-only and host-context exports retain the product boundary. Six illustrated continuous windings do not imply a 600 mm active width, measured field map, full tensor measurement, tomography or assay.
- The executed datum test verifies geometry translation only. The exported M01 documentation remains pinned to Z=1000 mm. Other host widths are validity probes, not validated installations; unchanged clamp geometry must not be assumed compatible.

## Remaining design and physical-validation holds

1. Measure actual mounted field/sensitivity coverage, primary-field cancellation, cross-talk, noise, drift, saturation and useful incremental information against strong simpler baselines. Neither the number of coils nor their orthogonal planes establishes an advantage.
2. Qualify the real carrying/return belts, reinforcement/splices, frame, rollers, fasteners, cable shields, host drive and switching equipment. The reserved box is an experiment-planning envelope, not an electromagnetic exclusion distance.
3. Validate host metering, accepted fragment geometry, height and mass, overlap, lane containment, skirt wear, collision/entrapment and safe handling of blocked feed. A screen fraction does not establish maximum height or reliable passage.
4. Complete structural, tolerance, loaded-deflection, adjustment-travel, fastener-retention, materials, thermal, EMC, environmental and installation-specific safety engineering. The grey host is partial reference context with bearing/drive/guard details intentionally omitted.
5. Verify object association through sequential stations. Encoder travel is not object travel. Last usable observation, latency/deadline, abstention policy and any downstream actuation/capture integration remain unresolved.
6. Select optical/electrical components, calibration standards and procedures; validate repeatability, full optical coverage, lifting/service access and fabrication drawings before operation.

## Evidence files

- `SOURCE_SPATIAL_REVIEW.json`: source hashes, coil planes, measured nominal clearances, reservation intersections, four swept envelopes, all module-host intersections, cable-fixed intersections, optical rays, contact graph, part bounds and volumes.
- `EXPORT_FILE_REVIEW.json`: file hashes, binary GLB comparisons and STEP/BREP/source volume reconciliation.
- `WINDING_GEOMETRY_REVIEW.json` and `WINDING_REVIEW_VERDICT.json`: path reconstruction, turn separation, terminal contacts, groove-floor probes, insulation/housing checks and actual extrema.
- `DATUM_PARAMETER_REVIEW.json`: independent +100 mm geometry-translation test.
- `review_source_geometry.py`, `verify_export_files.py`, `verify_datum_parameter.py`: reproducible independent checks. They write only this verification directory.

The earlier 221-part draft receipt and withdrawn 373c1635 verdict are retained as review history. The sealed 273-part M01 baseline is preserved separately; this report applies to M01-W1. Drawings and figures require their separate source-matched visual/export review. No CAD, website, metric, training, publication or private-paper content was modified by this reviewer.
