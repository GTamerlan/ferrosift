# Independent M01 engineering review scope

This review checks the proposed mechanical research geometry and exported representations. It cannot establish sensor sensitivity, electromagnetic independence, coverage, feed throughput, recovery, safety certification or fabrication readiness.

## Acceptance checks

1. Product scope is explicit on every CAD/web part. Host belt, frame and rollers remain reference equipment, with visually distinct colours and separate exports.
2. The 600 mm host is shown with a physically guided 180 mm central test lane and unused outer regions. A lane envelope is not a measured sensing footprint or qualified feed specification.
3. Under-belt coil solids lie in XY planes; side-head coil solids lie in XZ planes. The complement is between vertical and transverse sensitivity arrangements. Opposed polarity or Tx/Rx reversal is not another independent direction.
4. Intended coil housings, lanes and optical hardware have plausible mechanical clearances. Metallic structure entering the proposed exclusion/test reservation is enumerated, including reference host equipment. The reservation is not a computed electromagnetic boundary.
5. Mounts contact intended supports; holes/slots, fasteners and cable support are represented coherently. Load adequacy, host strength and final fastener/device selection remain open.
6. Optical geometry capture and illumination are visible, optional 3D is identified, and optical view examples are labeled assumed rather than calibrated.
7. Isolated maintenance withdrawal paths are checked for collision with retained solids. Any prerequisite cover release, cable disconnect, external support or host removal is explicit.
8. Calibration access is shown without implying calibrated response, complete pose recovery or exact composition reconstruction.
9. Source solids, STEP/BREP, GLB, web mesh and manifests agree in geometry, names, scope and scale. Browser annotations/field glyphs remain separate from measured fields.
10. Public descriptions retain unresolved host compatibility, actual belt reinforcement and wear, cross-talk, lift-off, drift, calibration, EMC/thermal and mechanical safety requirements.

## Early contract observation

The initial contract places guide bottoms at Z=1003 mm over a Z=1000 mm belt. This 3 mm opening cannot by itself constrain thinner fragments to the lane. The CAD owner was asked to add an explicitly preliminary nonmetallic skirt/wear provision or retain a clearly documented feed-containment hold.

## Evidence policy

Pass results describe geometric checks only. Lack of solid intersections does not prove manufacturability, load capacity, electrical clearance, signal quality or safe operation. Unvalidated performance claims must not be inferred from detailed CAD.
