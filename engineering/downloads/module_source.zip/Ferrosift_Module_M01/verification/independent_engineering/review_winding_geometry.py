"""Independent detailed-winding geometry review. No EM/electrical validation.

Run only after the author freezes the winding source. Reports source solids,
contact/clearance pairs, baseline differences and conductor intersections. Exact
coil endpoint/crossover interpretation is recorded after reading the source.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,importlib.util,json,sys
import cadquery as cq
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]/'engineering'
BASE=HERE.parents[1]/'history/M01_baseline_20261015_0907UTC/verification/independent_engineering/SOURCE_SPATIAL_REVIEW.json'
sys.path.insert(0,str(ROOT/'cad'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def bounds(s):
    b=Bnd_Box();BRepBndLib.AddOptimal_s(s.wrapped,b,False,False);v=b.Get()
    return {'min':list(v[:3]),'max':list(v[3:])}
def overlap(a,b):return all(a['min'][i]<b['max'][i]-1e-7 and b['min'][i]<a['max'][i]-1e-7 for i in range(3))
def bbox_distance(a,b):return sum(max(a['min'][i]-b['max'][i],b['min'][i]-a['max'][i],0)**2 for i in range(3))**.5
def main():
    source=ROOT/'cad/build_module.py'; params=ROOT/'design_basis/parameters.json'
    original={str(p.relative_to(ROOT)):sha(p) for p in [*sorted((ROOT/'cad').glob('*.py')),params,ROOT/'design_basis/geometry_contract.json']}
    spec=importlib.util.spec_from_file_location('winding_review_module',source)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    parts=module.build(json.loads(params.read_text())); rows={p['id']:p for p in parts}
    bb={p['id']:bounds(p['shape']) for p in parts}
    baseline=json.loads(BASE.read_text())
    coils=[p for p in parts if p.get('coil')]
    assert len(coils)==6
    assert sum(p['coil']['role']=='Tx' for p in coils)==2
    assert sum(p['coil']['role']=='Rx' for p in coils)==4
    reports=[]
    for p in coils:
        ident=p['id'];shape=p['shape']
        assert shape.isValid(),ident
        old=baseline['part_bounds'][ident]
        near_parts=[]
        for q in parts:
            if q is p:continue
            if bbox_distance(bb[ident],bb[q['id']])>5:continue
            distance=shape.distance(q['shape'])
            if distance>5:continue
            volume=shape.intersect(q['shape']).Volume() if overlap(bb[ident],bb[q['id']]) else 0.0
            near_parts.append({'id':q['id'],'material':q['materialClass'],'distance_mm':distance,'intersection_mm3':volume})
        winding=p.get('winding',{})
        assert winding, ('Missing detailed winding metadata',ident)
        path_edges=[]
        for edge in winding['path_edges']:
            vertices=[cq.Vector(*edge[k]) for k in ('start','middle','end')]
            path_edges.append(cq.Edge.makeLine(vertices[0],vertices[2]) if edge['type']=='LINE' else cq.Edge.makeThreePointArc(*vertices))
        wire=cq.Wire.assembleEdges(path_edges)
        assert not wire.IsClosed(),ident
        connections=[path_edges[i].endPoint().sub(path_edges[i+1].startPoint()).Length for i in range(len(path_edges)-1)]
        assert max(connections)<1e-6,('Path discontinuity',ident,connections)
        assert len(shape.Solids())==1,('Disconnected conductor',ident)
        for edge in path_edges:
            for fraction in (.1,.5,.9):
                assert shape.Solids()[0].isInside(edge.positionAt(fraction),1e-6),('Path not in conductor',ident,fraction)
        nonlocal_pairs=[]
        for i,a in enumerate(path_edges):
            for j,b in enumerate(path_edges[i+4:],start=i+4):
                distance=a.distance(b)
                nonlocal_pairs.append({'edge_a':i,'edge_b':j,'distance_mm':distance})
        minimum=min(nonlocal_pairs,key=lambda x:x['distance_mm'])
        assert minimum['distance_mm']>=winding['insulation_od_mm']-1e-6,('Nonlocal turn approach',ident,minimum)
        terminal_checks=[]
        for terminal_id in winding['terminal_ids']:
            terminal=rows[terminal_id]
            v=shape.intersect(terminal['shape']).Volume()
            assert v>1e-4,('Terminal does not contact conductor',ident,terminal_id)
            others=[]
            for q in coils:
                if q['id']==ident:continue
                if overlap(bb[terminal_id],bb[q['id']]):
                    iv=terminal['shape'].intersect(q['shape']).Volume()
                    if iv>1e-4:others.append({'id':q['id'],'intersection_mm3':iv})
            assert not others,('Terminal shorts another winding',terminal_id,others)
            terminal_checks.append({'id':terminal_id,'own_core_intersection_mm3':v,'other_winding_intersections':others,'bounds_mm':bb[terminal_id]})
        insulation=rows[winding['insulation_id']]
        insulation_contacts=[]
        for q in parts:
            if q is insulation or not overlap(bb[insulation['id']],bb[q['id']]):continue
            v=insulation['shape'].intersect(q['shape']).Volume()
            if v>1e-4:insulation_contacts.append({'id':q['id'],'intersection_mm3':v})
        former_id='under_tx_former' if ident=='under_tx_xy' else 'under_rx_former' if ident.startswith('under_rx_') else 'side_winding_former_-1' if ident=='side_tx_xz' else 'side_winding_former_1'
        former=rows[former_id]['shape']
        normal=cq.Vector(*winding['normal_direction'])
        origin=cq.Vector(*winding['former_face_origin_mm'])
        return_normal=winding['recessed_return_normal_mm']
        return_lines=[e for e in path_edges if e.geomType()=='LINE' and all(abs((q-origin).dot(normal)-return_normal)<1e-6 for q in (e.startPoint(),e.endPoint()))]
        middle=max(return_lines,key=lambda e:e.Length()).positionAt(.5)
        floor_probe=cq.Edge.makeLine(middle-normal*2,middle)
        floor_intersection=former.intersect(floor_probe)
        floor_thickness=sum(e.Length() for e in floor_intersection.Edges())
        assert abs(floor_thickness-1)<1e-5,('Former groove floor',ident,floor_thickness)
        housing_ids=['under_cartridge_shell','under_cartridge_cover','module_support_window'] if ident.startswith('under_') else ['side_cartridge_-1','side_face_cover_-1'] if ident=='side_tx_xz' else ['side_cartridge_1','side_face_cover_1']
        if ident=='under_tx_xy':housing_ids+=['under_rx_former']
        envelope_members=[p,insulation,*[rows[k] for k in winding['terminal_ids']]]
        housing_clearances=[]
        for housing_id in housing_ids:
            h=rows[housing_id]['shape']
            distances=[(q['id'],q['shape'].distance(h)) for q in envelope_members]
            intersections=[{'id':q['id'],'volume_mm3':q['shape'].intersect(h).Volume()} for q in envelope_members if overlap(bb[q['id']],bb[housing_id])]
            assert all(x['volume_mm3']<1e-4 for x in intersections),('Winding housing intersection',ident,housing_id,intersections)
            nearest=min(distances,key=lambda x:x[1])
            housing_clearances.append({'housing_id':housing_id,'nearest_winding_member':nearest[0],'minimum_distance_mm':nearest[1]})
        envelope_bounds={'min':[min(bb[q['id']]['min'][i] for q in envelope_members) for i in range(3)],'max':[max(bb[q['id']]['max'][i] for q in envelope_members) for i in range(3)]}
        reports.append({'id':ident,'metadata':p['coil'],'winding_metadata':winding,'solid_count':len(shape.Solids()),'valid':shape.isValid(),'volume_mm3':shape.Volume(),'bbox_mm':bb[ident],
                        'bbox_delta_from_baseline_mm':{side:[bb[ident][side][i]-old[side][i] for i in range(3)] for side in ('min','max')},
                        'parts_within_5mm':near_parts,'path_closed':wire.IsClosed(),'path_edge_count':len(path_edges),'path_length_mm':wire.Length(),'min_actual_bend_radius_mm':min(e.radius() for e in path_edges if e.geomType()=='CIRCLE'),'minimum_nonlocal_edge_spacing':minimum,'nominal_min_nonlocal_insulation_separation_mm':minimum['distance_mm']-winding['insulation_od_mm'],'terminal_contacts':terminal_checks,'insulation_intersections':insulation_contacts,'former':{'id':former_id,'insulation_distance_mm':insulation['shape'].distance(former),'groove_floor_probe_thickness_mm':floor_thickness,'floor_probe_location_mm':list(middle.toTuple())},'including_insulation_and_terminal_bounds_mm':envelope_bounds,'housing_clearances':housing_clearances})
    pairs=[]
    for i,p in enumerate(coils):
        for q in coils[i+1:]:
            distance=p['shape'].distance(q['shape'])
            volume=p['shape'].intersect(q['shape']).Volume() if overlap(bb[p['id']],bb[q['id']]) else 0.0
            pairs.append({'a':p['id'],'b':q['id'],'distance_mm':distance,'intersection_mm3':volume})
    changed=[]
    for ident,b in bb.items():
        old=baseline['part_bounds'].get(ident)
        if old is None:changed.append({'id':ident,'change':'added','bounds_mm':b});continue
        maximum=max(abs(b[side][i]-old[side][i]) for side in ('min','max') for i in range(3))
        if maximum>1e-6:changed.append({'id':ident,'change':'bounds_changed','max_bound_change_mm':maximum,'bounds_mm':b})
    gone=sorted(set(baseline['part_bounds'])-set(bb))
    assert original=={name:sha(ROOT/name) for name in original},'Source changed during winding review'
    out={'generated_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':original,'scope':'Nominal CAD geometry only; no electromagnetic/electrical/thermal/insulation or fabrication validation.','coil_count':len(coils),'parts':len(parts),'coils':reports,'coil_pair_clearances':pairs,'changed_part_bounds':changed,'removed_part_ids':gone,'status':'requires_source_and_terminal_interpretation'}
    (HERE/'WINDING_GEOMETRY_REVIEW.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'parts':len(parts),'coils':[{'id':p['id'],'solid_count':p['solid_count'],'near_parts':p['parts_within_5mm']} for p in reports],'changed_part_bounds':changed},indent=2))
if __name__=='__main__':main()
