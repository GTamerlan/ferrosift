# Ferrosift module figures M01-W1

These four views render the exact generated CAD mesh through an orthographic WebGL depth buffer. There is no image-generated substitute geometry. Source hashes, component selections, omission lists, image hashes and the depth-occlusion probe are recorded in `figure_manifest.json`.

- `module_isolated.png`: the proposed product without the host belt/frame. Module scope includes optics, complementary electromagnetic research cartridges, mounting adapters, encoder association, enclosure and supported cable routes.
- `module_installed_host.png`: the colored module on a grey host reference. The 600 mm belt is not the active width; only the central 180 mm experimental lane is mechanically constrained.
- `module_sensing_arrangement.png`: close cutaway of the exact six-path research winding arrangement, showing three illustrative perimeter passes per path, separate terminal pins, XY under-belt planes and XZ transverse planes. Insulation, the support window, covers, shells, formers and selected supports are omitted for visibility; the host and lane guides are translucent. The arrows denote intended principal excitation directions, not a computed or measured field. The paths do not establish a selected turn count, electrical connection scheme or useful sensing coverage.
- `module_maintenance_interfaces.png`: separate acquisition/control enclosure with its front omitted. Internal solids are unselected device envelopes. Connectors, pinouts, thermal/EMC behavior and safety functions are unvalidated.

Each captioned image is 2400 x 1440 pixels. Corresponding `_clean.png` files are 2260 x 1090 pixel raw CAD views without titles, captions or schematic overlays. Use clean files only with an accompanying caption explaining the concept status and any cutaway. Their absence of labels is not evidence of physical validation.

Recommended shared caption: "Retrofit sensing-module concept for a constrained test lane. Host conveyor shown for interface context. Dimensions and field reservations are illustrative; useful sensing coverage, performance, installation and safety remain to be validated."

`review/` contains five additional 2400 x 1440 review PNGs and companion SVGs: installed overall, installed top, longitudinal under-belt section at Y=0 mm, transverse section at X=334 mm, and cartridge withdrawal. The section planes intersect actual Tx/Rx solid segments. Their exact component intersection areas, projection inputs, omissions, source hashes and visual-review outcome are recorded in `review/review_views_manifest.json`. The overall review SVG embeds the exact mesh render; the other four contain editable vector projections. These are review views, not manufacturing drawings or physical validation.

## Reproduce

From the Ferrosift_Lab root, run `node module_package_20261015_v01/engineering/figures/render_figures.cjs`. This requires installed Chrome and starts a temporary loopback-only server. The renderer does not contact external services. It checks that the mesh and STEP hashes did not change during rendering. Review the final images after every source change; the script cannot establish visual completeness or engineering validity on its own.
