"""Ferrosift M01 retrofit research module. Millimetres, X travel / Y across / Z up.

Research coordination solids only. M01-W1 windings are continuous proposed
packaging paths, not qualified electrical designs, fields or measured sensitivity.
"""
from __future__ import annotations
import argparse, hashlib, json, math, sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
import cadquery as cq
import numpy as np
from export_common import bbox, rgb, tessellate, write_glb
from windings import winding, place, place_point
ROOT=Path(__file__).resolve().parents[1]
COLORS={'module':'#28596b','accent':'#41bba3','panel':'#d8e7e7','black':'#22343e','polymer':'#9ac9c3','copper':'#df9b53','rx':'#71d9d1','glass':'#70b4cb','steel':'#8a9aa3','host':'#777e85','belt':'#92989c','cable':'#374a58','light':'#f4e9bc'}
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def box(dx,dy,dz,x,y,z):return cq.Workplane('XY').box(dx,dy,dz).translate((x,y,z)).val()
def rounded(dx,dy,dz,x,y,z,r=3):return cq.Workplane('XY').box(dx,dy,dz).edges('|Z').fillet(min(r,min(dx,dy)/2-.1)).translate((x,y,z)).val()
def cyl(r,length,base,axis=(0,0,1)):return cq.Solid.makeCylinder(r,length,cq.Vector(*base),cq.Vector(*axis))
def tube_between(a,b,r,inner=0):
 d=cq.Vector(*b).sub(cq.Vector(*a));s=cyl(r,d.Length,a,d.normalized().toTuple())
 return s.cut(cyl(inner,d.Length,a,d.normalized().toTuple())) if inner else s

def loop_xy(w,h,t,z,x=0,y=0,r=12,trace=4):
 return rounded(w,h,t,x,y,z,r).cut(rounded(w-2*trace,h-2*trace,t+2,x,y,z,max(r-trace,2)))
def loop_xz(w,h,t,x,y,z,trace=4):return loop_xy(w,h,t,0,trace=trace).rotate((0,0,0),(1,0,0),90).translate((x,y,z))
def slot_plate(dx,dy,t,x,y,z,holes):
 s=rounded(dx,dy,t,x,y,z,5)
 for hx,hy in holes:
  cut=cq.Workplane('XY').center(hx,hy).slot2D(24,9,0).extrude(t+2).translate((0,0,z-t/2-1)).val();s=s.cut(cut)
 return s

def build(p):
 parts=[];ids=set();host_width=p['host']['belt_width'];half=host_width/2;z=1000;dz=p['host']['belt_top_z']-1000
 def add(id,name,group,shape,color='module',scope='module',material='metal',**meta):
  if isinstance(shape,cq.Workplane):shape=shape.val()
  if id in ids or not shape.isValid() or not shape.Solids() or shape.Volume()<=0:raise ValueError(f'Invalid or duplicate solid: {id}')
  ids.add(id)
  meta.setdefault('optional',False)
  parts.append(dict(id=id,name=name,group=group,category=group,scope=scope,materialClass=material,color=COLORS.get(color,color),shape=shape,proposed=True,geometryStatus='research_coordination_not_fabrication_release',**meta))
 def bolt(id,x,y,z,axis='z',length=24,material='metal',group='mounting',r=4):
  vector={'x':(1,0,0),'y':(0,1,0),'ny':(0,-1,0),'z':(0,0,1)}[axis]
  shaft=cyl(r,length,(x,y,z),vector)
  head=cyl(r*1.7,5,(x-vector[0]*5,y-vector[1]*5,z-vector[2]*5),vector)
  add(id,'Illustrative retained fastener, size/rating unselected',group,shaft.fuse(head),'steel' if material=='metal' else 'polymer',material=material,hardware_status='Illustrative geometry; supplier, preload and load rating unselected')
 def cable(id,points,r=4,group='cables',purpose='',optional=False):
  # Connected cylinder/sphere sweep envelope; bend radii/electrical shielding unresolved.
  segs=[tube_between(a,b,r) for a,b in zip(points,points[1:])]
  segs += [cq.Solid.makeSphere(r,cq.Vector(*v)) for v in points[1:-1]]
  s=segs[0]
  for t in segs[1:]:s=s.fuse(t)
  add(id,purpose or 'Supported cable route envelope',group,s,'cable',material='cable',optional=optional,points_mm=points,EMC_status='Lead dress, pair balance, shielding, bend radii and connector pinout unresolved',intended_sensor_lead=group in ('under_belt','transverse'))
 def add_winding(id,role,group,size,origin,plane='XY',normal_sign=1,pair=None,service_group=None):
  w=winding(*size)
  def positioned(shape):return place(shape,origin,plane,normal_sign)
  def point(q):return place_point(q,origin,plane,normal_sign)
  terminal_ids=[id+'_terminal_'+str(i) for i in range(2)]
  spec={**w['spec'],'former_face_origin_mm':list(origin),'normal_direction':[0,0,1] if plane=='XY' else [0,normal_sign,0],
        'path_control_points_mm':[point(q) for q in w['points']],
        'path_edges':[{'type':e.geomType(),'start':point(e.startPoint().toTuple()),'middle':point(e.positionAt(.5).toTuple()),'end':point(e.endPoint().toTuple()),'length_mm':e.Length()} for e in w['path'].Edges()],
        'terminal_ids':terminal_ids,'insulation_id':id+'_insulation',
        'terminals':[{**t,'centre':point(t['centre'])} for t in w['terminals']],
        'groove_fit_status':'Nominal matching OD with open inspection slot; fabrication tolerance, retention and insulation qualification unselected'}
  coil={'role':role,'plane':plane,'axis':[0,0,1] if plane=='XY' else [0,1,0],'centre_mm':point((0,0,.7)),
        'pair':pair,'pair_status':'Independent Rx channels; candidate differential pairing unoptimized, polarity, cancellation and position-dependent sensitivity unmeasured'}
  add(id,role+' proposed continuous winding · '+plane+' main plane',group,positioned(w['conductor']),'copper' if role=='Tx' else 'rx',material='coil_conductor',coil=coil,winding=spec,service_group=service_group)
  add(id+'_insulation','Proposed winding insulation annulus · unselected construction',group,positioned(w['insulation']),'#d4a766' if role=='Tx' else '#93d9c9',material='nonmetallic',winding_id=id,winding_part='insulation',default_hidden=True,cutaway=True,service_group=service_group)
  for i in range(2):
   add(terminal_ids[i],role+' winding '+('start' if i==0 else 'finish')+' terminal · not a selected connector',group,positioned(w['terminal_pins'][i]),'copper',material='coil_terminal',winding_id=id,winding_part='terminal',terminal_index=i,service_group=service_group)
   add(id+'_terminal_base_'+str(i),'Nonmetallic winding terminal insert',group,positioned(w['terminal_bases'][i]),'black',material='nonmetallic',winding_id=id,winding_part='terminal_base',service_group=service_group)
  cuts=[positioned(w['channel'])]+[positioned(q) for q in w['terminal_pockets']]
  return cuts
 # Grey host section only. A selected compatible belt is NOT asserted.
 add('host_carrying_belt','Host belt reference; reinforcement compatibility unverified','host',box(2400,host_width,4,0,0,z-2),'belt',scope='host_reference',material='host_belt_unknown',compatibility='Actual reinforcement/conductivity, wear and tracking require measurement')
 add('host_return_belt','Host return run reference; compatibility unverified','host',box(2400,host_width,4,0,0,z-136),'host',scope='host_reference',material='host_belt_unknown')
 for sy in (-1,1):
  add(f'host_side_rail_{sy}','Host frame reference outside illustrative test envelope','host',box(2520,50,90,0,sy*(half+75),z-145),'host',scope='host_reference')
 for x in (-1050,1050):
  add(f'host_roller_{x}','Grey host roller reference; not a selected drive','host',cyl(65,host_width+40,(x,-half-20,z-69),(0,1,0)),'host',scope='host_reference',host_detail_hold='Partial host segment: bearing/drive/guard details omitted; this roller is not an installed design')
  for sy in (-1,1):
   add(f'host_leg_{x}_{sy}','Host support context','host',box(60,60,545,x,sy*(half+75),537.5),'host',scope='host_reference')
   add(f'host_foot_{x}_{sy}','Host foot context','host',box(130,100,12,x,sy*(half+75),259),'host',scope='host_reference')
 # Nonmetallic support window, its geometry is not evidence of electromagnetic compatibility.
 add('module_support_window','Replaceable nonmetallic belt support window','under_belt',rounded(760,host_width+4,6,130,0,993,6),'polymer',material='nonmetallic',status='Material, wear, deflection and replacement method require host-specific engineering')
 for x in (-235,495):
  add(f'window_support_bridge_{x}','Nonmetallic window end support','mounting',box(40,820,34,x,0,973),'polymer',material='nonmetallic')
  for sy in (-1,1):add(f'window_bridge_post_{x}_{sy}','Nonmetallic window bridge support to lower rail','mounting',box(40,40,46,x,sy*400,933),'polymer',material='nonmetallic')
  for sy in (-1,1):bolt(f'window_bridge_bolt_{x}_{sy}',x,sy*398,948,length=45,material='nonmetallic')
 # Two end portals and external side rails, all selected metal outside test volume.
 for x in (-620,620):
  for sy in (-1,1):
   y=sy*420
   holes=[(x+dx,sy*yy) for dx in (-30,30) for yy in (340,410)]
   plate=slot_plate(150,150,10,x,sy*400,955,holes)
   add(f'mount_plate_{x}_{sy}','Slotted host adapter foot · proposed 24 x 9 mm slots','mounting',plate,'accent',mount_pattern_mm=holes)
   spacer=box(110,150,50,x,sy*400,925)
   backing=box(110,150,10,x,sy*375,805)
   for hx,hy in holes:
    spacer=spacer.cut(cyl(4.5,52,(hx,hy,899)))
    backing=backing.cut(cyl(4.5,12,(hx,hy,799)))
   add(f'mount_spacer_{x}_{sy}','Adapter saddle on host rail · fit/load unverified','mounting',spacer,'steel')
   add(f'mount_backing_{x}_{sy}','Clamp backing plate under host rail','mounting',backing,'steel')
   for ix,(hx,hy) in enumerate(holes):
    bolt(f'mount_bolt_{x}_{sy}_{ix}',hx,hy,800,length=166)
    nut=cyl(7,6,(hx,hy,960)).cut(cyl(4.2,8,(hx,hy,959)))
    add(f'mount_nut_{x}_{sy}_{ix}','Illustrative clamp nut · not torque specified','mounting',nut,'steel')
   upright=box(50,50,650,x,y,1285).cut(box(42,42,652,x,y,1285))
   add(f'portal_column_{x}_{sy}','Hollow adjustable module portal column','mounting',upright)
   # Actual slots in sliding optical head support plate are elsewhere, this is a structural placeholder.
   for h in (1060,1160,1260,1360):
    add(f'column_index_{x}_{sy}_{h}','Adjustment index marker','mounting',box(18,1.2,3,x,y-sy*25.7,h),'accent',material='nonmetallic')
  add(f'portal_crossbar_{x}','Module portal crossbar','mounting',box(50,890,50,x,0,1605))
 for sy in (-1,1):
  add(f'overhead_side_rail_{sy}','Overhead longitudinal module rail','mounting',box(1240,40,40,0,sy*420,1590))
  lower=box(1240,40,30,0,sy*420,895)
  for hx in (-185,185):lower=lower.cut(cyl(4.5,32,(hx,sy*410,879)))
  add(f'lower_side_rail_{sy}','Lower mounting rail, outside sensing reservation','mounting',lower)
 # Lane guides with nominal-contact flexible skirts, no physical feed validation claimed.
 for sy in (-1,1):
  add(f'lane_guide_{sy}','Nonmetallic guide · 180 mm experimental lane','lane',rounded(1000,8,38,0,sy*94,1022,3),'polymer',material='nonmetallic',clear_lane_width_mm=180,guide_to_belt_gap_mm=3)
  add(f'lane_skirt_{sy}','Replaceable flexible skirt · nominal belt contact','lane',box(1000,2,8,0,sy*91,1004),'accent',material='nonmetallic',hold='Wear, deflection, entrapment and fragment escape untested')
  for x in (-410,480):
   add(f'lane_support_post_{x}_{sy}','Nonmetallic lane support post to module rail','lane',box(28,40,130.5,x,sy*410,975.25),'polymer',material='nonmetallic')
   add(f'lane_support_arm_{x}_{sy}','Nonmetallic lane support arm','lane',box(28,300,15,x,sy*248,1048),'polymer',material='nonmetallic')
   add(f'lane_support_drop_{x}_{sy}','Nonmetallic guide attachment','lane',box(28,12,32,x,sy*99,1033),'polymer',material='nonmetallic')
   bolt(f'lane_retainer_{x}_{sy}',x,sy*99,1038,length=16,material='nonmetallic',group='lane',r=3)
 # Upstream exclusion mask: an installation/feed constraint, not an operating feeder.
 for sy in (-1,1):
  add(f'inlet_support_post_{sy}','Nonmetallic upstream exclusion support','lane',box(28,40,193,-500,sy*410,1006.5),'polymer',material='nonmetallic')
  add(f'inlet_support_arm_{sy}','Nonmetallic exclusion cantilever','lane',box(28,120,15,-500,sy*345,1110.5),'polymer',material='nonmetallic')
  add(f'inlet_outer_lane_mask_{sy}','Nonmetallic upstream outer-lane exclusion panel','lane',box(20,half-90,112,-500,sy*(half+90)/2,1062),'polymer',material='nonmetallic',hold='Requires host metering/singulation into central lane before this mask; blocked feed must be prevented, no throughput or safe jam-clearing claim')
  add(f'inlet_mask_skirt_{sy}','Flexible upstream exclusion skirt · nominal belt contact','lane',box(8,half-90,10,-500,sy*(half+90)/2,1005),'accent',material='nonmetallic',hold='Wear, collision, entrapment and escape unvalidated')
  for yy in (200,280):add(f'outer_cover_spacer_{sy}_{yy}','Nonmetallic pod cover standoff','lane',cyl(5,22,(300,sy*yy,1140)),'polymer',material='nonmetallic')
  add(f'outer_lane_pod_guard_{sy}','Nonmetallic unused-lane pod cover','lane',box(820,half-100,6,80,sy*(half+100)/2,1165),'polymer',material='nonmetallic',default_hidden=True,cutaway=True,hold='Local concept collision cover only; guarded access and feed envelope require review')
 # Under-belt removable cartridge, copper loops and candidate balanced receiver pair.
 shell=rounded(240,300,46,0,0,953,10).cut(rounded(230,290,48,0,0,959,7))
 add('under_cartridge_shell','Nonmetallic under-belt cartridge shell','under_belt',shell,'module',material='nonmetallic',service_group='under_cartridge')
 add('under_cartridge_cover','Removable nonmetallic cartridge cover','under_belt',rounded(240,300,4,0,0,978,10),'polymer',material='nonmetallic',default_hidden=True,cutaway=True,service_group='under_cartridge')
 under_tx_cuts=add_winding('under_tx_xy','Tx','under_belt',(186,226),(0,0,961),service_group='under_cartridge')
 under_rx_cuts=[]
 for x in (-42,42):
  under_rx_cuts+=add_winding(f'under_rx_xy_{x}','Rx','under_belt',(62,170),(x,0,968),pair='under_balanced_pair',service_group='under_cartridge')
 tx_former=rounded(205,245,4,0,0,959,6)
 rx_former=rounded(205,245,4,0,0,966,6)
 for cut in under_tx_cuts:tx_former=tx_former.cut(cut)
 for cut in under_rx_cuts:rx_former=rx_former.cut(cut)
 add('under_tx_former','Nonmetallic Tx former with open recessed return channel','under_belt',tx_former,'polymer',material='nonmetallic',service_group='under_cartridge')
 add('under_rx_former','Nonmetallic Rx former with separate return channels','under_belt',rx_former,'polymer',material='nonmetallic',service_group='under_cartridge')
 for x in (-102,102):
  for y in (-110,110):add(f'under_former_post_{x}_{y}','Nonmetallic winding former support','under_belt',cyl(3,28,(x,y,936)),'polymer',material='nonmetallic',service_group='under_cartridge')
 for x in (-128,128):
  add(f'under_slide_flange_{x}','Cartridge slide flange · mates to fixed rail','under_belt',box(40,270,8,x,0,934),'polymer',material='nonmetallic',service_group='under_cartridge')
 for x in (-106,106):
  add(f'under_coil_support_{x}','Nonmetallic cartridge coil support','under_belt',box(8,250,26,x,0,947),'polymer',material='nonmetallic',service_group='under_cartridge')
 for x in (-135,135):
  sx=1 if x>0 else -1
  rail=box(22,840,20,x,0,920)
  for sy in (-1,1):
   rail=rail.cut(box(24,20,6,x,sy*410,913))
   ear=box(82,20,14,sx*165,sy*410,923).cut(cyl(4.5,16,(sx*185,sy*410,915)))
   rail=rail.fuse(ear)
   for iz in range(2):
    shim=box(82,20,3,sx*165,sy*410,911.5+iz*3).cut(cyl(4.5,5,(sx*185,sy*410,909+iz*3)))
    add(f'under_height_shim_{x}_{sy}_{iz}','Removable nonmetallic height spacer · 3 mm nominal','under_belt',shim,'accent',material='nonmetallic',adjustment='Two 3 mm spacers installed; changing the pack changes nominal head height. Only the installed pose is checked; loads, tolerance, repeatability and range are unvalidated')
   bolt(f'under_slide_retainer_{x}_{sy}',sx*185,sy*410,880,length=56,material='nonmetallic',group='under_belt')
   nut=cyl(7,6,(sx*185,sy*410,930)).cut(cyl(4.2,8,(sx*185,sy*410,929)))
   add(f'under_slide_nut_{x}_{sy}','Spacer-pack clamp nut, outside withdrawal envelope','under_belt',nut,'polymer',material='nonmetallic')
  add(f'under_slide_rail_{x}','Nonmetallic cassette slide rail on replaceable spacer packs','under_belt',rail,'polymer',material='nonmetallic')
 # Pull lip sits below the belt and stays outside cartridge extraction travel.
 add('under_pull_handle','Cassette pull handle · release retainers first','under_belt',tube_between((-55,-174,951),(55,-174,951),6).fuse(tube_between((-55,-174,951),(-55,-145,951),6)).fuse(tube_between((55,-174,951),(55,-145,951),6)),'polymer',material='nonmetallic',service_group='under_cartridge')
 for x in (-100,100):bolt(f'under_cover_retainer_{x}',x,-135,973,length=8,material='nonmetallic',group='under_belt',r=3)
 # Transverse side heads: vertical XZ planes and axis Y. Clear of guide inner faces.
 for sy in (-1,1):
  y=sy*120
  shell=box(180,24,110,300,y,1060).cut(box(170,24,100,300,y-sy*5,1060))
  add(f'side_cartridge_{sy}','Nonmetallic transverse cartridge housing','transverse',shell,'module',material='nonmetallic',service_group=f'side_head_{sy}')
  add(f'side_face_cover_{sy}','Removable transverse face cover','transverse',box(180,3,110,300,sy*106.5,1060),'polymer',material='nonmetallic',default_hidden=True,cutaway=True,service_group=f'side_head_{sy}')
  arm=box(46,252,25,300,sy*258,1127.5)
  slot=cq.Workplane('XY').center(300,sy*185).slot2D(75,9,90).extrude(29).translate((0,0,1113)).val()
  add(f'side_arm_{sy}','Nonmetallic transverse arm with Y adjustment slot','transverse',arm.cut(slot),'polymer',material='nonmetallic',adjustment='75 x 9 mm slot in Y; nominal pose checked, full travel, collision and locking strength unverified')
  add(f'side_head_hanger_{sy}','Nonmetallic transverse-head top attachment','transverse',box(46,24,25,300,sy*120,1127.5),'polymer',material='nonmetallic')
  flange=box(70,80,8,300,sy*155,1144).cut(cyl(4.5,10,(300,sy*165,1139)))
  add(f'side_y_adjust_flange_{sy}','Y sliding head flange · positive retaining bolt','transverse',flange,'polymer',material='nonmetallic',service_group=f'side_head_{sy}')
  bolt(f'side_y_adjust_bolt_{sy}',300,sy*165,1115,length=39,material='nonmetallic',group='transverse')
  nut=cyl(7,6,(300,sy*165,1148)).cut(cyl(4.2,8,(300,sy*165,1147)))
  add(f'side_y_adjust_nut_{sy}','Y adjustment retained nut · material/rating unselected','transverse',nut,'polymer',material='nonmetallic')
  post=box(50,40,245,300,sy*420,1032.5)
  plate=box(70,16,160,300,sy*392,1075)
  for x in (280,320):
   post=post.cut(cyl(4.5,44,(x,398,1100),(0,1,0)) if sy>0 else cyl(4.5,44,(x,-398,1100),(0,-1,0)))
   cut=cq.Workplane('XZ').center(x,1075).slot2D(90,9,90).extrude(12,both=True).translate((0,sy*392,0)).val()
   plate=plate.cut(cut)
   bolt(f'side_clamp_bolt_{sy}_{x}',x,sy*384,1100,axis='y' if sy>0 else 'ny',length=62,group='transverse')
   nut=cyl(7,6,(x,sy*440,1100),(0,sy,0)).cut(cyl(4.2,8,(x,sy*439,1100),(0,sy,0)))
   add(f'side_z_adjust_nut_{sy}_{x}','Z carriage retained nut · load rating unselected','transverse',nut,'steel')
  add(f'side_support_post_{sy}','Transverse support post tied to lower module rail','transverse',post,'module')
  add(f'side_outer_bracket_{sy}','Transverse Z carriage with real 90 x 9 mm slots','transverse',plate,'steel',adjustment='Nominal Z pose shown; full travel, positive locking loads and calibration repeatability unverified')
 for sy in (-1,1):add(f'side_former_spacer_{sy}','Nonmetallic transverse former spacer','transverse',box(100,3,60,300,sy*125.5,1060),'polymer',material='nonmetallic',service_group=f'side_head_{sy}')
 side_cuts={-1:add_winding('side_tx_xz','Tx','transverse',(144,76),(300,-120,1055),'XZ',1,service_group='side_head_-1'),1:[]}
 for x in (266,334):side_cuts[1]+=add_winding(f'side_rx_xz_{x}','Rx','transverse',(54,60),(x,120,1055),'XZ',-1,pair='transverse_balanced_pair',service_group='side_head_1')
 for sy in (-1,1):
  former=box(166,4,96,300,sy*122,1060)
  for cut in side_cuts[sy]:former=former.cut(cut)
  add(f'side_winding_former_{sy}','Nonmetallic transverse former with open return channels','transverse',former,'polymer',material='nonmetallic',service_group=f'side_head_{sy}')
 # Optical carrier and adjustment slots. RGB observes upstream; timing must associate the item.
 optical_plate=box(220,820,12,-280,0,1538)
 for y in (-330,330):optical_plate=optical_plate.cut(cq.Workplane('XY').center(-280,y).slot2D(110,9,0).extrude(16).translate((0,0,1530)).val())
 add('optical_slotted_carrier','Slotted optical carrier · 100 mm nominal X adjustment','optical',optical_plate,'module',adjustment_status='Slot travel only; optics and field of view unselected')
 for sy in (-1,1):
  add(f'optical_carrier_hanger_{sy}','Optical carrier bracket','optical',box(90,12,75,-280,sy*409,1563),'steel')
  for x in (-310,-250):bolt(f'optical_carrier_fastener_{x}_{sy}',x,sy*330,1532,length=18,group='optical')
 add('rgb_body','RGB industrial camera envelope · hardware unselected','optical',rounded(90,84,66,-280,0,1500,6),'black')
 add('rgb_lens_barrel','RGB lens envelope','optical',cyl(26,22,(-280,0,1445)),'black')
 add('rgb_lens_glass','RGB lens aperture','optical',cyl(22,2,(-280,0,1443)),'glass',material='optical_glass')
 for sy in (-1,1):
  add(f'light_bar_{sy}','Diffuse illumination envelope','optical',rounded(220,35,28,-420,sy*150,1390,7),'black')
  add(f'light_diffuser_{sy}','Illumination diffuser','optical',rounded(206,28,3,-420,sy*150,1374.5,5),'light',material='nonmetallic')
  add(f'light_drop_arm_{sy}','Adjustable light support','optical',box(15,20,140,-375,sy*150,1462),'steel')
 # Optional exterior 3D geometry capture remains a separate option, not hidden material imaging.
 add('optional_3d_mount','OPTION: 3D mounting spacer','optical',box(65,45,16,-280,150,1531),'steel',optional=True)
 add('optional_3d_body','OPTION: exterior 3D geometry sensor envelope','optical',rounded(100,65,56,-280,150,1495,6).rotate((-280,150,1495),(-279,150,1495),-18.5),'accent',optional=True,measurement='Exterior geometry/pose only; device and calibration unselected')
 for y in (130,170):add(f'optional_3d_aperture_{y}','OPTION: 3D optical aperture','optical',cyl(10,3,(-280,y,1464)).rotate((-280,150,1495),(-279,150,1495),-18.5),'glass',material='optical_glass',optional=True)
 add('optical_top_service_cover','Removable optical service cover','optical',rounded(260,430,6,-280,70,1552,9),'panel',default_hidden=True,cutaway=True)
 for x in (-390,-170):
  for y in (-100,240):add(f'optical_lid_spacer_{x}_{y}','Optical service-cover standoff','optical',cyl(5,5,(x,y,1544)),'steel')
 # Acquisition/control enclosure. Shell, front, removable mounting tray, device envelopes.
 shell=rounded(340,240,440,820,-620,1190,10).cut(rounded(328,240,428,820,-626,1190,6))
 add('control_enclosure_shell','Acquisition and control enclosure shell','controls',shell,'module')
 add('control_front_panel','Removable control front panel','controls',rounded(340,6,440,820,-743,1190,8),'panel',service_group='control_front')
 add('control_status_window','Local acquisition status window envelope','controls',box(110,3,60,820,-747,1310),'black',material='nonmetallic',service_group='control_front')
 for x in (675,965):
  for zz in (995,1385):bolt(f'control_panel_retainer_{x}_{zz}',x,-747,zz,axis='y',length=16,group='controls',r=3)
 add('control_backplate','Removable electronics mounting tray','controls',box(305,5,400,820,-521,1190),'steel')
 for x in (690,950):
  for zz in (1030,1350):add(f'control_tray_standoff_{x}_{zz}','Electronics tray standoff','controls',cyl(6,12.5,(x,-518.5,zz),(0,1,0)),'steel')
 for x,w,label in [(725,90,'Synchronous acquisition'),(845,110,'Control and compute')]:
  add(f'control_device_spacer_{x}','Electronics envelope mounting spacer','controls',box(w-10,4,100,x,-525.5,1280),'steel',default_hidden=True)
  add(f'control_device_{x}',label+' device envelope · unselected','controls',box(w,95,120,x,-575,1280),'black',default_hidden=True,device_status='Unspecified envelope, no channel count, resolution, frequency or power claim')
 add('control_psu_spacer','Power-conditioning mounting spacer','controls',box(190,6.5,65,820,-526.75,1095),'steel',default_hidden=True)
 add('control_psu','Power-conditioning envelope','controls',box(210,80,85,820,-570,1095),'steel',default_hidden=True)
 for x in (680,960):
  add(f'control_mounting_ear_{x}','Enclosure external mounting ear','controls',slot_plate(50,85,8,x,-470,1360,[(x,-470)]),'steel')
  add(f'control_mounting_brace_{x}','Enclosure carrier bracket','controls',box(100 if x==680 else 45,95,25,650 if x==680 else x,-452.5,1050),'module')
 for zz in (1050,1360):add(f'control_carrier_{zz}','Enclosure carrier rail to module portal','controls',box(400,40,35,800,-445,zz),'module')
 # Interface connector envelopes are dimensioned examples, not selected IP-rated hardware.
 for ix,label in enumerate(('power','host_io','encoder','optics','coil_A','coil_B')):
  x=700+ix*48
  add(f'control_connector_{label}','Interface connector: '+label.replace('_',' '),'controls',cyl(10,22,(x,-620,948)),'black',interface=label,connector_status='Unselected connector/pinout/seal/EMC concept')
 # Encoder association mounted outside reservation, linked to reference host roller shaft.
 add('encoder_body','Host encoder association device envelope','encoder',cyl(28,54,(-1050,-half-105,931),(0,1,0)),'accent')
 add('encoder_coupling','Illustrative encoder shaft coupling','encoder',cyl(10,35,(-1050,-half-51,931),(0,1,0)),'steel')
 add('encoder_bracket','Slotted encoder bracket envelope','encoder',box(95,8,100,-1050,-half-104,900).cut(box(14,12,55,-1050,-half-104,922.5)),'steel')
 # Supported cable routes mostly outside test volume; coil leads necessarily enter it.
 cable('cable_optical',[(-235,0,1500),(-200,-360,1510),(-200,-460,1510),(530,-460,1510),(530,-500,930),(844,-620,948)],purpose='RGB/illumination association cable route')
 cable('cable_optional_3d',[(-230,150,1495),(-200,350,1510),(-200,460,1510),(530,460,1510),(530,460,930),(530,-500,930),(844,-620,948)],purpose='Optional 3D cable route envelope',optional=True)
 cable('cable_under_lead',[(100,-140,951),(160,-170,951),(160,-500,951),(620,-500,951),(892,-620,948)],group='under_belt',purpose='Under-belt acquisition lead · routing influence unvalidated')
 cable('cable_side_near',[(350,-132,1080),(350,-390,1150),(530,-460,1150),(530,-500,950),(940,-620,930),(940,-620,948)],group='transverse',purpose='Transverse Tx lead · routing influence unvalidated')
 cable('cable_side_far',[(350,132,1080),(350,390,1150),(530,420,1150),(530,420,950),(530,-500,950),(940,-620,930),(940,-620,948)],group='transverse',purpose='Transverse Rx lead · routing influence unvalidated')
 cable('cable_encoder',[(-1050,-half-105,931),(-1050,-420,860),(620,-420,860),(796,-620,948)],purpose='Encoder association cable route')
 for x in (0,500):
  for sy in (-1,1):
   bracket=box(25,40,4,x,sy*450,1568).fuse(box(15,12,49,x,sy*460,1541.5))
   add(f'cable_saddle_bracket_{x}_{sy}','Nonmetallic optical cable saddle support','cables',bracket,'polymer',material='nonmetallic',hold='Support loads, clamp closure and selected material require engineering review')
   saddle=tube_between((x-12.5,sy*460,1510),(x+12.5,sy*460,1510),7,4.5)
   add(f'cable_clip_{x}_{sy}','Optical cable saddle · nominal bore clearance','cables',saddle,'polymer',material='nonmetallic',hold='Nominal 0.5 mm cable-to-bore clearance; actual clamping, retention and abrasion unvalidated')
 # Removable calibration accessory, hidden in operating views. No reference standard selected.
 carrier=rounded(100,140,6,-400,0,1003,8).cut(rounded(80,120,6,-400,0,1006,6))
 add('calibration_carrier','Removable nonmetallic calibration coupon carrier','lane',carrier,'accent',material='nonmetallic',default_hidden=True,calibration_accessory=True,status='Nominal belt-contact accessory; safe insertion, calibration standards and repeatability unresolved')
 add('calibration_handle','Removable carrier handle · insert/remove upstream','lane',box(110,22,6,-500,0,1003),'polymer',material='nonmetallic',default_hidden=True,calibration_accessory=True)
 add('calibration_coupon_envelope','Unselected reference coupon envelope','lane',box(60,100,1,-400,0,1003.5),'panel',material='reference_material_unselected',default_hidden=True,calibration_accessory=True,status='No alloy, target response or calibration certificate asserted')
 # Restore a parameterised vertical datum by translating completed geometry.
 if dz:
  for part in parts:part['shape']=part['shape'].translate((0,0,dz))
 return parts


def export(parts,p):
 out=ROOT/'exports';web=ROOT/'web';qa=ROOT/'verification'
 for d in (out,web,qa,out/'groups',out/'selections'):d.mkdir(parents=True,exist_ok=True)
 selections={'module_assembly':[v for v in parts if v['scope']=='module'],'module_with_host':parts,'host_reference':[v for v in parts if v['scope']=='host_reference']}
 export_receipts={}
 for name,selected in selections.items():
  a=cq.Assembly(name='Ferrosift_M01_W1_'+name)
  for v in selected:a.add(v['shape'],name=v['id'],color=cq.Color(*rgb(v['color'])))
  print('Exporting '+name+f' ({len(selected)} named components)',flush=True)
  target=out/(name+'.step');a.export(str(target),exportType='STEP',unit='MM',outputUnit='MM')
  compound=cq.Compound.makeCompound([v['shape'] for v in selected]);compound.exportBrep(str(out/(name+'.brep')))
  reopened=cq.importers.importStep(str(target)).val();v0=sum(v['shape'].Volume() for v in selected);b0=bbox(compound);b1=bbox(reopened)
  error=abs(reopened.Volume()-v0)/v0;bd=max(abs(a-b) for side in ('min','max') for a,b in zip(b0[side],b1[side]))
  passed=reopened.isValid() and len(compound.Solids())==len(reopened.Solids()) and error<1e-6 and bd<1e-3
  export_receipts[name]={'status':'passed' if passed else 'failed','components':len(selected),'source_solids':len(compound.Solids()),'reimported_solids':len(reopened.Solids()),'reimported_valid':reopened.isValid(),'relative_volume_error':error,'bbox_difference_mm':bd,'bbox':b0,'step_sha256':digest(target)}
  if not passed:raise ValueError('STEP roundtrip failure: '+name)
 groups=defaultdict(list)
 for v in parts:groups[v['group']].append(v)
 for name,selected in groups.items():
  cq.exporters.export(cq.Compound.makeCompound([v['shape'] for v in selected]),str(out/'groups'/f'{name}.step'))
 selection_sets={
  'calibration_accessory':[v for v in parts if v.get('calibration_accessory')],
  'under_cartridge':[v for v in parts if v.get('service_group')=='under_cartridge'],
  'optical_lid':[v for v in parts if v['id']=='optical_top_service_cover'],
  'controls_open':[v for v in parts if v['group']=='controls' and not v.get('service_group')=='control_front' and not v['id'].startswith('control_panel_retainer')],
  'controls_front':[v for v in parts if v.get('service_group')=='control_front'],
  'under_windings':[v for v in parts if v.get('coil',{}).get('plane')=='XY' or v.get('winding_id','').startswith('under_')],
  'transverse_windings':[v for v in parts if v.get('coil',{}).get('plane')=='XZ' or v.get('winding_id','').startswith('side_')],
  'winding_detail':[v for v in parts if v.get('coil') or v.get('winding_id') or v['id'] in ('under_tx_former','under_rx_former','side_winding_former_-1','side_winding_former_1')]}
 for name,selected in selection_sets.items():cq.exporters.export(cq.Compound.makeCompound([v['shape'] for v in selected]),str(out/'selections'/f'{name}.step'))
 (out/'selections/selection_manifest.json').write_text(json.dumps({k:[v['id'] for v in vs] for k,vs in selection_sets.items()},indent=2)+'\n')
 print('Tessellating source CAD solids',flush=True)
 objects=[tessellate(v) for v in parts]
 for name,selected in selections.items():write_glb([v for v in objects if v['id'] in {s['id'] for s in selected}],out/(name+'.glb'))
 sources={str(f.relative_to(ROOT)):digest(f) for folder in ('cad','design_basis') for f in (ROOT/folder).glob('*') if f.suffix in ('.py','.json')}
 bounds={name:export_receipts[name]['bbox'] for name in selections}
 packet={'schemaVersion':2,'releaseId':'Ferrosift_M01_W1_20261015','units':'mm','coordinateSystem':'X travel, Y across, Z up','objects':objects,'bounds':bounds,'provenance':{'kind':'source_CAD_tessellation','cadquery':cq.__version__,'sourceSha256':sources,'moduleStepSha256':digest(out/'module_assembly.step'),'status':'Proposed retrofit research geometry; no fabrication or performance certification'},'exclusionEnvelope':p['exclusion_test_envelope'],'serviceZones':[{'id':'under_cartridge','min':[-148,-1030,930],'max':[148,150,980],'label':'850 mm cartridge withdrawal after isolation, disconnection and external support; not validated operator access'},{'id':'control_front','min':[645,-1100,960],'max':[995,-740,1420],'label':'350 mm panel removal reservation; handling and access unvalidated'}],'footprints':{'camera':p['optical']['footprint_example'],'experimentalLane':p['lane'],'hostBeltWidth':p['host']['belt_width'],'validatedSensingWidth':None},'coilConfigurations':{'A':p['under_belt'],'B':p['transverse']},'limitations':['Central 180 mm lane is a mechanical experimental arrangement, not sensor coverage or accepted material limits.','Full-width arrays, fields, sensitivity, metal/host compatibility, timing and process performance are unvalidated.','Coil conductors and leads are intentionally inside the experimental metal-exclusion reservation. Its final extent must be measured.']}
 (web/'module-assembly.json').write_text(json.dumps(packet,separators=(',',':')))
 manifest={'schema_version':2,'release_id':packet['releaseId'],'generated_utc':datetime.now(timezone.utc).isoformat(),'units':'mm','coordinate_system':packet['coordinateSystem'],'status':packet['provenance']['status'],'source_sha256':sources,'part_count':len(parts),'scope_counts':dict((k,len(v)) for k,v in selections.items()),'bounds':bounds,'parts':[{**{k:v for k,v in v.items() if k!='shape'},'bbox':bbox(v['shape']),'volume_mm3':v['shape'].Volume(),'solid_count':len(v['shape'].Solids())} for v in parts],'groups':{k:{'file':f'groups/{k}.step','ids':[v['id'] for v in vs],'sha256':digest(out/'groups'/f'{k}.step')} for k,vs in groups.items()},'exports':{f.name:{'bytes':f.stat().st_size,'sha256':digest(f)} for f in out.iterdir() if f.suffix in ('.step','.brep','.glb')},'geometric_checks':export_receipts,'limitations':packet['limitations']}
 (out/'assembly_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 receipt={'status':'passed','generated_utc':datetime.now(timezone.utc).isoformat(),'components':len(parts),'triangle_count':sum(len(v['indices'])//3 for v in objects),'vertex_count':sum(len(v['vertices'])//3 for v in objects),'all_source_components_valid':all(v['shape'].isValid() for v in parts),'roundtrips':export_receipts,'source_sha256':sources,'web_sha256':digest(web/'module-assembly.json'),'limitations':'Source/STEP geometry integrity only. No physical or electromagnetic validation.'}
 (qa/'cad_export_validation.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k] for k in ('status','components','triangle_count','vertex_count')}),flush=True)
 return receipt
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--validate-only',action='store_true');parser.add_argument('--host-width',type=float);args=parser.parse_args()
 p=json.loads((ROOT/'design_basis/parameters.json').read_text())
 if args.host_width:p['host']['belt_width']=args.host_width
 before={str(f):digest(f) for folder in ('cad','design_basis') for f in (ROOT/folder).glob('*') if f.suffix in ('.py','.json')}
 parts=build(p)
 if args.validate_only:print(json.dumps({'status':'passed','components':len(parts),'all_source_components_valid':all(v['shape'].isValid() for v in parts),'host_width_mm':p['host']['belt_width'],'host_belt_bbox':bbox(next(v['shape'] for v in parts if v['id']=='host_carrying_belt'))}))
 else:
  if args.host_width:raise ValueError('Variants only allowed with --validate-only')
  receipt=export(parts,p);receipt['source_unchanged_during_build']=all(digest(f)==h for f,h in before.items())
  (ROOT/'verification/cad_export_validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
  if not receipt['source_unchanged_during_build']:raise ValueError('Source changed during build; rebuild required')
