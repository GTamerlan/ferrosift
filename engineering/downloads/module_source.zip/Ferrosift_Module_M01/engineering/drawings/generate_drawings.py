#!/usr/bin/env python3
"""Editable A3 sheets from exact OpenCascade STEP projections. Research dimensions only."""
from pathlib import Path
import hashlib, html, json, math, textwrap
import fitz
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'drawings'; PROJ=OUT/'projections'
INK='#17282d'; MUTED='#52686f'; TEAL='#087f80'; LIGHT='#d6e1e4'; PALE='#edf5f5'; AMBER='#a35b12'
FONT='Arial,Helvetica,sans-serif'
CONTRACT=json.loads((ROOT/'design_basis/geometry_contract.json').read_text())
MAN=json.loads((ROOT/'exports/assembly_manifest.json').read_text())
PARTS=MAN.get('parts',MAN.get('objects',[]))
STEP_SHA=hashlib.sha256((ROOT/'exports/module_with_host.step').read_bytes()).hexdigest()
SHEETS=[];CHECKS=[]
def esc(t):return html.escape(str(t))
def n(v):return f'{v:.3f}'.rstrip('0').rstrip('.') if isinstance(v,float) else str(v)
def bpoints(part):
    bb=part['bbox'];return bb['min'],bb['max']
def bounds(parts):
    coords=[bpoints(p) for p in parts]
    return [min(v[0][i] for v in coords) for i in range(3)], [max(v[1][i] for v in coords) for i in range(3)]
def catparts(*cats):return [p for p in PARTS if p['category'] in cats]
def findparts(s):return [p for p in PARTS if s.lower() in (p['id']+' '+p['name']).lower()]
def part(ident):return next(p for p in PARTS if p['id']==ident)
def center(ident):
    lo,hi=bpoints(part(ident));return [(a+b)/2 for a,b in zip(lo,hi)]
def norm(v):
    l=math.sqrt(sum(x*x for x in v));return [x/l for x in v]
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def dot(a,b):return sum(x*y for x,y in zip(a,b))

class Page:
    def __init__(self,num,title,subtitle):
        self.num=num;self.title=title;self.a=[]
        self.a.append('<svg xmlns="http://www.w3.org/2000/svg" width="420mm" height="297mm" viewBox="0 0 420 297">')
        self.a.append(f'<metadata>Ferrosift retrofit module M01-W1; model-derived HLR and solid sections; geometry mm; A3 landscape; {esc(title)}</metadata>')
        self.rect(0,0,420,297,'#fff');self.rect(8,8,404,281,'none',LIGHT,.25)
        self.text(14,16,'FERROSIFT / ENGINEERING',3.7,TEAL,bold=True)
        self.text(14,25,title,6.0,INK,bold=True)
        self.text(14,32,subtitle,2.6,MUTED)
        self.text(406,16,'CONCEPT ONLY',3.4,AMBER,bold=True,anchor='end')
        self.text(406,22,'NOT FOR FABRICATION',2.7,AMBER,bold=True,anchor='end')
        self.line(14,36,406,36,TEAL,.6)
    def text(self,x,y,t,size=2.9,color=INK,bold=False,anchor='start',rotation=None):
        transform=f' transform="rotate({rotation} {x} {y})"' if rotation else ''
        self.a.append(f'<text x="{x}" y="{y}" font-family="{FONT}" font-size="{size}" font-weight="{700 if bold else 400}" fill="{color}" text-anchor="{anchor}"{transform}>{esc(t)}</text>')
    def line(self,x1,y1,x2,y2,color=INK,width=.25,dash=None):
        if dash:
            # Explicit vector segments preserve dashes in SVG-to-PDF renderers
            # which otherwise discard SVG stroke-dasharray attributes.
            on,off=[float(x) for x in dash.split()];length=math.hypot(x2-x1,y2-y1)
            if not length:return
            d=0
            while d<length:
                end=min(length,d+on)
                self.line(x1+(x2-x1)*d/length,y1+(y2-y1)*d/length,
                          x1+(x2-x1)*end/length,y1+(y2-y1)*end/length,color,width)
                d+=on+off
            return
        self.a.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="{width}"/>')
    def rect(self,x,y,w,h,fill='none',stroke=None,width=.25,dash=None):
        if dash:
            self.rect(x,y,w,h,fill)
            for a,b in [((x,y),(x+w,y)),((x+w,y),(x+w,y+h)),((x+w,y+h),(x,y+h)),((x,y+h),(x,y))]:self.line(*a,*b,stroke or INK,width,dash)
            return
        self.a.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}" stroke="{stroke or "none"}" stroke-width="{width}"/>')
    def circle(self,x,y,r,fill='none',stroke=INK,width=.25):
        self.a.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{width}"/>')
    def polygon(self,points,fill,stroke=None,width=.25):
        pts=' '.join(f'{x},{y}' for x,y in points)
        self.a.append(f'<polygon points="{pts}" fill="{fill}" stroke="{stroke or "none"}" stroke-width="{width}"/>')
    def paragraph(self,x,y,t,width=80,size=2.8,color=MUTED,lineheight=4.3):
        lines=[]
        for para in str(t).split('\n'):
            current=''
            for word in para.split():
                trial=(current+' '+word).strip()
                if current and fitz.get_text_length(trial,fontname='helv',fontsize=size)>width-.5:
                    lines.append(current);current=word
                else:current=trial
            lines.append(current)
        for i,line in enumerate(lines):self.text(x,y+i*lineheight,line,size,color)
        return y+len(lines)*lineheight
    def note(self,x,y,w,title,body):
        self.text(x,y,title,3.1,TEAL,bold=True)
        return self.paragraph(x,y+5,body,w)+3
    def arrow(self,x1,y1,x2,y2,color=TEAL,width=.45):
        self.line(x1,y1,x2,y2,color,width)
        angle=math.atan2(y2-y1,x2-x1);s=2
        self.polygon([(x2,y2),(x2-s*math.cos(angle-.5),y2-s*math.sin(angle-.5)),(x2-s*math.cos(angle+.5),y2-s*math.sin(angle+.5))],color)
    def dimh(self,x1,x2,y,ay1,ay2,label,color=INK):
        self.line(x1,ay1,x1,y+(1 if y>ay1 else -1),LIGHT,.2)
        self.line(x2,ay2,x2,y+(1 if y>ay2 else -1),LIGHT,.2)
        self.line(x1,y,x2,y,color,.2)
        for x,sign in ((x1,1),(x2,-1)):
            self.polygon([(x,y),(x+sign*1.6,y-.5),(x+sign*1.6,y+.5)],color)
        self.text((x1+x2)/2,y-1.3,label,2.7,color,anchor='middle')
    def dimv(self,y1,y2,x,ax1,ax2,label,color=INK):
        self.line(ax1,y1,x-1,y1,LIGHT,.2);self.line(ax2,y2,x-1,y2,LIGHT,.2)
        self.line(x,y1,x,y2,color,.2)
        for y,sign in ((y1,1),(y2,-1)):
            self.polygon([(x,y),(x-.5,y+sign*1.6),(x+.5,y+sign*1.6)],color)
        self.text(x-1.5,(y1+y2)/2,label,2.7,color,anchor='middle',rotation=-90)
    def leader(self,x,y,tx,ty,label,color=TEAL):
        length=fitz.get_text_length(label,fontname='helv',fontsize=2.7)
        end=tx+length+2 if x>tx+length else tx-1
        self.circle(x,y,.6,color,color);self.line(x,y,end,ty-1,color,.2)
        self.text(tx+1,ty,label,2.7,color)
    def table(self,x,y,width,headers,rows,colwidths=None,rowh=7,size=2.7):
        cs=colwidths or [width/len(headers)]*len(headers)
        self.rect(x,y,width,rowh,PALE)
        xx=x
        for h,w in zip(headers,cs):self.text(xx+2,y+rowh*.67,h,size,TEAL,bold=True);xx+=w
        for i,row in enumerate(rows):
            yy=y+rowh*(i+1);self.line(x,yy,x+width,yy,LIGHT,.2);xx=x
            for v,w in zip(row,cs):self.text(xx+2,yy+rowh*.67,v,size,INK);xx+=w
        self.line(x,y+rowh*(len(rows)+1),x+width,y+rowh*(len(rows)+1),LIGHT,.2)
        return y+rowh*(len(rows)+1)
    def view(self,name,box,denom=None,caption=None):
        d=json.loads((PROJ/f'{name}.json').read_text());l,b,r,t=d['bounds'];x,y,w,h=box
        if denom is None:
            need=max((r-l)/w,(t-b)/h)
            denom=next(v for v in [2,5,10,15,20,25,30,40,50,75,100] if v>=need)
        scale=1/denom;dw=(r-l)*scale;dh=(t-b)*scale
        ox=x+(w-dw)/2-l*scale;oy=y+(h-dh)/2+t*scale
        if dw>w+.01 or dh>h+.01:raise ValueError(f'{name} exceeds allocated viewport: {dw}x{dh}, {w}x{h}')
        self.a.append(f'<g transform="translate({ox},{oy}) scale({scale}, {-scale})" fill="none" stroke="{INK}" stroke-width="{.22/scale}" stroke-linecap="round" stroke-linejoin="round">')
        for triangle in d.get('fill_triangles',[]):
            pts=' '.join(f'{px},{py}' for px,py in triangle)
            self.a.append(f'<polygon points="{pts}" fill="#d8eceb" stroke="none"/>')
        self.a.extend(f'<path d="{p}"/>' for p in d['paths']);self.a.append('</g>')
        label=caption or name.upper().replace('_',' ')
        if 'not to scale' not in label.lower() and 'no manufacturing scale' not in label.lower():label+=f' / 1:{denom}'
        self.text(x,y+h+5,label,2.7,TEAL,bold=True)
        CHECKS.append({'sheet':self.num,'view':name,'scale_denominator':denom,'viewport_mm':box,'projected_size_mm':[dw,dh],'projection_input_sha256':d['input_sha256']})
        normal=norm(d['normal']);vx=norm(d['x_direction']);vy=cross(normal,vx)
        def mapping(p):return ox+dot(p,vx)*scale,oy-dot(p,vy)*scale
        mapping.scale=scale;mapping.ox=ox;mapping.oy=oy;mapping.denom=denom
        return mapping
    def finish(self):
        self.line(14,263,406,263,TEAL,.5)
        self.text(14,270,'DIMENSIONS: mm  |  SCALE PER VIEW AT A3  |  PROPOSED RESEARCH GEOMETRY',2.7,INK,bold=True)
        self.text(14,276,'No approved fit, tolerance, load, electromagnetic coverage, throughput or safeguarding rating.',2.6,MUTED)
        self.text(14,282,f'Source: module_with_host.step | SHA-256 {STEP_SHA[:16]} | geometry revision M01-W1',2.5,MUTED)
        self.text(405,270,f'FS-M01-{self.num:02d}',4,INK,bold=True,anchor='end')
        self.text(405,276,f'REV M01-W1 / 2026-10-15 / {self.num} OF 6',2.8,MUTED,anchor='end')
        self.text(405,282,'CONCEPT REVIEW - NOT FOR FABRICATION',2.5,AMBER,bold=True,anchor='end')
        self.a.append('</svg>');path=OUT/f'FS-M01-{self.num:02d}.svg';path.write_text('\n'.join(self.a));SHEETS.append(path)


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def verify_fresh():
    for definition in json.loads((OUT/'view_definitions.json').read_text()):
        inputs=b''.join((ROOT/source).read_bytes() for source in definition['sources'])
        expected=hashlib.sha256(inputs+json.dumps(definition,sort_keys=True).encode()+(OUT/'project_views.py').read_bytes()).hexdigest()
        record=json.loads((PROJ/f"{definition['name']}.json").read_text())
        if record['input_sha256']!=expected:raise ValueError('Stale projection: '+definition['name'])
    if sha(ROOT/'exports/module_with_host.step')!=STEP_SHA:raise ValueError('Assembly changed during drawing generation')
    for k,h in MAN['source_sha256'].items():
        if sha(ROOT/k)!=h:raise ValueError('CAD manifest source changed: '+k)

def main():
    verify_fresh()
    # Annotation values are intentionally frozen to reviewed M01-W1 geometry; do not silently drift.
    assertions={'belt_width':(CONTRACT['host']['belt_width'],600),'belt_top_z':(CONTRACT['host']['belt_top_z'],1000),
     'lane_width':(CONTRACT['lane']['clear_width'],180),'optics_x':(CONTRACT['optical']['rgb_centre'][0],-280),
     'A_x':(CONTRACT['under_belt']['tx_centre'][0],0),'B_x':(CONTRACT['transverse']['station_x'],300),
     'coil_core_top_standoff':(CONTRACT['under_belt']['standoff_coil_top_to_belt_top'],30.85),
     'enclosure_width':(CONTRACT['controls']['enclosure_size'][0],340),'enclosure_height':(CONTRACT['controls']['enclosure_size'][2],440)}
    byid={p['id']:p for p in PARTS}
    def bb(ident,side,axis):return byid[ident]['bbox'][side][axis]
    assertions.update({
      'carrying_belt_thickness':(bb('host_carrying_belt','max',2)-bb('host_carrying_belt','min',2),4),
      'support_window_thickness':(bb('module_support_window','max',2)-bb('module_support_window','min',2),6),
      'closed_head_to_support_gap':(bb('module_support_window','min',2)-bb('under_cartridge_cover','max',2),10),
      'actual_Rx_core_top_to_belt':(bb('host_carrying_belt','max',2)-bb('under_rx_xy_42','max',2),30.85),
      'actual_Rx_insulation_top_to_belt':(bb('host_carrying_belt','max',2)-bb('under_rx_xy_42_insulation','max',2),30.6),
      'actual_Rx_terminal_top_to_belt':(bb('host_carrying_belt','max',2)-bb('under_rx_xy_42_terminal_0','max',2),30.2),
      'actual_Tx_core_top_to_belt':(bb('host_carrying_belt','max',2)-bb('under_tx_xy','max',2),37.85),
      'actual_Tx_insulation_top_to_belt':(bb('host_carrying_belt','max',2)-bb('under_tx_xy_insulation','max',2),37.6),
      'actual_Tx_terminal_top_to_belt':(bb('host_carrying_belt','max',2)-bb('under_tx_xy_terminal_0','max',2),37.2),
      'actual_Tx_core_extent_x':(bb('under_tx_xy','max',0)-bb('under_tx_xy','min',0),185.5),
      'actual_Tx_core_extent_y':(bb('under_tx_xy','max',1)-bb('under_tx_xy','min',1),228.5),
      'actual_Tx_insulation_extent_x':(bb('under_tx_xy_insulation','max',0)-bb('under_tx_xy_insulation','min',0),186),
      'actual_Tx_insulation_extent_y':(bb('under_tx_xy_insulation','max',1)-bb('under_tx_xy_insulation','min',1),229),
      'transverse_main_plane_spacing':(CONTRACT['transverse']['rx_centres'][0][1]-CONTRACT['transverse']['tx_centre'][1],238.6),
      'core_diameter':(CONTRACT['winding_geometry']['conductor_diameter_mm'],.9),
      'insulation_od':(CONTRACT['winding_geometry']['insulation_od_mm'],1.4),
      'path_centre_pitch':(CONTRACT['winding_geometry']['centre_pitch_mm'],3.8),
      'return_top_to_shell_bottom':(bb('under_cartridge_shell','min',2)-bb('host_return_belt','max',2),64),
      'nominal_shell_to_host_rail_clearance':(bb('under_cartridge_shell','min',2)-bb('host_side_rail_-1','max',2),30)
    })
    for k,(actual,want) in assertions.items():
        if abs(actual-want)>1e-6:raise ValueError(f'Revise annotation {k}: actual {actual}, expected {want}')
    exec((OUT/'compose_sheets.py').read_text(),globals())
    draw_all()
    pdf=fitz.open()
    for f in SHEETS:
        doc=fitz.open(stream=f.read_bytes(),filetype='svg')
        converted=fitz.open('pdf',doc.convert_to_pdf());pdf.insert_pdf(converted)
    pdf.set_metadata({'title':'Ferrosift retrofit sensing module - M01-W1 concept drawings','author':'Ferrosift','subject':'Actual STEP geometry with proposed dimensions; research review, not fabrication release','keywords':'A3,retrofit,module,STEP,research,host-interface'})
    target=OUT/'module_drawings.pdf';pdf.save(target,garbage=4,deflate=True)
    check=fitz.open(target)
    assert len(check)==6
    for i,page in enumerate(check):
        assert abs(page.rect.width-420*72/25.4)<.1 and abs(page.rect.height-297*72/25.4)<.1
        page.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False).save(OUT/'previews'/f'FS-M01-{i+1:02d}.png')
    verify_fresh()
    report={'revision':'M01-W1','status':'GEOMETRY_CHECKS_PASS_VISUAL_REVIEW_PENDING','created_utc':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),'pdf':'module_drawings.pdf','page_count':len(check),'a3_landscape_mm':[420,297],'source_step_sha256':STEP_SHA,'source_manifest_sha256':sha(ROOT/'exports/assembly_manifest.json'),'source_contract_sha256':sha(ROOT/'design_basis/geometry_contract.json'),'projection_method':'OpenCascade exact visible-edge HLR; actual solid/plane section intersections where named','render_backend':'PyMuPDF SVG to PDF and raster (Poppler unavailable in environment)','checks':{'A3_page_size':'PASS','six_pages':'PASS','source_hashes_current':'PASS','viewports_fit':'PASS','annotation_contract_matches':'PASS','visual_review':'PENDING','physical_sensing_and_fabrication_validation':'NOT PERFORMED'},'views':CHECKS,'annotated_basis_mm':{k:v[0] for k,v in assertions.items()},'sheets':[{'path':f.name,'sha256':sha(f)} for f in SHEETS],'pdf_sha256':sha(target),'limitations':['All dimensions and interfaces are proposed research geometry.','Neither CAD validity nor the drawing checks establish load capacity, operational safety, compatibility or electromagnetic performance.','Usable aperture, full-width scale-up and the advantage of complementary sensing directions are unvalidated.']}
    (OUT/'drawing_manifest.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'pdf':str(target),'pages':len(check),'views':len(CHECKS),'sha256':sha(target)},indent=2))
if __name__=='__main__':main()
