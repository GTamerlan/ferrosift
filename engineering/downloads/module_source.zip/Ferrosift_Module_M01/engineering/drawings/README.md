# Ferrosift retrofit module drawings M01-W1

`module_drawings.pdf` contains six A3 landscape concept sheets. `FS-M01-01.svg` through `FS-M01-06.svg` are editable vector sources. The geometry in each view is derived from the current generated STEP solids using OpenCascade visible-edge projection; sheet 3 uses exact solid/plane intersections at X42 mm. These are coordination drawings, not a fabrication release. The preceding M01 baseline is preserved under `../../history/M01_baseline_20261015_0907UTC/`.

1. General arrangement and module/host boundary.
2. Under-belt XY and transverse XZ winding arrangements.
3. Host interface, belt/support/head/return-run section and experimental exclusion reservation.
4. RGB, optional exterior 3D geometry and sequential fragment association.
5. Cartridge withdrawal, optical access and calibration/service conditions.
6. Acquisition/control enclosure and host interfaces.

The 600 mm host belt is context. The 180 mm lane is a mechanical research passage, not a measured sensing aperture or an accepted fragment-size limit. The six functional winding paths (two Tx and four Rx) contain three illustrative perimeter passes per path. The open spiral transitions and recessed returns are unoptimized research geometry. Optical/induction fusion already exists; this concept tests whether conditioning directional/frequency responses on exterior geometry and pose adds useful information over strong simpler baselines.

The source retains project Z=1000 mm as the nominal carrying surface. Heights relative to the belt equal Z minus 1000. The two electromagnetic stations are longitudinally separated; the same object does not occupy both simultaneously. Last usable observation and downstream decision timing remain to be measured.

All tolerances, structural adequacy, electromagnetic compatibility, field coverage, electronics, guarding, service safety and performance remain unvalidated. Consult the engineering verification reports for the specific geometric checks and exclusions. No physical test is implied by a valid STEP export, a collision check, or these drawings.

## Reproduce from the project root

```sh
PYTHONDONTWRITEBYTECODE=1 XDG_CACHE_HOME=/tmp/ferrosift-module-drawings-cache engineering/conveyor_concept_20261013/.venv-cad/bin/python module_package_20261015_v01/engineering/drawings/project_views.py
PYTHONDONTWRITEBYTECODE=1 XDG_CACHE_HOME=/tmp/ferrosift-module-drawings-cache engineering/conveyor_concept_20261013/.venv-cad/bin/python module_package_20261015_v01/engineering/drawings/generate_drawings.py
PYTHONDONTWRITEBYTECODE=1 engineering/conveyor_concept_20261013/.venv-cad/bin/python module_package_20261015_v01/engineering/drawings/check_drawings.py
```

Regeneration refuses stale CAD/projection hashes. After any meaningful change, inspect all six PNG pages in `previews/` and update `drawing_manifest.json` with the actual visual-review outcome. `drawing_layout_qa.json` checks page dimensions and text containment; it is not a substitute for visual inspection or engineering review.

Five standalone review views are generated in `../figures/review/`. After rendering the main figures, run `project_views.py --config module_package_20261015_v01/engineering/drawings/review_view_definitions.json` with the same Python runtime, then `generate_review_views.py`. Their separate manifest binds each view to the context STEP and mesh, declares the section/crop and translation scope, and records actual winding-solid intersection checks. Review all five PNGs before marking that manifest complete.
