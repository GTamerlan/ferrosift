# M02 independent geometry review

These scripts test nominal source and exported geometry. They do not qualify materials, loads, electrical construction, electromagnetic response, sensing coverage, sealing, bend ratings, operation or fabrication.

Run from the extracted package root, with a Python interpreter containing the CadQuery/OCP versions recorded in the export provenance. Set `PYTHONDONTWRITEBYTECODE=1` and point `XDG_CACHE_HOME` to a writable temporary cache. Each script derives `engineering/` from its own location; it does not require the original workstation path.

After the CAD author freezes all `engineering/cad/*.py` and `engineering/design_basis/*.json`, run:

```sh
python verification/independent_engineering/review_source_geometry.py
python verification/independent_engineering/review_winding_geometry.py
python verification/independent_engineering/review_hardware_geometry.py
python verification/independent_engineering/verify_datum_parameter.py
```

After the same frozen source has produced its complete exports and web mesh, run:

```sh
python verification/independent_engineering/verify_export_files.py
```

The source, winding and hardware scripts emit measurements for engineering interpretation. A process exit of zero does not itself approve every reported contact or intersection. The final verdict binds the reviewed receipts and records exact scope, explicit overlap exceptions and unresolved holds.

After reviewing the raw findings and confirming that the explicit exceptions still apply, `python verification/independent_engineering/seal_review.py` asserts the scoped M02 criteria and binds the final receipts. Its `--source-only` option seals only hardware/winding measurements while datum/export reconciliation is pending. The sealer is tailored to this reviewed M02 geometry; it does not replace engineering interpretation of a later design revision.

The two `BASELINE_M01_W1_*_REVIEW.json` fixtures are immutable historical measurement inputs used to identify unchanged winding paths and changed component geometry. They are included for reproducibility and do not confer M02 approval. Earlier baseline verdicts and draft failed receipts are superseded by the final M02 verdict for this revision only; v01 itself remains preserved.

`locate_draft_cable_collisions.py` is a diagnostic for the locally archived first draft, not part of the final reproduction sequence. It requires `draft_01_findings/` and may be omitted from a compact source bundle. It reconstructs cable shapes from archived metadata without importing live CAD.

The compact source bundle may omit large STEP/BREP/GLB/mesh exports. Export reconciliation requires those separate deliverables in their recorded paths, or fresh regeneration from the same frozen source. Regeneration should precede the final integrity check; do not substitute baseline exports.
