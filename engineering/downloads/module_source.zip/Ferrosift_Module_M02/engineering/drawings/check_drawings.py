#!/usr/bin/env python3
"""Structural/layout checks after visual review; does not establish engineering validity."""
from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET
import fitz
D=Path(__file__).resolve().parent
svgchecks=[]
for p in sorted(D.glob('FS-M02-*.svg')):
    doc=ET.parse(p);problems=[];texts=0
    for t in doc.findall('.//{http://www.w3.org/2000/svg}text'):
        texts+=1;a=t.attrib;x=float(a['x']);y=float(a['y']);fs=float(a['font-size']);s=''.join(t.itertext())
        length=fitz.get_text_length(s,fontname='hebo' if a.get('font-weight')=='700' else 'helv',fontsize=fs)
        if 'rotate' in a.get('transform',''):continue
        left=x-(length if a.get('text-anchor')=='end' else length/2 if a.get('text-anchor')=='middle' else 0)
        right=left+length
        if left<8 or right>412 or y>286 or y-fs<8:problems.append({'text':s,'bbox_mm':[left,y-fs,right,y]})
    svgchecks.append({'file':p.name,'texts':texts,'outside_page_frame':problems})
pdf=fitz.open(D/'module_drawings.pdf')
pagechecks=[]
for n,p in enumerate(pdf,1):
    spans=[s for b in p.get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans']]
    outside=[{'text':s['text'],'bbox':s['bbox']} for s in spans if s['bbox'][0]<8*72/25.4-.5 or s['bbox'][2]>412*72/25.4+.5 or s['bbox'][3]>289*72/25.4]
    pagechecks.append({'page':n,'A3':abs(p.rect.width-420*72/25.4)<.1 and abs(p.rect.height-297*72/25.4)<.1,'text_spans':len(spans),'outside_frame':outside,'text_characters':len(p.get_text())})
status='PASS' if len(pdf)==6 and not any(s['outside_page_frame'] for s in svgchecks) and all(s['A3'] and not s['outside_frame'] for s in pagechecks) else 'FAIL'
r={'status':status,'page_count':len(pdf),'svg_checks':svgchecks,'pdf_checks':pagechecks,'pdf_sha256':hashlib.sha256((D/'module_drawings.pdf').read_bytes()).hexdigest(),'visual_review':'Recorded separately in drawing_manifest.json after latest page PNG inspection','scope':'Page dimensions and text containment only; neither mechanical nor electromagnetic validation.'}
(D/'drawing_layout_qa.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
raise SystemExit(status!='PASS')
