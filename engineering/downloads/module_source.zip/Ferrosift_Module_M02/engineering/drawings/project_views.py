#!/usr/bin/env python3
"""Exact orthographic visible-edge projections from generated STEP solid geometry.

Run with .venv-cad/bin/python after build_conveyor.py. No substitute mockup geometry.
Each view definition names real CAD categories; HLR is performed by OpenCascade.
"""
from pathlib import Path
import argparse, hashlib, json, math, os
os.environ.setdefault('XDG_CACHE_HOME', '/tmp/ferrosift-cad-cache')
import cadquery as cq
from OCP.gp import gp_Ax2, gp_Pnt, gp_Dir
from OCP.HLRBRep import HLRBRep_Algo, HLRBRep_HLRToShape
from OCP.HLRAlgo import HLRAlgo_Projector
from OCP.BRepLib import BRepLib
from cadquery.occ_impl.exporters.svg import makeSVGedge

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'drawings'/'projections'
VIEWS = {
    'side': ((0,-1,0),(1,0,0)),
    'plan': ((0,0,1),(1,0,0)),
    'end': ((1,0,0),(0,1,0)),
    'iso': ((1,-1,0.85),(1,1,0)),
    'iso_under': ((1,-1,-0.75),(1,1,0)),
}

def project(shape, name, orientation, sources, extra=None):
    normal, xdir = VIEWS[orientation]
    axis = gp_Ax2(gp_Pnt(),gp_Dir(*normal),gp_Dir(*xdir))
    hlr=HLRBRep_Algo(); hlr.Add(shape.wrapped)
    hlr.Projector(HLRAlgo_Projector(axis)); hlr.Update(); hlr.Hide()
    result=HLRBRep_HLRToShape(hlr)
    visible=[]
    for raw in (result.VCompound(),result.Rg1LineVCompound(),result.OutLineVCompound()):
        if not raw.IsNull():
            BRepLib.BuildCurves3d_s(raw,1e-6)
            visible.extend(cq.Shape(raw).Edges())
    paths=[makeSVGedge(e) for e in visible]
    if not visible: raise ValueError(f'No projection edges: {name}')
    bb=cq.Compound.makeCompound(visible).BoundingBox()
    payload={'name':name,'orientation':orientation,'sources':sources,
             'bounds':[bb.xmin,bb.ymin,bb.xmax,bb.ymax], 'paths':paths,
             'normal':normal,'x_direction':xdir,'method':'OpenCascade exact visible-edge HLR of STEP solids',
             'geometry_unit':'mm'}
    if extra:payload.update(extra)
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/f'{name}.json').write_text(json.dumps(payload,separators=(',',':'))+'\n')
    print(name,len(paths),'visible edges',flush=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--config',default=str(ROOT/'drawings'/'view_definitions.json'))
    args=ap.parse_args();config=json.loads(Path(args.config).read_text())
    cache={}
    for view in config:
        path=OUT/f"{view['name']}.json"
        source_paths=[ROOT/item for item in view['sources']]
        digest=hashlib.sha256(b''.join(p.read_bytes() for p in source_paths)+json.dumps(view,sort_keys=True).encode()+Path(__file__).read_bytes()).hexdigest()
        if path.exists() and json.loads(path.read_text()).get('input_sha256')==digest:
            print(view['name'],'cached',flush=True);continue
        shapes=[]
        for p in source_paths:
            if str(p) not in cache:cache[str(p)]=cq.importers.importStep(str(p)).val()
            shape=cache[str(p)]
            offset=view.get('offsets',{}).get(p.stem)
            if offset:shape=shape.translate(tuple(offset))
            shapes.append(shape)
        shape=cq.Compound.makeCompound(shapes)
        extra={'input_sha256':digest}
        if view.get('part_selection'):
            selected=[];ids=[];all_solids=shape.Solids()
            for spec in view['part_selection']:
                target=spec['bbox']['min']+spec['bbox']['max'];matches=[]
                for solid in all_solids:
                    bb=solid.BoundingBox();actual=[bb.xmin,bb.ymin,bb.zmin,bb.xmax,bb.ymax,bb.zmax]
                    if max(abs(a-b) for a,b in zip(actual,target))<1e-4 and abs(solid.Volume()-spec['volume_mm3'])<max(1e-4,spec['volume_mm3']*1e-7):matches.append(solid)
                if len(matches)!=1:raise ValueError(f"Part selection must match one exact solid: {spec['id']} ({len(matches)} matches)")
                selected.extend(matches);ids.append(spec['id'])
            shape=cq.Compound.makeCompound(selected)
            extra['selected_component_ids']=ids
            extra['selection_method']='Exact imported STEP solid bounds and volume matched to frozen assembly manifest records embedded in view definition'
        if view.get('crop'):
            lo,hi=view['crop'];size=[hi[i]-lo[i] for i in range(3)]
            crop=cq.Workplane('XY').box(*size,centered=(False,False,False)).val().translate(tuple(lo))
            # Crop each original solid independently: one compound-wide boolean
            # can suppress touching/interior components such as the sensor tray.
            clipped=[]
            for solid in shape.Solids():
                bb=solid.BoundingBox();a=[bb.xmin,bb.ymin,bb.zmin];b=[bb.xmax,bb.ymax,bb.zmax]
                if any(b[i]<lo[i] or a[i]>hi[i] for i in range(3)):continue
                if all(a[i]>=lo[i] and b[i]<=hi[i] for i in range(3)):clipped.append(solid)
                else:clipped.extend(solid.intersect(crop).Solids())
            shape=cq.Compound.makeCompound(clipped)
            extra['crop_bbox_mm']=view['crop']
        if view.get('section'):
            section=view['section'];axis=section['axis'];value=section['value']
            unit=[int(i==axis) for i in range(3)];origin=[v*value for v in unit]
            plane=cq.Face.makePlane(basePnt=tuple(origin),dir=tuple(unit))
            faces=[];areas=[];contributions=[]
            for solid in shape.Solids():
                cut=solid.intersect(plane)
                for face in cut.Faces():
                    if face.Area()>1e-6:
                        faces.append(face);areas.append(face.Area())
                        bb=face.BoundingBox()
                        contributions.append({'area_mm2':face.Area(),'bbox_mm':{'min':[bb.xmin,bb.ymin,bb.zmin],'max':[bb.xmax,bb.ymax,bb.zmax]}})
            if not faces:raise ValueError(f'No exact solid sections: {view["name"]}')
            shape=cq.Compound.makeCompound(faces)
            normal,xdir=VIEWS[view['orientation']]
            def normalized(v):
                length=math.sqrt(sum(a*a for a in v));return [a/length for a in v]
            nx=normalized(xdir);nn=normalized(normal)
            ny=[nn[1]*nx[2]-nn[2]*nx[1],nn[2]*nx[0]-nn[0]*nx[2],nn[0]*nx[1]-nn[1]*nx[0]]
            triangles=[]
            for face in faces:
                vertices,indices=face.tessellate(.15,.08)
                for ids in indices:
                    triangles.append([[sum(vertices[i].toTuple()[j]*basis[j] for j in range(3)) for basis in (nx,ny)] for i in ids])
            extra.update({'section':section,'section_face_count':len(faces),
              'section_total_area_mm2':sum(areas),'section_contributions':contributions,'fill_triangles':triangles,
              'method':'Exact solid/plane intersection in OpenCascade; visible edge HLR; face tint tessellation tolerance 0.15 mm'})
        project(shape,view['name'],view['orientation'],view['sources'],extra)

if __name__=='__main__':main()
