# Ferrosift: first-stream commercial and feed design basis

Research date: 13 October 2026. Decision-stage research, not an equipment quotation, validated performance specification, refinery offer, or investment forecast.

## Decision

**Start with a retrofit module recovering a PCB-rich concentrate from depolluted, liberated, dry, screened WEEE at an established electronics processor.** Prefer the non-ferrous-bearing stream after ferrous removal and before eddy-current separation (ECS), if the host plant's mass balance confirms recoverable boards remain there. Screen into 12.5–25 mm and 25–50 mm campaigns initially. First physical separation: PCB-rich target versus balance; provide an explicit uncertain/review route or controlled second pass. Do not promise simultaneous commodity-grade copper, aluminium, polymer and precious-metal products from one pass.

This is the best **risk-adjusted first compact-conveyor product hypothesis**, not proof that it will make the most money. No host feed assay, buyer settlement schedule, annual accessible tonnage, installed machine quotation, or customer commitment has yet been obtained. Those missing inputs can reverse the ranking. The existing steel CV/induction prototype is relevant experience, **not a PCB-ready classifier or demonstrated e-scrap product**.

The first customer should already have permitted depollution/shredding/screening, sufficient unsorted material, downstream buyers and a measurable commercial loss. Target a processor selling a PCB-bearing mixed fraction on a discounted basis, or losing boards into a lower-paying output. Avoid making Ferrosift own feedstock, build a shredder plant, finance commodity inventory, or take responsibility for whole-device depollution in its first deployment.

TOMRA documents recovery of PCBs before ECS as a process option that avoids having to retrieve them from two downstream fractions [1]. Umicore's current buyer page confirms assay-based settlement and recommends 25–100 tonne lots for mechanically preprocessed shredded PCB-bearing fractions [2]. Thus an accepted outlet and aggregation route are essential, particularly for a small pilot.

## Ranked alternatives

### 1. Sized, depolluted shredded WEEE: PCB-rich recovery

- **Value capture:** increase the net payable value of all outputs together by moving recoverable board material into an accepted concentrate; possibly reduce downstream burden. The increment is not the gross commodity value of the metals.
- **Supply:** industrial mixed WEEE streams are demonstrated, including the German processor samples in the Vogelgesang dataset [3]. Local accessible supply and composition are unknown. Global e-waste tonnage is not obtainable feed or addressable sorter revenue.
- **Mechanical fit:** small screened fragments fit a modest enclosed belt, controlled feeder, RGB/induction sensing and light-fragment actuation. Two narrow size campaigns reduce flight and sensing variation. Dust, sharp fragments, entanglement, orientation and composite pieces remain important.
- **Software gap:** requires a new representative labeled dataset, ground-truth mass and assay validation. Green appearance alone is insufficient; black/brown boards and plain green plastic are challenge classes.
- **Capital/operating burden:** materially narrower than a full recycling line; upstream liberation, screening, extraction and downstream refining remain host responsibilities. Sorting trials must still measure compressed air, electrical use, wear, cleaning, operator time and rejects.
- **Sellability:** a narrow paid-value recovery trial is understandable. Competitors already exist, so the claim must be affordable integration, serviceability and demonstrated site economics rather than invention of PCB sorting [1,4].
- **Main failure case:** the baseline mixed fraction already receives most metal value, the boards have low payable assay, or losses/fees exceed concentration benefit. Visual purity alone does not rescue the economics.

### 2. Ferrous scrap copper-composite cleanup

- **Value capture:** avoid steel-grade discounts or obtain a buyer-confirmed cleaner-grade premium, plus recover a copper-bearing side fraction. Copper contamination is a genuine metallurgical problem; it cannot simply be removed commercially after entering the steel melt [5].
- **Supply and readiness:** potentially broad flows and closer to Ferrosift's existing steel work. If an existing accessible steel customer has a paid grade problem, this can be the faster first commercial sale.
- **Mechanical mismatch:** heavy, jagged, larger objects require a different belt, impact protection, loading and ejection basis. STEINERT describes 20–400 mm ferrous feed and up to 75 t/h per metre width, composition dependent, for its SteelMaster [6]. Those figures are not comparators for a 12.5–50 mm compact WEEE pilot.
- **Competition:** STEINERT offers physical ballistic/magnetic removal, reducing the scope needing sensors; TOMRA launched an AI copper-meatball application in May 2026 [6–8]. Ferrosift must beat or complement a real incumbent process, not compare only against hand sorting.
- **Limits:** image/induction recognition of exposed composites cannot certify bulk residual copper chemistry or remove alloyed/hidden copper. Premium furnace-feed claims require representative chemical assays and a buyer's actual specification.
- **Ranking condition:** promote to #1 if current steel customer access, validated detections and an enforceable grade premium outweigh the WEEE retraining and feed-access gap. Keep it as a commercial fallback and software validation path; do not silently present the WEEE CAD as fit for heavy steel.

### 3. Whole-device pre-shred triage

- **Value capture:** intact-device reuse and component resale can exceed raw material recovery; the decision depends on functionality, age, condition, repair, data sanitization and sales channel. Pre-shred segregation can also protect downstream operations.
- **Why third for this machine:** heterogeneous geometry/mass, batteries hidden in devices, testing and data handling are a different workflow from fragment sorting. A single visual pass does not prove safe depollution, reusability, functionality or secure erasure.
- **Supply:** whole devices are abundant in collection streams, but usable devices should be assessed before destructive processing. England's regulator explicitly prioritizes segregation for reuse and requires functional/electrical-safety evidence [9]. This is jurisdiction-specific guidance, not a global legal statement.
- **Mechanical/business burden:** controlled stations, gentle handling and possibly human/robotic operations, rather than an air-eject fragment conveyor. The host needs a reuse/ITAD process and authorized downstream treatment. Battery risk is real: EPA documented 245 known or likely lithium-battery fires at 64 waste facilities for 2013–2020, explicitly an incomplete non-random count [10].
- **Ranking condition:** could become a separate high-value product with an ITAD partner and narrow device family, but is not the defensible first use of the present compact fragment-conveyor concept.

## Feed acceptance and pilot operating assumptions

These are proposed qualification limits to test, not published commercial capabilities. Final engineering owns dimensional and actuator limits.

1. **Origin:** processor-controlled, non-reusable WEEE fraction with documented prior depollution and a known treatment route. Written declaration does not replace receipt inspection and the site's safety procedures.
2. **Process position:** after existing hazardous-component removal, liberation and ferrous separation; initially before ECS. Compare this with a downstream mixed-fraction placement on actual samples before final integration. Do not shred valuable reusable devices to create test feed.
3. **Sizing:** 12.5–25 mm and 25–50 mm sieve classes, tested separately before a mixed 12.5–50 mm campaign. The dataset supports research relevance, not an optimal commercial size cut [3]. Sieve aperture does not cap length, thickness or mass: elongated wires can pass a screen. Measure all three dimensions and particle mass distributions; set separate maximums from actuator and transfer trials.
4. **Exclusions:** all batteries/power packs, whole devices, lamps, CRT/display assemblies, pressure vessels/aerosols, toner/ink, oils/free liquid, refrigerants, asbestos/radioactive items, hazardous capacitors and known energetic/pyrotechnic components. Exclude cable tangles, stringy flexible strips and oversized/heavy pieces from the first campaign. This is a conservative pilot exclusion list; appropriate treatment requirements vary by jurisdiction and material.
5. **Moisture:** dry-to-touch, free-flowing with no visible free liquid or sticky agglomerates. Starting test target ≤1% free/surface moisture by wet mass, measured by an agreed safe method; this is an engineering hypothesis, not an industry standard or instrument specification. Do not use an unreviewed heating/drying method on unknown WEEE. Record ambient humidity and requalify if feed causes adhesion, glare or sensing drift.
6. **Fines/dust:** pre-screen undersize and characterize carryover, dust explosibility/toxicity and extraction requirements. A dust port is not a completed dust-control design. Enclosed transfers and extraction must not disturb trajectories or camera stability. Do not call the balance output clean/recyclable plastic without independent characterization.
7. **Pilot rate:** begin with single-particle tests, then approximately 50–200 kg/h as an experimental ramp only. Rate is limited by measured particle count/area, singulation, reject demand and actuator recovery, not just motor power. No industrial tonnes-per-hour claim until representative runs demonstrate it. Commercial feasibility sensitivity below deliberately evaluates larger annual volumes separately; the pilot does not already deliver them.
8. **Presentation:** single layer with validated maximum occupancy/overlap; log belt speed, exposure, light settings, feed rate, reject duty and environmental conditions. Pause feed on tracking failure, blocked outlets or safety fault, according to the validated safety design.
9. **Outputs:** weigh every output, recirculation, oversize, fines, spill and retained material. Keep suspected hazardous contamination under host isolation procedures. A normal review bin is not a validated battery-fire containment system.

RGB+induction can provide object appearance and electromagnetic-response evidence. Neither alone supplies a precious-metal assay, definitive alloy grade, bromine/POP certification or proof that no hidden battery exists. PCB concentrate remains a complex regulated material, not pure metal. England's guidance explicitly notes hazardous chemicals/POPs in boards, cables and plastics [11]; applicability elsewhere requires local review.

## Economic model: money available to customer and to Ferrosift

Use matched representative lots and the host's actual current process as the baseline. Do not compare with landfilling material that the customer already sells.

For each output j, compute net settlement per dry feed tonne:

R_new = sum(y_j × N_j)

where y_j is tonnes of that output per dry feed tonne and N_j is its realized net value per output tonne. N_j can be negative for disposal outputs. It includes payable metal assays and recoveries/payabilities, deductions, treatment/refining/sampling charges, contamination penalties, transport and relevant lot charges, without counting any cost twice.

ΔR = R_new − R_baseline

u = ΔR + genuinely avoidable baseline cost − incremental variable sorting/preparation/handling cost

A = T × u − F

T = qualified t/h × actual processing hours/year × availability × fraction of hours with eligible feed

Here A is annual customer incremental operating cash benefit before financing/tax and initial investment; F is incremental annual fixed cost, including service/software where applicable. Record whether rated hours already include downtime so availability is not counted twice. All-in installed capital K must include the sorter, necessary feeder/screens/transfers, extraction modifications, compressed-air capacity, electrical/safety integration, commissioning and contingencies. Incremental working capital W includes inventory/settlement delays.

Simple payback = (K + W) / A, only if A > 0. For a chosen payback limit P, maximum affordable K + W = P × A. This is a screening calculation, not a discounted investment valuation or guarantee.

### Sensitivity without invented scrap prices or machine quotations

The following u values are deliberately hypothetical **net variable uplift per feed tonne**, not offers, observed margins or commodity prices. Annual feed quantities are commercial scenarios, not demonstrated pilot capacities. Annual benefit below is before F.

| Qualified annual feed | u = $25/t | u = $75/t | u = $150/t |
|---|---:|---:|---:|
| 500 t/year | $12,500 | $37,500 | $75,000 |
| 1,000 t/year | $25,000 | $75,000 | $150,000 |
| 2,000 t/year | $50,000 | $150,000 | $300,000 |

Also test zero/negative uplift; a positive outcome is not assured. At 1,000 t/year and hypothetical u=$75/t, A=$75,000−F and a two-year payback allows K+W ≤ $150,000−2F. This is a purchasing-budget ceiling, not a proposed equipment price. At the 50–200 kg/h pilot rate, 2,000 actual operating hours would yield only 100–400 t/year before other availability/feed limitations, potentially far too little to support an expensive machine. The pilot must either establish scale-up economics or serve a high-u niche.

**Lot aggregation example:** at 1,000 t/year of feed and 5% concentrate mass yield (hypothetical), output is 50 t/year. A 25 t concentrate lot takes roughly six months to accumulate under uniform production. At 1% yield it takes 2.5 years. This can make direct refinery sale impractical even when assays look attractive; use the customer's accepted aggregator outlet and its actual deductions in the model. Umicore's 25–100 t guideline is one buyer's recommendation, not a universal legal minimum [2].

**Ferrosift economics are separate:** hardware gross contribution = selling price minus landed build cost, installation/commissioning, warranty reserve, freight and channel costs. Recurring contribution = fees minus service visits, support, compute, spares and performance liabilities. Do not claim all the customer's recovered metal value as Ferrosift revenue. A capital-light first offer is a scoped evaluation followed by equipment/software sale with paid service; revenue sharing requires auditable baselines and agreement on commodity-price changes, feed shifts and settlement delays.

## Qualification experiment and go/no-go gates

1. Obtain permission to sample several representative lots from more than one production period, including poor feed. Record source mix and upstream configuration. Use a competent sampling plan; do not cherry-pick attractive boards.
2. Establish a matched baseline with the host's normal route, and compare randomized/split or suitably alternating lots. Record all outputs, dust/spills, rework and time. Keep test/train separation by source lot, not only by cropped image.
3. Independently measure PCB mass recovery/purity and metal distribution by agreed sampling/assay. Report mass-based recovery, concentration, residual losses, throughput, confidence intervals and downtime; object-count accuracy alone is insufficient.
4. Obtain written buyer acceptance/specification and indicative settlement basis for both concentrate and balance before purchase commitments. Verify minimum lots, moisture/dry weight basis, paid metals/payabilities, sampling/umpire assay, deductions, prohibited contaminants, shipping and payment timing. Public buyer descriptions prove a route exists, not that a buyer will accept this product.
5. Run enough time to observe feed drift, cleaning and actuator congestion, then extrapolate only with explicitly supported assumptions. Show both optimistic and adverse cases for rate, yield, value, availability and cost.
6. Proceed to production tooling only if lower-confidence incremental benefit clears the customer's agreed economic hurdle after full installed cost and service. Otherwise change location/target split, narrow the stream, or return to the steel opportunity. Safety and downstream acceptance are independent gates even if gross economics appear good.

## What supports a $5 million raise, and what does not

A credible case is a focused paid recovery problem, evidence from representative feed, auditable positive site economics, an accepted outlet, a repeatable deployment envelope and realistic service/manufacturing margins. The amount of a proposed raise does not validate valuation or market demand. A modular CAD model and animated demonstration show intended architecture, not validated performance. Use labels such as “proposed pilot configuration” and “simulation”; separate current steel prototype evidence from future WEEE results.

The 62 Mt global 2022 e-waste context and an estimated embedded copper value, if used elsewhere, must remain sector context. They are not Ferrosift's serviceable feed, customer spend, lost value attributable solely to sorting, or obtainable revenue. A bottom-up market calculation needs verified candidate plants × eligible lines × economically qualifying sites × realistic equipment/service revenue, adjusted for incumbents, sales cycles and capacity to support deployments.

## Evidence register and limitations

Primary sources below were checked on 13 October 2026. Vendor claims are attributed benchmarks, not independently validated Ferrosift capabilities. Older process sources remain useful but their market forecasts and statements about absent technologies must not be represented as current.

1. **TOMRA, 2022 process article:** PCB recovery ahead of ECS; process flexibility. Use for plant placement, not outdated global forecast or guaranteed ROI. https://www.tomra.com/en-ie/waste-metal-recycling/media-center/news/2022/how-sensorbased-sorting-technology-is-driving-advances-in-e-scrap-recycling
2. **Umicore current e-scrap purchasing page:** assay settlement, removal of non-valorized Fe/Al and batteries; recommended minimum 10 t boards, 25–100 t shredded PCB-bearing fractions. No binding commercial price or acceptance obtained. https://www.umicore.com/en/markets-products/recycling-solutions/precious-metals/e-scrap
3. **Vogelgesang dataset / primary article:** industrial-source WEEE, RGB images and particle mass, four broad classes and 12.5–25/25–50 mm bins. Dataset is characterization research, not installed recovery guarantee. Primary repository currently presents Open Access/CC BY 4.0; an aggregator's restricted-access flag conflicts, so verify files/license before reuse. https://tudatalib.ulb.tu-darmstadt.de/items/e05efd14-6421-43ba-a9e4-123c536e712a ; https://doi.org/10.1016/j.dib.2025.112413
4. **TOMRA current e-scrap application:** existing multi-sensor PCB, wire, metal and plastics applications. Its 74 Mt 2030 forecast is old context and should not be reused as current. https://www.tomra.com/en-gb/waste-metal-recycling/applications/metal-recycling/e-scrap
5. **Daehn, Serrenho and Allwood, peer-reviewed steel research:** copper contamination and constraints after melting. Historic wording about available separation technology must be read with the 2026 vendor developments below. https://www.repository.cam.ac.uk/items/93eecec5-af72-4cd4-9440-95f5eab378d5 ; related 2019 analysis https://d-nb.info/1181673534/34
6. **STEINERT SteelMaster engineering/vendor page and 2020 application article:** physical magnetic/ballistic approach; relevant large-particle industrial benchmark. https://steinertglobal.com/us/sorting-systems/magnetic-separation/magnetic-head-pulleys/steinert-steelmaster/ ; https://steinertglobal.com/us/company/news/news-detail/the-perfect-sorting-solution-for-copper-meatballs-out-of-ferrous-products/
7. **TOMRA, 7 May 2026 launch:** AI copper-meatball application exists; do not pitch that category as uncontested. https://www.tomra.com/waste-metal-recycling/media-center/news/2026/tomra-launches-next-generation-ai-platform-and-expands-gainnext-ecosystem
8. **STEINERT WEEE flow:** magnetic, ECS and multi-sensor processes illustrate that a compact sensor belt is one step in a treatment train. https://steinertglobal.com/us/applications/metal-recycling/e-waste-recycling/
9. **Environment Agency, England, WEEE treatment guidance:** reuse-first segregation; process documentation, controlled treatment, representative material balances and characterization. A deployment's applicable jurisdiction and permit must be separately established. https://www.gov.uk/guidance/waste-electrical-and-electronic-equipment-weee-appropriate-measures-for-permitted-facilities/5-waste-treatment-appropriate-measures
10. **US EPA, July 2021 lithium-battery fire study:** documented safety consequences; neither a complete event count nor current incidence estimate. https://nepis.epa.gov/Exe/ZyPURL.cgi?Dockey=P1012TVS.TXT
11. **Environment Agency classification guidance, updated February 2025:** boards/cables/plastics can retain hazardous/POP status; segregation is not chemical certification. https://www.gov.uk/guidance/classify-some-waste-electrical-devices-components-and-wastes-from-their-treatment
12. **Aurubis official purchasing/process description:** electronics procurement through strategic packages and individual deals, representative sampling/analysis underpin valuation. Corroborates that commodity spot price is not equivalent to an e-scrap purchase price. https://www.aurubis.com/produkte/recycling/e-Schrott-und-komplexe-rohstoffe

No supplier contacts, feed purchases, signed agreements, permit determinations or build activity were performed for this research. Public commercial descriptions were reviewed; private recycler contracts and actual host settlement statements were not available. Precise equipment cost, margin, optimal feed and payback remain unverified until the above qualification inputs exist.
