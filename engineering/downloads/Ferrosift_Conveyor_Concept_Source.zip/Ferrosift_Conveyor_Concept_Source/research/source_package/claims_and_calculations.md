# Ferrosift super-conveyor: independent claims and physics audit

Research checked 13 October 2026. This is a concept-review document, not a fabrication release, certified machine design, legal opinion, or evidence of achieved Ferrosift recovery. Calculations below are transparent design examples; measured feed properties and selected hardware must replace assumptions.

## 1. Executive decision

A defensible first experiment is a narrow, depolluted, dry, liberated and screened WEEE fraction, provisionally 12.5–50 mm, after ferrous removal and before conventional eddy-current separation. Test PCB-rich concentrate recovery plus a balance stream, with low-confidence material routed to controlled review. Do not start by promising universal WEEE, elemental precious-metal identification, or safe autonomous handling of batteries.

The research team's provisional 50–200 kg/h pilot range is a test target, not calculated or demonstrated production capacity. Screening aperture is not a maximum object length, thickness or mass specification. Define limits for long wire, sharp fragments, flexible sheets, sticky feed, moisture, dust and residual hazards independently.

All four named competitors already advertise relevant WEEE capabilities. No reviewed public source establishes their loss fraction on the proposed Ferrosift feed, or establishes Ferrosift's physical recovery advantage. Put unknowns visibly on the website rather than inventing a loss waterfall. The proper breakthrough hypothesis is a testable workflow improvement, not merely “AI plus induction,” which is established industry practice.

## 2. Evidence classification and claims ledger template

Every numerical label, animation, dimension and comparative statement needs a claim ID and one of these states:

- **Published vendor claim:** accurately attributed, with application and conditions retained; not independently verified by this review.
- **Published research result:** bounded to the paper's specimens, apparatus and procedure.
- **Ferrosift demonstrated:** requires original test record, date, hardware/model version, denominator, conditions and uncertainty. None of the physical sorting figures in this document qualify.
- **Design assumption:** selected to size or illustrate a concept, explicitly adjustable.
- **Calculated scenario:** equations and input assumptions exposed; not a measurement.
- **Hypothesis / validation needed:** intended improvement with an experiment specified.

Per-claim record fields:

Claim ID; proposed wording; claim category; source URL/title/date/access date; exact source result; whether result is independently verified; feed/material/size/conditioning; machine configuration; metric and denominator; sample size and uncertainty; design assumptions; equation and units; calculation result; limitations; required validation; evidence owner; publishable wording; last review date.

### Initial ledger

| ID | Proposed statement | Evidence status | Required condition / limitation | Publishable treatment |
|---|---|---|---|---|
| C01 | Ferrosift recovers 94% while competitors recover 86% | Unsupported physical comparison | Prior internal YOLO metric lacks demonstrated mass recovery, hardware separation or matched competitor trial | Do not publish this comparison; describe original ML metric only after identifying exact metric, split, class and uncertainty |
| C02 | First feed is 12.5–50 mm depolluted WEEE | Design scope | Incoming screening, liberation and hazard verification required; aperture does not limit every dimension | Proposed pilot feed envelope |
| C03 | 50–200 kg/h | Pilot test target | Actual object mass distribution, ejection load and feed spacing unknown | Planned test range, subject to commissioning |
| C04 | RGB + induction improves difficult PCB decisions | Hypothesis with established industrial precedent | Test independent holdout lots; induction is not elemental assay | Proposed fusion experiment |
| C05 | Confidence-aware review reduces harmful errors | Hypothesis | Report rejected/reviewed proportion, review labour and lost availability | Measure the purity/recovery/abstention trade-off |
| C06 | Encoder-linked tracking delivers accurate ejection | Engineering concept | Belt slip, object motion, timing tails and actuator dynamics must be measured | Proposed closed-loop timing architecture |
| C07 | Multi-view recovery detects hidden surfaces | Hypothesis | A new view must actually expose the surface; induced tumbling can create tracking errors/dust | Optional second-view experiment |
| C08 | Programmable Lorentz module is novel and superior | Not established | Relevant variable-frequency ECS research already exists; no patent/novelty review performed | Optional research bay, not baseline performance |
| C09 | Machine is industrially safe / compliant | Not established | Site-specific machinery, electrical, dust/fire and functional-safety review required | Concept includes space for guarding and hazard controls |
| C10 | More sorted PCB mass means recovered gold | Invalid inference | PCB grade, assay, treatment yield, payability, penalties and baseline disposition matter | PCB-rich output pending assay and downstream acceptance |

An image-level accuracy, mAP or recall improvement cannot directly establish tonnes recovered, copper recovery, PCB class coverage, revenue, or plant ROI. An 8 percentage-point difference is not automatically an 8% relative gain; neither interpretation is permitted until the original metric is known.

## 3. Current competitors: fair comparisons

### TOMRA

TOMRA's September 2025 FINDER COLOR announcement describes RGB with AI object-level sorting, an optional electromagnetic sensor, and applications including PCB purification. Published size range is 6–120 mm. Its “up to 20 t/h” number is explicitly for Zorba, not the proposed PCB-rich WEEE feed. Its existing E-Scrap page describes spectral/electromagnetic PCB sorting, and NIR/XRT routes for polymer-related tasks. These establish relevant capabilities, not matched-condition recovery results. [FINDER COLOR](https://www.tomra.com/en-gb/waste-metal-recycling/media-center/news/2025/tomra-recycling-unveils-finder-color), [E-Scrap](https://www.tomra.com/en-gb/waste-metal-recycling/applications/metal-recycling/e-scrap).

A separate TOMRA demonstration identifies its feed as a 20–80 mm e-scrap fraction processed by FINDER with NIR. That is useful evidence of an application, not a quantified purity/recovery benchmark. [PCB demonstration](https://video.tomra.com/e-scrap-pcb-recovery-from-e-scrap).

### STEINERT

STEINERT markets a portfolio spanning magnetic, induction, colour, 3D, NIR and XRT sorting for e-waste. Its KSS CLI combines colour, laser-derived 3D and induction and lists creation of circuit-board concentrates as an application. The application page also distinguishes fine-particle equipment and black-plastic technologies. Do not portray STEINERT as using a single blind sensor or lacking PCB classification. No matched-feed numerical loss comparison was established. [E-waste applications](https://steinertglobal.com/us/applications/metal-recycling/e-waste-recycling/), [sensor-sorting brochure](https://steinertglobal.com/fileadmin/user_upload/Steinert/Downloads/Sensor_sorting/STR_Produktbroschuere_DE_EN_webversion.pdf).

### SICON / SESOTEC

SICON's VariSort literature describes modular sensor combinations and circuit-board detection applications using camera, camera plus induction and XRT. Its broader process brochure includes configurable belt widths and optional multiple outputs. It contains an inconsistent imperial/SI speed conversion: “160 feet per second (4 m/s).” Do not reproduce the imperial number; seek vendor confirmation before a specification comparison. [VariSort sensor matrix](https://sicontechnology.com/wp-content/uploads/SICON-VariSort-E.pdf), [process brochure](https://sicontechnology.com/wp-content/uploads/Brochure-Non-Ferrous-and-ASR-Recovery-24-1.pdf).

PolyFloat is density-based plastics refining, not a direct Ferrosift PCB-conveyor benchmark. SICON advertises 99.4% product purity and throughput up to 12 t/h for that process. Do not transfer its plastics purity into a PCB recovery comparison. [PolyFloat](https://sicontechnology.com/en/polyfloat/).

### Recycleye

Its current QuantiSort 2.0 page explicitly lists WEEE/metals, including boards, cables and batteries. Published maxima include 1,000 ejections/minute, belt speed 4.5 m/s and maximum width 2,800 mm; they do not prove simultaneous performance or accuracy on this feed. The WEEE brochure advertises detection down to 5 mm and reports illustrative/customer results including recovery of 75% of aluminium previously lost in reject and purity change from 94% to 97%. The available description lacks a fully reproducible matched-feed comparison, so retain attribution and avoid extrapolation. Its apparent “gold” class must not be interpreted as assayed gold content. [QuantiSort](https://recycleye.com/optical-sorter/), [WEEE brochure](https://recycleye.com/wp-content/uploads/2024/10/AI-powered-sorting-for-Metal-WEEE.pdf).

### What the comparison should show at each stage

| Stage | Fair baseline question | Ferrosift hypothesis | Evidence needed before numeric X versus Y |
|---|---|---|---|
| Feed preparation | How many valuables leave in fines, dust, ferrous and oversize? | Controlled feed improves observable/separable fraction | Weigh and assay every output on paired representative lots |
| Presentation | What overlap, shadow, rolling and entanglement occur at real loading? | Metering and spacing improve detection and actuation | Occupancy and overlap distribution; downstream pick success |
| Sensing | Which object classes are confused under surface damage/coatings? | Fusion or additional view reduces specific confusions | Same objects, sensor ablation, fresh lots and size strata |
| Decision | Where does forcing a class cause contamination? | Calibrated abstention improves selected operating point | Precision–recall–abstention curves and review burden |
| Actuation | Which correctly classified objects physically miss their bin? | Encoder timing and feedback improve hit probability | Synchronized event log, high-speed video and weighed bins |
| Downstream sale | Which products meet actual buyer specifications? | Better partition yields better net settlement | Independent assay, buyer terms and all-output net value |

Website copy can say “Loss channel to measure” and “Proposed intervention.” Avoid animated percentages that look like observed results. A clearly labelled simulator may use illustrative inputs but should default to unknown baseline and unknown Ferrosift recovery, not fabricated values.

## 4. Auditable concept calculations

### 4.1 Area-loading envelope, not an industrial capacity rating

Let W be usable belt width in metres, v speed in m/s, phi observed fractional projected-area occupancy, and Abar mean projected object area in square metres. In an ideal monolayer, with no overlaps and a stationary size distribution:

Ndot ≈ phi × W × v / Abar, in objects/s.

This is an approximate count-flow relation. Overlaps, variable size and shape, clustering, unusable edges and particles slipping relative to the belt invalidate a simple interpretation. Phi must be measured at the sensor, not inferred from hopper fill.

Illustration: W = 0.50 m effective on a nominally wider belt; v = 0.40 m/s; phi = 0.10; Abar = 0.0009 m² (30 × 30 mm equivalent). Ndot ≈ 22.2 objects/s. That does not mean an actuator can sort 22.2 objects/s.

Mass flow Q in kg/h = 3,600 × Ndot × mbar, where mbar is measured mean object mass in kg for the same counted population. For the identical illustration, mbar of 2 g, 5 g and 20 g gives respectively 160, 400 and 1,600 kg/h. This tenfold span proves why belt dimensions alone cannot substantiate a tonne/hour claim. These three masses are hypothetical, not feed measurements.

Conversely, at a hypothetical mean 10 g/object, a 50–200 kg/h test asks for 1.39–5.56 objects/s. With the same 900 mm² area and 0.20 m²/s swept area, corresponding ideal occupancy is about 0.625–2.50%. That is a sparse-flow commissioning scenario, not guaranteed packing behaviour.

### 4.2 Spacing and actuator loading

For a deliberately constrained lane, object length ell and end-to-end gap g give pitch p = ell + g and per-lane count ceiling Nlane = v/p. With ell = 50 mm, g = 50 mm and v = 0.4 m/s, Nlane = 4/s. Six hypothetical 80-mm lanes across 500 mm effective width give 24/s before feeder or ejection limits. Physical lanes may introduce jams and are not assumed necessary for the final machine.

Only an ejected fraction f loads the selected-output actuator: E = f × Ndot. At 22.2 objects/s and f = 0.20, demand is 4.44 ejections/s, about 267/minute. Simultaneous adjacent objects, nozzle reuse, valve duty cycle, pressure recovery and pulse overlap may constrain operation even when the global average is acceptable. An uncertain-object review stream adds its own ejection demand.

For a 50-mm object at 0.4 m/s, nominal passage time past a point is 125 ms. Air pulse length is not automatically 125 ms: pressure, jet footprint, acceleration, nozzle angle, mass/area and flight geometry require tests. A mechanical diverter likewise needs measured cycle, settling and object-clearance times. Never substitute model FPS for physical sorting rate.

### 4.3 Sensing-to-actuation distance

Let Tdecision be worst-case bounded time from a usable exposure to an available decision, Tio communication/control delay, Tact actuator effective delay and Tmargin engineering reserve. Minimum straight-line travel distance before action is approximately:

dmin = vmax × (Tdecision + Tio + Tact + Tmargin).

Illustrative budget: capture/readout 20 ms, inference/association 80 ms, tracking/control 10 ms, communication 10 ms, actuator delay 15 ms, reserve 25 ms. Total 160 ms; at 0.4 m/s, dmin = 64 mm. These timings are assumed, not benchmarks. If the concept places a sensing reference 500 mm upstream of an action reference, nominal time available is 1.25 s. That provides geometric margin only; it does not certify the timing or trajectory.

Use encoder position scheduling, not a fixed sleep based on nominal speed. The geometric relation must include the actual observation point, belt end, free-flight intersection and valve location. Decision lateness should trigger a defined safe sort/review outcome rather than a late uncontrolled pulse. Record high-percentile latency and deadline misses under worst-case load, not just mean inference time.

### 4.4 Encoder and trajectory errors

For a 200-mm effective measuring diameter and 4,096 counts per revolution, nominal scale is pi × 200 / 4096 ≈ 0.1534 mm/count. This is encoder quantization, not object-position accuracy. Wheel slip, roller diameter tolerance, belt stretch, timestamp alignment and object rolling often dominate.

Illustrative separate error bounds: calibration 1 mm; image localization 2 mm; object/belt slip 3 mm; airborne/nozzle interaction 4 mm; timing uncertainty 5 ms × 0.4 m/s = 2 mm. Worst-case additive bound is 12 mm. Root-sum-square is approximately 5.83 mm only if independent, zero-mean statistical assumptions are justified. Neither number is measured. A 12.5-mm fragment cannot be promised selective ejection from a similarly spaced neighbour on this error budget. This is a reason to test spacing and short-object performance, not conceal uncertainty with a fine encoder specification.

### 4.5 Pixels, fields of view and motion

For horizontal field of view F = 400 mm and Nx = 2,048 sensor pixels, nominal sampling is 0.1953 mm/pixel. A face-on 12.5-mm feature spans 64 sensor pixels. If the whole width is resized to 640 model pixels, it spans only 20 model pixels; a 5-mm feature spans eight. Tiling may retain detail but changes compute and latency. Optical blur, occlusion, perspective, focus, belt height, dirt and model architecture all reduce usable detail. Pixel count is not proof of class recognition or composition.

Motion blur in pixels b = v × texposure / s, with s in metres/pixel. At 0.4 m/s and 0.1953 mm/pixel, holding blur to 0.5 pixel calls for exposure no longer than approximately 0.244 ms. This is a sampling calculation, not a camera requirement validated against a classifier; lighting and shutter choice need testing.

At 30 frames/s and 0.4 m/s, the belt advances 13.3 mm/frame. A 300-mm along-belt field of view has nominal residence time 0.75 s, about 22.5 frames. Tracking must deduplicate observations; multiplying frame detections is not object flow. For line-scan imaging, line rate must exceed v/sy for desired along-belt sampling: at 0.4 m/s and 0.2 mm/line, at least 2,000 lines/s before margins and acquisition constraints.

### 4.6 Recovery and economics equations

For class or commodity i:

Mass recovery Ri = correctly routed target mass / target mass in input.

Product purity Pi = target mass in selected product / total selected product mass.

Yield Yi = selected product mass / total feed mass.

Count recall and image mAP are different quantities. A copper-bearing composite may count as a successful PCB pick while its copper content remains unmeasured.

Incremental net plant value per input tonne = sum over all outputs of (output mass fraction × actual net settlement per tonne) minus the same all-output baseline, minus incremental energy, air, labour, maintenance, disposal, logistics and other operating costs. Annual cash benefit further depends on uptime and actual annual feed; capital cost and financing determine payback. A baseline that already sells PCB-bearing mixed scrap must retain that revenue. Do not double count copper and gold value already included in a buyer's PCB settlement.

## 5. Sensor and experimental architecture review

RGB + controlled illumination + encoder is the minimum useful optical sorting experiment. Adding inductive response is a plausible orthogonal measurement of conductive behaviour; it does not uniquely identify copper, gold, PCB grade or chemical composition. Sensor-to-object association is a first-class risk when the induction footprint is coarser than the image footprint or objects overlap.

If NIR is proposed, distinguish polymer/surface signatures from hidden composition. If XRT is proposed, distinguish effective attenuation/shape/thickness information from unambiguous elemental identification. If XRF/LIBS is proposed, treat it as a separately engineered and validated spectroscopy module with safety and exposure controls; do not decorate a render with these labels and imply an integrated capability. 3D may assist shape, height correction and tracking but does not itself assay value.

An optical second view should be an optional later branch. Demonstrate that a transfer or controlled reorientation exposes new useful information without making matching and actuation worse. Do not depend on deliberate tumbling for battery-containing or hazardous feed.

Recommend keeping any programmable electromagnetic actuation outside the core pilot until ordinary sensor, tracker and actuator performance is understood. Otherwise too many novel failure modes prevent attributing improvements.

## 6. Optional programmable electromagnetic module

Variable-frequency electromagnetic separation has prior research. A 2017 KONA paper demonstrates nonferrous separation with a variable-frequency electromagnet and notes a magnetic-gap throughput bottleneck of approximately 50–100 kg/h in that research apparatus. It specifically cautions that real scrap variability in size, geometry and composition broadens trajectories. This is prior art and a research result, not Ferrosift performance or a universal scaling law. [Original paper](https://www.jstage.jst.go.jp/article/kona/34/0/34_2017012/_html/-char/en).

Describe a future module as a frequency/field/trajectory characterization experiment. Required measurements include specimen geometry/mass/conductivity class, gap, field, drive waveform, heating, power, duty cycle, repeatability and capture-zone separation. “Programmable” does not create material specificity automatically. No novelty, patent clearance, energy superiority or industrial throughput conclusion is supported here.

## 7. Safety and CAD review gates

Show safety provisions as concept placeholders, not compliance stamps:

- Guard access to drive, pulley, nip, return-belt and discharge pinch zones; contain sharp or ejected pieces.
- Reserve accessible emergency-stop locations and a restart/reset concept. An emergency stop is not an energy-isolation procedure.
- Provide a lockable electrical isolation concept, pneumatic isolation and stored-pressure release, plus access for cleaning and maintenance without reaching through moving machinery.
- Include upstream verified depollution and a hazardous-feed rejection/quarantine workflow. A battery classifier is supplementary monitoring; it is not proof that feed is battery-free.
- Reserve extraction/cleaning interfaces for a competent dust assessment; consider metal/polymer dust, contamination, ignition, visibility and housekeeping. Do not assume a generic vacuum or enclosure solves the hazard.
- Show service clearance, access to valves/sensors, clean optical windows and restrained collection bins. Set clearance and guard dimensions through the applicable risk assessment, not aesthetic CAD proportions.
- Mark X-ray/laser/strong-field modules as absent from the baseline or requiring separate engineered controls.

US OSHA's general machine-guarding rule addresses hazards including nip points, rotating parts and flying material; its hazardous-energy rule covers unexpected start-up and stored energy during servicing. These are useful review references, not a determination of which rules apply at a future site. [Guarding](https://www.osha.gov/laws-regs/regulations/standardnumber/1910/1910.212), [energy isolation](https://www.osha.gov/laws-regs/regulations/standardnumber/1910/1910.147).

EPA documents lithium-battery fire incidents across waste-management facilities, including electronics recyclers. That supports an explicit incoming-feed and fire-risk review rather than treating battery sorting as an optional economic feature. [EPA report overview](https://www.epa.gov/recycle/importance-sending-consumers-used-lithium-ion-batteries-electronic-recyclers-or-hazardous).

## 8. Validation sequence and release gate

1. Characterize representative incoming lots: mass, size, shape, projected area, moisture, occlusion, hazards, class labels and independent composition/assay where needed.
2. Establish the actual plant baseline and all output destinations. Use randomized paired splits where feasible, or a controlled crossover accounting for feed changes. Do not pick an intentionally weak baseline and label it a named competitor.
3. Run RGB-only, induction-only where meaningful, and fused decisions on the same held-out objects. Hold out supplier/day/lot to expose domain shift. Freeze training before evaluation.
4. Separate recognition, association, decision, command, physical ejection and final-bin outcomes in the event log. Measure every loss stage rather than blaming the model for every miss.
5. Test sparse flow first, then increase occupancy and adverse cases within the safe envelope. Include different sizes, surface damage, coatings, rotation, neighbours and unknowns. Record reject rate, jams, downtime, energy/air use and maintenance burden.
6. Weigh input and every output; reconcile mass balance including fines/dust and handling losses. Inspect and assay representative product samples. Report count-based and mass-based metrics separately, with uncertainty and stratification.
7. Use actual buyer settlement and baseline displacement to calculate economics. Include costs of review/rework and any lower-value residual stream.
8. Only after these steps should the website replace unknown X/Y fields with empirical outcomes. A vendor comparison requires the same feed, chosen operating point, sizing, configuration, throughput and relevant support conditions, with attribution and uncertainty.

Concept drawing release: suitable for discussion only. Fabrication release remains blocked until mechanical/electrical specifications, guarded layout, control architecture, actuation tests and competent safety review are complete.

## 9. Reconciliation with revised 600-mm CAD concept

Architecture coordination update: nominal belt width 600 mm, deck x=0–3000 mm, belt top z=1000 mm; RGB centre x=1300 mm; induction centre x=1600 mm; last sensing datum x=1750 mm; belt lip x=3000 mm. Thus tracking distance to the lip is 1250 mm. These are packaging-study dimensions, not selected hardware or validated design. Use 500 mm effective width only as the example edge-margin assumption; confirm actual sensor and nozzle coverage.

The earlier 0.4 m/s examples illustrate sparse-flow commissioning and are not a conflicting rated specification. Revised study speed is 1.0 m/s, with 0.5–2.0 m/s exploration. Begin slow and sparse; treat 2.0 m/s as an unvalidated stress case.

| Quantity, all illustrative | 0.5 m/s | 1.0 m/s | 2.0 m/s |
|---|---:|---:|---:|
| Time from x1750 to lip x3000 | 2.50 s | 1.25 s | 0.625 s |
| Travel during assumed 160-ms timing budget | 80 mm | 160 mm | 320 mm |
| Advance at 30 frames/s | 16.7 mm | 33.3 mm | 66.7 mm |
| Position error from 5-ms timing uncertainty | 2.5 mm | 5 mm | 10 mm |
| Maximum exposure for 0.5 pixel blur at 400-mm FOV/2048 px | 0.195 ms | 0.0977 ms | 0.0488 ms |
| Count flow at W=0.5m, phi=10%, Abar=900mm² | 27.8/s | 55.6/s | 111.1/s |
| Ejections/minute if 20% of that flow is targeted | 333 | 667 | 1,333 |

The high-occupancy rows do not represent the 50–200 kg/h trial plan and must not be conflated with it. They expose the growing actuator and computing burden. At 1 m/s, retaining the earlier non-timing illustrative error terms gives a worst-case sum of 15 mm; at 2 m/s it gives 20 mm. Do not show selective 12.5-mm airjet targeting without corresponding measured errors and spacing.

### Review gate: an important architecture limitation

The revised concept uses a terminal airjet to split PCB-rich target from balance, followed by a swing gate on the balance chute that diverts uncertain time windows or groups to review. This can yield three collection bins, but is not evidence of three-way per-object sorting.

- A balance-only review gate cannot recover a misrouted uncertain object already blown into the PCB chute. Its default-to-review state protects only the balance path, not the whole machine.
- Uncertain objects should not trigger the primary target ejector; disable target ejection on an invalid tracking/control state and handle feed stoppage through the validated control design. Residual air or misfires still need containment and measurement.
- Gate timing must include the distribution of chute transit times, bounce, collisions, gate opening/closing and residual objects. Belt timestamps no longer establish reliable individual object arrival after uncontrolled chute motion.
- Preferred commissioning strategy: inhibit upstream feed, wait for a verified clearing gap or divert an intentionally broad group/window, position and verify the gate, then resume under a defined sequence. This costs capacity and may send valuable material to review; include it in yield, downtime and economics.
- Actuation, end-position feedback, air-pressure loss, power loss and blocked-chute scenarios require a competent machine-control and safety review. “Fail-to-review” is a routing intent, not a functional-safety certification.

### Induction evidence caution

Williams and colleagues' 2023 MIS paper concerns wrought versus cast shredded aluminium, not PCB recovery. The laboratory result did not transfer directly to their industrial conveyor; identified problems included partial detections by adjacent sensors, orientation/surface-facing dependence and model selection. Its industrial trials operated at 2 m/s, which establishes a studied setting, not Ferrosift feasibility. [Original paper](https://pure.manchester.ac.uk/ws/portalfiles/portal/277754037/sensors-23-07837.pdf).

### Commercial memo cross-check

The independent commercial memo's two size campaigns, all-output settlement model and explicit scale-up gap are consistent with this audit. Its 50–200 kg/h experiment cannot support 1,000–2,000 annual tonnes without a separate throughput/operating-hours argument. Its $25/$75/$150 per feed tonne sensitivity values must remain labelled hypothetical net variable uplift, not market quotes or expected margins. A chosen ≤1% surface-moisture condition is a proposed test assumption; establish a safe measurement protocol and empirical need before presenting it as a feed acceptance standard. No identified commercial ranking is proven without host access, representative assay and buyer terms.
