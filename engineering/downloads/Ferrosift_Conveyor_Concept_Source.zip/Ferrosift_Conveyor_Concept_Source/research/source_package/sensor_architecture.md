# Ferrosift: evidence-led sensor/process concept basis

Research date: 2026-10-13. Design-study assumptions, not a fabrication release, machinery safety assessment, promised performance or freedom-to-operate opinion.

## Decision

First pilot task: enrich printed circuit board (PCB) fragments from depolluted, dry, liberated, screened 12.5–50 mm WEEE, after upstream ferrous removal and before eddy-current separation (ECS). Feed choice coordinated with the feed/economics workstream. This document does not establish profitable settlement, a minimum detectable PCB size, or readiness to accept waste. A PCB-rich concentrate is not pure copper, precious-metal assay, polymer identification, or proof of brominated-flame-retardant compliance.

Build the CAD around material presentation, controlled RGB, a removable under-belt induction cassette, encoder-referenced object fusion, a tested ejection window, and conservative review handling. Provide a bolt-in 3D position; install it only if it earns its cost through overlap detection, height compensation or improved object assignment. Keep expensive spectroscopy as downstream alternatives rather than placing every sensor on one belt.

Commercial precedent already exists: STEINERT ISS has an under-belt sensor, and KSS CLI combines color, 3D and induction for circuit-board concentrates. Differentiation must be measured integration performance, cost, maintainability or a specific feed niche. No basis was found to claim that multisensor sorting is new or that a commercial competitor loses a fixed percentage more material.

## Evidence register

[S1] STEINERT ISS official product page: https://steinertglobal.com/sorting-systems/sensor-sorting/induction-sorting-system/ . Under-belt induction, acceleration belt and compressed-air ejection are explicitly described. Published machine family range is 1–200 mm, 600–3000 mm working width; Fines variant 1–20 mm. These ranges are NOT this project's performance or a PCB minimum. Manufacturer detection sensitivity is not equivalent to material-classification accuracy.

[S2] STEINERT KSS CLI official page: https://steinertglobal.com/sorting-systems/sensor-sorting/combined-sensor-sorting-systems/steinert-kssr-cli/ . Color, 3D and metal response are combined; PCB concentrates are an established application. Secondary optical characteristics support allocation; purity may require a subsequent cleanup pass.

[S3] Williams et al., Sensors 2023, 23, 7837, DOI 10.3390/s23187837. Full paper: https://pure.manchester.ac.uk/ws/portalfiles/portal/277754037/sensors-23-07837.pdf . This is University of Manchester/Magnapower wrought-versus-cast ALUMINIUM Twitch research, not commercial WEEE performance. §3.2, printed p6: 600 mm-wide, 2 m-long, 1.3 mm-thick belt at 2 m/s; eight active sensors cover approximately 150 mm with guided feed. Fig9/§4.2, pp12–13: static recovery/purity 89.66%/94.96% versus industrial-test 63.89%/60%, for approximately balanced 47%/53% wrought/cast by count. §4.3 pp14–16 identifies adjacent-coil partial hits, orientation/lift-off and generalization issues. The paper tests 3, 6, 9, 15, 30 and 60 kHz (§3.1 p5); this is evidence for a frequency sweep experiment, not selected Ferrosift operating frequencies. These results motivate joint object assignment and realistic validation; they predict neither PCB yield nor competitor losses.

[S4] Environment Agency WEEE treatment guidance: https://www.gov.uk/guidance/waste-electrical-and-electronic-equipment-weee-appropriate-measures-for-permitted-facilities/5-waste-treatment-appropriate-measures . Jurisdiction-specific authoritative example: depollution is a defined upstream process, batteries/powerpacks generally remain whole for removal, hazardous components and dust/emissions need controlled treatment, and output monitoring matters. Applicability depends on location and permits; it is not a universal legal specification.

[S5] STEINERT XRF/3D official page: https://steinertglobal.com/sorting-systems/sensor-sorting/x-ray-sorting-systems/steinert-kss-xf-l/ . Elemental composition separates copper/brass/zinc; supplier explicitly calls it surface evaluation, although some metallic coatings can be accommodated. Published application range 10–120 mm, widths 1000/2000 mm. This does not prove bulk composition of PCB composites.

[S6] TOMRA X-TRACT official page: https://www.tomra.com/en-gb/waste-metal-recycling/products/machines/new-x-tract . Dual-energy XRT measures attenuation-related material differences for metal sorting; its role is bulk/internal contrast, not direct universal elemental assay. Official aluminum application page https://www.tomra.com/en-gb/waste-metal-recycling/applications/metal-recycling/aluminum describes staged XRT, LIBS and AI sorting and up-to-3.8 m/s equipment. No speed or yield transfers to this pilot.

[S7] TOMRA AUTOSORT PULSE official page: https://www.tomra.com/en-ie/waste-metal-recycling/products/machines/autosort-pulse . Dynamic LIBS addresses alloy/grade and surface-treatment challenges with laser scanning; claimed commercial envelope includes 10–150 mm and 1.2 m belt. This is a separate mature industrial machine, not a justification to add a laser to the PCB pilot.

[S8] TOMRA AUTOSORT BLACK official page: https://www.tomra.com/pt-br/waste-metal-recycling/products/machines/autosort-black . The manufacturer uses MIR for carbon-black-filled plastics and specifies 25–120 mm. This is an important counterexample to assuming ordinary NIR classifies all WEEE plastic.

[S9] de Jong et al., Automatic sorting of scrap metals with a combined electromagnetic and dual energy X-ray transmission sensor, International Journal of Mineral Processing 82 (2007), 222–232: https://www.sciencedirect.com/science/article/pii/S0301751606002432 . Primary experiment combining electromagnetic conductivity response and dual-energy XRT; non-ferrous post-shredder metals, not PCB grade assay. It supports complementary information and documents surface color errors from contamination, plating and paint.

## Process boundary and order

1. External prerequisite: documented receipt, depollution, liberation and ferrous separation. Do not depict whole devices, batteries, CRTs, mercury lamps or sealed unknown assemblies entering this sorter. An inline camera cannot repair an upstream battery-removal failure [S4].
2. Sized-feed interface: separate fines and oversize; use 12.5–50 mm only as proposed sieve band, not maximum bounding-box length. Measure actual length/width/thickness and long-wire carryover; screens can pass long thin objects. Fines, wires and oversize need defined routes.
3. Metering/spreading: small hopper and variable vibratory feeder, isolation mounts, adjustable spreader, removable inspection panels. Mechanism: reduce clustering and supply a near-monolayer; feeder speed controlled by observed belt occupancy. The broad mechanical precedent is [S1,S3]. Unknown: attainable coverage without tangling or overlap.
4. Acceleration/stabilization belt: stabilize fragment pose before measurement. Mechanism: reduces sensor-to-ejector slip/rotation. Proposed stabilization distance is a test variable, not a known required length [S1,S3].
5. Controlled-light RGB; optional 3D: segment objects, record exposed board texture/color, estimate footprint and overlap/height flags. Dark hood and repeatable illumination limit changing ambient conditions; do not infer hidden copper from green color. An oblique second camera is optional only if it measurably resolves side features/occlusion. No added camera sees a fully covered underside [S2,S9].
6. Under-belt induction: sample complex amplitude/phase over selected frequencies; record signal footprint, SNR, saturation and calibration state. Mechanism: conductive content/response helps distinguish look-alikes and link PCB-like objects to metal-bearing features [S1–S3]. It does not uniquely measure composition or locate all hidden copper.
7. Encoder-based shared object tracking and fusion: transform every sensor observation into belt coordinates and a common object ID. Assign neighboring induction responses jointly to the RGB footprint; weak edge responses must not independently command an ejector. Tag touching/overlapping pieces as a group. This is a proposed response to [S3], not a demonstrated gain.
8. Decision/ejection: high-confidence PCB candidate → air-ejected concentrate; other known material → balance. Unknown, sensor failure, ambiguous group or tracking loss → conservative review routing. All decisions and delivered fractions must be audited.
9. Sample/QA interface: weigh input and all outputs; collect time-correlated samples, misses and false positives. Validate PCB mass recovery, concentrate grade and buyer assay separately.

## CAD v0 parameter pack: all dimensions below are chosen assumptions

Coordinate convention: x increases with belt travel; y spans belt width; z is height above floor. Units mm. Freeze only for visual/design-study layout; retain parameters in the model.

- Active belt width 600. Belt travel deck x=0..3000, belt top z=1000. Frame outside width approximately 850, subject to real rollers/guards. Initial calculated speed 1.0 m/s; study range 0.5–2.0 m/s. No rated tonnes/hour.
- Feeder/spreader reserved volume x=-1400..0, y=-450..450, z=1000..1700. Upstream screen/magnet/depollution shown as process interfaces, not miniaturized decorative hardware.
- Stabilization x=0..1100. No sensor benefits are assigned to a second belt by default.
- RGB field center x=1300. Combined optional 3D/optical hood x=1050..1950, width900, height850 above deck. Use adjustable camera/lighting crossrails, lift-out cleanable windows and service hinges. Final lens FOV, working distance and depth range remain unselected.
- Induction cassette nominal center x=1600, reserved envelope 600W×350L×200H below the belt. Last sensing reference x=1750. Removable from side with repeatable locating features; allow extra lateral space for connectors and withdrawal.
- Nonconductive sensor-window zone reserved x=1350..1850: no steel deck plate, metal belt splice or reinforcing cords through active field. Actual belt conductivity, thickness, wear support and static-control compatibility require vendor/material tests. Do not specify a structural polymer plate thickness before deflection/wear design.
- Coil-to-underside clearance provisionally adjustable through a 1–15 mm study travel, clearly labeled UNVALIDATED CLEARANCE, not claimed detection range. Total object lift-off = belt thickness + mechanical gap + support-layer thickness + local air gap caused by object shape. Required collision margin/flatness may invalidate the smallest settings. Keep mounting datum independent of a bouncing feeder.
- Last sensor-to-lip distance 1250. Reserve final tracker/verification-camera mounting x=2550..2750, initially unpopulated unless movement requires it.
- Air bar at discharge lip x≈3000; enclosed trajectory/splitter volume x=3000..4200, z=300..1250, width≈1000. This is clearance reservation only; jet angle, pressure, nozzle pitch, pulse width and splitter geometry need measured impulse/trajectory tests.
- Three bins: concentrate on deflected path; balance on natural trajectory; review receives a conservative timed interval from a swing gate on the BALANCE chute. Bins may be placed side by side downstream with chutes, but bend/slope/jam risk must be engineered. No claim that one ordinary air bar does precise three-way sorting.
- Reserve 900 mm each side for service plus cabinet-door/coil-withdrawal/bin-exchange sweeps. These are layout allowances, not verified accessibility or machine-safety distances. Guarded pinch points and a real safety-engineering design are required.
- Electrical/control cabinet outside induction exclusion area, with separated drive-power, valve-power and low-noise sensor/data routes. Dust extraction ports at feeding and discharge are placeholders for a qualified dust/fire design, not an arbitrary suction sizing.

### Review routing logic and actuation alternatives

For v0, the balance chute gate defaults to review on loss of power/valid tracking where mechanically achievable. Unknowns reserve a widened time window; known neighbors sharing that window also enter review and are counted as a review burden. If a candidate overlaps an unknown or a jet footprint would hit it, suppress the candidate ejection and send the whole group to review. This trades recovery/throughput for conservative classification; test actual gate delay, bounce and transit dispersion. An unknown in the ejected path cannot be recovered by the balance gate, so fusion must suppress conflicting ejections upstream. Fault handling should stop metering and account for material already between sensors and discharge; do not promise a gate alone creates a safe machine.

Air jets have industrial precedent [S1,S3], suit small liberated pieces, and allow width-wise selection. Unknowns: mass/area ratio, board flutter, heavy components, pressure droop, adjacent hits, air consumption. At low experimental throughput, individually spaced pieces and a three-position diverter can establish classification truth without a high-rate jet claim. Robots, lanes or multiple sequential ejectors add handling and synchronization; justify only after measured actuator failure modes. A genuine independent item-level third stream should use a validated second separation stage, not cosmetic three-bin artwork.

## Physics and interfaces to preserve

- Metal support within the field contributes its own signal; moving steel rollers/splices and motor drives may create drift or interference. Place drive motor and ferrous rollers away from active region, test with belt running empty, and map frame sensitivity. No universal exclusion radius is claimed.
- Do not place a conductive shield across the sensing aperture. Shield electronics/cabling and characterize any side/back screens; shields themselves alter the field. Frequency/time scheduling and channel calibration need a measured crosstalk matrix. More coils do not automatically mean independent spatial pixels.
- Ferromagnetic steel has permeability response as well as eddy-current conductivity effects; a Cu/Al-only model does not generalize to steel-copper composites. Upstream magnet removal is a feed prerequisite, not proof that the remaining stream is steel-free. Reject anomalous/saturated responses and include residual steel in validation.
- For a simple uniform conductor, skin depth δ = sqrt(1/(π f μ σ)). Increasing frequency changes penetration and response; complex geometry, permeability, layers and lift-off make inverse composition non-unique. A surface trace, buried winding and steel-backed copper cannot be presumed equivalent.
- Cameras/3D/induction report timestamp, encoder position, calibration version, quality flags and spatial footprint. Decisions report object/group ID, class probability or score, reason for abstention, and intended actuator event. Controller records actual encoder/valve/gate acknowledgement and compressed-air pressure.
- Encoder distance, not a fixed wall-clock delay alone, should schedule belt travel: required travel Δx maps to encoder increments. Separately compensate sensing/compute/output/valve delays and flight time. Emergency deceleration changes trajectories and must invalidate pending sorts safely.

## Calculation framework (illustrative assumptions, not performance)

Travel budget t = L/v. With L=1.25 m and v=1 m/s, t=1.25 s; at 2 m/s it is 0.625 s. Available computation budget subtracts acquisition, communications, output response, required lead and safety margin. This is not a measured latency.

Timing error becomes longitudinal error e≈vΔt. At 2 m/s a 5 ms error produces 10 mm displacement, nearly the short dimension of a minimum nominal sieve fraction. Include sensor registration, belt slip, object movement and airflow scatter in the error budget; add independent random errors statistically only when justified, otherwise use worst-case bounds.

A 12.5 mm object at 2 m/s passes a mathematical scan line in 6.25 ms. For 1 mm along-track sampling, line rate must be at least v/Δx = 2000 lines/s at that speed. For at most 0.5 mm motion blur, exposure ≤0.25 ms. These are geometry calculations and do not choose a camera or establish resolution on reflective/dirty boards.

Mass rate Q = 3600 W v c (m̄/Ā) kg/h, where W is belt width in m, c is non-overlapping projected coverage fraction, and m̄/Ā is representative mass per projected area in kg/m². Equivalent object rate ṅ = W v c/Ā. Use actual measured mixture statistics; no bulk-density × belt-section shortcut for sparse irregular monolayers. Closely packed projected coverage still says nothing about ejection-neighbor clearance.

For horizontal ballistic discharge with negligible drag, t_f=sqrt(2h/g), x=v t_f. Board drag/rotation and jet impulse make this only an initial envelope. Measure trajectories by size/mass/shape and pressure; do not dimension splitters from this equation alone. Jet impulse J≈mΔv is a requirement, not proof a selected nozzle meets it.

## Optional module decisions

- 3D: first optional addition, useful for height/footprint, overlap rejection and camera/coil assignment [S2,S3]. Added capital, calibration and laser-safety work; retained only if blind test improves net saleable value or reduces review burden.
- Second RGB view: mount allowance only. Benefit must come from newly visible surfaces, not redundant same-side pixels. A transfer/tumble for opposite face may damage fragments and loses tracking; requires a separate re-identification stage and controlled trial [S3 orientation mechanism].
- XRT: reserve a separate enclosed downstream skid if internal high/low attenuation is decisive for a chosen metal/composite split [S6,S9]. Adds radiation source, detector, shielding/interlock/regulatory work and thickness/overlap ambiguity. Not a default PCB detector or universal hidden-Cu scanner. No radiation enclosure design in this concept.
- XRF: possible downstream metals upgrading or specifically validated bromine screening, not bulk PCB precious-metal assay [S5]. Surface sensitivity, coatings, small target area and dwell affect results. Requires compliant shielded equipment and qualified radiation review. Bromine detection does not identify every regulated BFR molecule or certify compliance.
- LIBS: possible alloy-specific separated metal product once a buyer pays for alloy grade [S7]. Ablates a local spot, needs aim/focus/cleaning strategy and certified laser/dust/fire enclosure. Not first-line broad PCB sorting and not bulk composition of heterogeneous fragments.
- NIR: possible downstream polymer stream with validated spectral library; cannot be assumed to classify carbon-black WEEE plastic, multilayers or BFR content. MIR is a commercially documented alternative for carbon-black-filled polymers [S8]; its cost and particle range need separate justification.
- Battery detection/thermal monitoring: useful as additional risk controls only through qualified facility design, never authorization to skip depollution [S4]. No inline miracle claim.

## Improvement claim to test, rather than assert

Hypothesis: a low-cost, modular PCB recovery sorter can gain useful recovery/purity or lower review burden by (a) joint camera/induction object assignment, (b) tracking-quality-based abstention and (c) measured feeder/actuator feedback, compared with the SAME hardware using independent thresholds. Commercial multisensor novelty is not claimed.

Paired blind experiments, same representative lots and throughput: RGB only; induction only; naïve fusion; spatially assigned fusion; fusion plus 3D; optional reinspection. Include both faces, dirt, metal-backed boards, cables, residual steel, low-metal board pieces, touching/overlapping pieces, belt wear, speed/coverage variation, and missed-jet cases. Split training/test by source lot and physical object, not two views of the same fragment. Separate classifier performance from actuator success. Report uncertainty and all review material.

Primary acceptance metrics: mass-based PCB recovery, mass-based PCB-rich concentrate purity, payable assay/settlement uplift, balanced material account, review kg/t, miss destinations, kWh/t, compressed-air use/t, uptime/cleaning and throughput at declared quality. A model can increase apparent purity by rejecting almost everything; therefore report recovery, abstention and net value together. Require a buyer's accepted concentrate specification before setting commercial targets. Stop adding modules when incremental net value after capex/opex/review costs is not demonstrated.

## Independent-review amendments before CAD freeze

Physics reviewer confirms: the balance-chute gate cannot capture unknown material accidentally entering the concentrate chute and is NOT a global fail-safe. Treat its mechanical default as local routing behavior only. Require upstream feed inhibit and a verified empty gap for gate state changes during initial trials; if continuous timed windows are later attempted, measure the full chute transit/dwell distribution and widen review windows accordingly. Tumbling/collisions after discharge break precise object-time associations. Quality fail-safe architecture may instead need a common downstream batch quarantine arrangement affecting BOTH products. Mechanical safety remains a separate qualified assessment.

Initial commissioning should start with sparse flow at 0.5 m/s; 1 m/s is the design-study nominal and 2 m/s a stress-test target, not demonstrated operation. The feed/economics workstream recommends independently testing 12.5–25 and 25–50 mm bands, dry-to-touch/no free liquid, with a 50–200 kg/h experimental ramp. Those rates are chosen trials, not mechanical capacity. Any optional ≤1% surface/free-moisture target is experimental, not a published supplier limit. Bound maximum object length, thickness and mass separately and reject long cable tangles.
