"""Editable solid geometry for a concept pneumatic split and group-review gate.

All dimensions are study selections. This does not compute pneumatic impulse,
safe guard openings, chute flow, actuator timing or containment requirements.
"""
import math
import cadquery as cq

STEEL = '#8b9da4'
BLUE = '#43677a'
ORANGE = '#e49c48'


def box(x, y, z, dx, dy, dz):
    return cq.Workplane('XY').box(dx, dy, dz).translate((x, y, z)).val()


def panel(points, thickness=3, normal=(0, 0, 1)):
    wire = cq.Wire.makePolygon([cq.Vector(*v) for v in points], close=True)
    return cq.Solid.extrudeLinear(wire, [], cq.Vector(*normal).normalized().multiply(thickness))


def cylinder(radius, length, origin, axis):
    return cq.Solid.makeCylinder(radius, length, cq.Vector(*origin), cq.Vector(*axis))


def trough(add, ident, start, end, width, wall=100, color=STEEL):
    dx, dy = end[0]-start[0], end[1]-start[1]
    length = math.hypot(dx, dy)
    nx, ny = -dy/length*width/2, dx/length*width/2
    a = (start[0]+nx, start[1]+ny, start[2])
    b = (start[0]-nx, start[1]-ny, start[2])
    c = (end[0]-nx, end[1]-ny, end[2])
    d = (end[0]+nx, end[1]+ny, end[2])
    add(ident+'_floor', ident.replace('_',' ')+' floor', 'chute', panel([a,b,c,d]), color,
        notes='Provisional slope; friction, bounce, bridging and trajectories require tests.')
    for side, pts in [('L',[a,d,(d[0],d[1],d[2]+wall),(a[0],a[1],a[2]+wall)]),
                      ('R',[b,c,(c[0],c[1],c[2]+wall),(b[0],b[1],b[2]+wall)])]:
        add(ident+'_side_'+side, ident+' side cheek '+side, 'chute', panel(pts,3,(nx,ny,0)), color)


def build(add, p):
    lip = p['geometry_mm']['belt']['discharge_lip_x']
    deck = p['geometry_mm']['belt']['top_z']
    ox, oz = lip-3000, deck-1000
    def shift_shape(shape):
        return shape.translate((ox,0,oz))
    upstream_add = add
    def add(ident, name, category, shape, color=STEEL, **meta):
        meta.setdefault('status','unvalidated_concept_selection')
        if 'animation' in meta:
            pivot=meta['animation'].get('pivot')
            if pivot:
                meta['animation']['pivot']=[pivot[0]+ox,pivot[1],pivot[2]+oz]
        upstream_add(ident,name,category,shift_shape(shape),color,**meta)

    # Hollow manifold and individual nozzle envelopes. Pitch is a drawing
    # selection only and must not be used as a claimed separation resolution.
    outer=cylinder(24,640,(3090,-320,910),(0,1,0))
    inner=cylinder(19,642,(3090,-321,910),(0,1,0))
    add('air_manifold','Pneumatic manifold, hollow envelope','airjet',outer.cut(inner),BLUE,
        notes='No pressure or valve response specified. 50 mm nozzle spacing is a geometric placeholder.')
    for n,y in enumerate(range(-275,276,50)):
        axis=cq.Vector(.28,0,.96).normalized()
        nozzle=cylinder(7,45,(3090,y,930),axis.toTuple()).cut(cylinder(3.5,46,(3090,y,929.5),axis.toTuple()))
        add(f'nozzle_{n:02d}',f'Nozzle envelope {n+1}','airjet',nozzle,ORANGE)
    for y in (-340,340):
        add(f'air_bracket_{y}','Adjustable airbar mounting plate','airjet',box(3130,y,875,100,8,130),STEEL)
    add('valve_pack','Valve bank envelope','airjet',box(3300,640,780,290,130,130),BLUE,
        notes='Envelope only; no selected manufacturer or internal geometry.')
    add('air_isolation','Pneumatic isolation / dump valve envelope','airjet',box(3480,640,780,70,75,100),ORANGE,
        notes='Requires selected valve and validated isolation / stored-energy procedure.')
    add('pressure_sensor','Pressure transducer envelope','airjet',cylinder(15,55,(3340,640,845),(0,0,1)),BLUE)
    pipe_outer=cylinder(12,320,(3090,320,915),(0,1,0)).fuse(cylinder(12,210,(3090,640,915),(1,0,0)),cylinder(12,70,(3300,640,845),(0,0,1)))
    pipe_inner=cylinder(9,322,(3090,319,915),(0,1,0)).fuse(cylinder(9,212,(3089,640,915),(1,0,0)),cylinder(9,72,(3300,640,844),(0,0,1)))
    add('air_supply_route','Protected pneumatic supply route envelope','airjet',pipe_outer.cut(pipe_inner),BLUE,
        notes='Routing envelope only; connectors, bends, pressure rating and flow sizing unselected.')

    # Natural-path catch precedes the group gate. Concentrate passes above
    # this region into the farther central chute after a tested jet impulse.
    trough(add,'balance_catch',(3140,0,780),(3350,0,675),580,100)
    trough(add,'concentrate_chute',(3610,0,820),(4000,0,490),290,105,ORANGE)
    trough(add,'balance_branch',(3660,135,615),(4000,340,490),235,90,BLUE)
    trough(add,'review_branch',(3660,-135,615),(4000,-340,490),235,90,'#aa8259')
    # Gate in its drawn centre position. This is a transition configuration,
    # not permitted sorting operation; endpoints/clear gap require validation.
    floor=box(3480,0,640,280,580,3).cut(cylinder(15,6,(3400,0,637),(0,0,1)))
    add('review_gate_floor','Group routing chamber floor','gate',floor,STEEL,
        notes='Transfer gaps and flow across chamber require physical tests; no guaranteed self-clearing flow.')
    add('review_gate_plate','Group routing vertical swing blade','gate',box(3480,0,740,160,4,180),ORANGE,
        animation={'type':'review-gate','axis':'z','pivot':[3400,0,740],'angle':0.45,'balanceAngle':-0.45},
        notes='Illustrated transition position. Group/window routing only; inhibit feed, clear, position and verify before resuming.')
    add('review_gate_shaft','Vertical gate shaft','gate',cylinder(12,280,(3400,0,615),(0,0,1)),STEEL)
    for zz in (622,856):
        bearing=box(3400,0,zz,65,55,20).cut(cylinder(12.25,22,(3400,0,zz-11),(0,0,1)))
        add(f'gate_bearing_{zz}','Gate shaft bearing envelope','gate',bearing,BLUE)
    add('gate_actuator','Rotary actuator envelope','gate',box(3400,0,915,90,95,40),BLUE,
        notes='No selected actuator, torque, default spring or cycle time established.')
    for y in (-80,80):
        add(f'gate_feedback_{y}','Gate end-position switch envelope','gate',box(3420,y,848,40,25,30),'#dcbb55')

    # Open-top removable bins. Colour denotes intended routing, not contents.
    for ident,cy,color in [('review',-340,'#aa8259'),('concentrate',0,ORANGE),('balance',340,BLUE)]:
        outer=box(4000,cy,280,380,300,400)
        inner=box(4000,cy,284,372,292,400)
        shell=outer.cut(inner)
        add('bin_'+ident,ident.title()+' collection bin','bin',shell,color,
            notes='Ordinary collection bin; not hazardous-material or battery-fire containment.')
        for sx in (-145,145):
            for sy in (-110,110):
                add(f'bin_{ident}_foot_{sx}_{sy}',ident+' bin foot','bin',box(4000+sx,cy+sy,40,35,35,80),STEEL)
        for sx in (-1,1):
            add(f'bin_{ident}_handle_{sx}',ident+' bin pull handle','bin',box(4000+sx*193,cy,405,10,90,12),STEEL)

    # Ejection enclosure frame with removable roof and side access screens.
    for x in (3170,4180):
        for y in (-525,525):
            add(f'discharge_post_{x}_{y}','Ejection enclosure upright','guard',box(x,y,606,35,35,1188),BLUE)
            add(f'discharge_foot_{x}_{y}','Ejection enclosure foot','guard',box(x,y,6,100,80,12),STEEL)
    for y in (-525,525):
        add(f'discharge_toprail_{y}','Ejection enclosure top rail','guard',box(3675,y,1190,1045,35,35),BLUE)
        side=box(3675,y,920,975,3,450)
        # Two large inspectable apertures retain borders; no claim that their
        # openings are safe. In practice guards require risk assessment.
        for x in (3415,3910):
            side=side.cut(box(x,y,920,410,9,355))
        add(f'discharge_access_frame_{y}','Removable discharge access frame','guard',side,STEEL,
            notes='Window insert and fastening detail require containment/risk review.')
        for x in (3415,3910):
            add(f'discharge_window_{x}_{y}','Discharge observation window envelope','guard',box(x,y,920,410,2,355),'#577885',
                opacity=.18,removable=True)
    add('discharge_roof','Removable discharge cover','guard',box(3675,0,1220,1075,1080,3),BLUE,
        removable=True,default_hidden=True)
    port=cylinder(55,100,(4040,0,1220),(0,0,1)).cut(cylinder(51,102,(4040,0,1219),(0,0,1)))
    add('discharge_dust_port','Unspecified extraction interface','guard',port,STEEL,
        notes='Interface reservation only; airflow, dust/fire design and trajectory interference unvalidated.')


ROUTES={
 'target':[[3000,0,1014],[3190,0,1060],[3440,0,1020],[3650,0,875],[3900,0,610],[4000,0,510],[4040,0,470],[4040,0,280]],
 'balance':[[3000,0,1014],[3100,0,950],[3220,0,820],[3370,0,725],[3460,100,735],[3660,180,715],[3900,340,565],[4000,340,510],[4040,340,470],[4040,340,280]],
 'review':[[3000,0,1014],[3100,0,950],[3220,0,820],[3370,0,725],[3460,-100,735],[3660,-180,715],[3900,-340,565],[4000,-340,510],[4040,-340,470],[4040,-340,280]],
}
