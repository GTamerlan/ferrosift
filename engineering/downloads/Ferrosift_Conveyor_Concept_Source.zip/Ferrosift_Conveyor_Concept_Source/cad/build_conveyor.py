"""Rebuild editable CadQuery solids, STEP assembly, BREP, GLB and web mesh.

Usage: .venv-cad/bin/python cad/build_conveyor.py
No Fusion, GPU, cloud CAD, private model or paid service is used.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import struct
import sys
from collections import defaultdict
from pathlib import Path
import cadquery as cq
import numpy as np
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(HERE))


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def as_shape(value):
    if isinstance(value,cq.Workplane):
        shapes=[v for v in value.vals() if isinstance(v,cq.Shape)]
        return shapes[0] if len(shapes)==1 else cq.Compound.makeCompound(shapes)
    return value


def build(parameters):
    from mechanical_base import build as mechanical
    from sensor_feed import build as sensing
    from discharge import build as discharge
    parts=[]
    names=set()
    def add(ident,name,category,shape,color='#8b9da4',**meta):
        if ident in names:
            raise ValueError('Duplicate part id: '+ident)
        names.add(ident)
        shape=as_shape(shape)
        if not isinstance(shape,cq.Shape):
            raise TypeError((ident,type(shape)))
        if not shape.isValid() or not shape.Solids():
            raise ValueError('Invalid or non-solid part: '+ident)
        if shape.Volume()<=0:
            raise ValueError('Zero-volume part: '+ident)
        if isinstance(meta.get('animation'),dict):
            a=meta['animation']
            if 'pivot_mm' in a:a['pivot']=a.pop('pivot_mm')
            if 'radius_mm' in a:a['radius']=a.pop('radius_mm')
            if isinstance(a.get('axis'),list):
                a['axis']='xyz'[max(range(3),key=lambda i:abs(a['axis'][i]))]
        category={'rollers':'roller','bearings':'bearing','guards':'guard','cables':'cable'}.get(category,category)
        if meta.get('default_visible') is False or meta.get('cutaway_hidden'):
            meta['default_hidden']=True
        parts.append(dict(id=ident,name=name,category=category,shape=shape,color=color,**meta))
    mechanical(add,parameters)
    sensing(add,parameters)
    discharge(add,parameters)
    return parts


def rgb(c):
    if isinstance(c,str):return [int(c.lstrip('#')[i:i+2],16)/255 for i in (0,2,4)]
    return list(c[:3])


def bbox(shape):
    b=Bnd_Box()
    BRepBndLib.AddOptimal_s(shape.wrapped,b,False,False)
    x0,y0,z0,x1,y1,z1=b.Get()
    return {'min':[x0,y0,z0],'max':[x1,y1,z1]}


def tessellate(part):
    vertices,indices=part['shape'].tessellate(0.6,0.16)
    v=np.array([p.toTuple() for p in vertices],dtype=np.float64)
    t=np.array(indices,dtype=np.int64)
    # Expand triangles for stable flat normals across hard mechanical edges.
    xyz=v[t].reshape((-1,3))
    normals=np.cross(xyz[1::3]-xyz[::3],xyz[2::3]-xyz[::3])
    norms=np.linalg.norm(normals,axis=1)
    good=norms>1e-10
    xyz=xyz.reshape((-1,3,3))[good].reshape((-1,3))
    normals=normals[good]/norms[good,None]
    nn=np.repeat(normals,3,axis=0)
    base={k:v for k,v in part.items() if k!='shape'}
    return dict(base,vertices=np.round(xyz,5).ravel().tolist(),normals=np.round(nn,6).ravel().tolist(),
                indices=list(range(len(xyz))),bbox=bbox(part['shape']))


def write_glb(objects,path):
    """Standard GLB2, named assembly nodes, mm->m and Z-up->Y-up explicitly."""
    scene={'asset':{'version':'2.0','generator':'Ferrosift CadQuery2.8 BRep tessellation'},'scene':0,
      'scenes':[{'nodes':[]}],'nodes':[],'meshes':[],'materials':[],'buffers':[{'byteLength':0}],
      'bufferViews':[],'accessors':[]}
    data=bytearray()
    def accessor(array,component,kind,target,limits=False):
        while len(data)%4:data.append(0)
        start=len(data);data.extend(array.tobytes())
        bv=len(scene['bufferViews']);scene['bufferViews'].append({'buffer':0,'byteOffset':start,'byteLength':array.nbytes,'target':target})
        a={'bufferView':bv,'componentType':component,'count':len(array),'type':kind}
        if limits:a.update(min=array.min(axis=0).astype(float).tolist(),max=array.max(axis=0).astype(float).tolist())
        i=len(scene['accessors']);scene['accessors'].append(a);return i
    for ob in objects:
        v=np.array(ob['vertices'],dtype=np.float32).reshape((-1,3))
        n=np.array(ob['normals'],dtype=np.float32).reshape((-1,3))
        v=np.column_stack((v[:,0],v[:,2],-v[:,1])).astype('<f4')*.001
        n=np.column_stack((n[:,0],n[:,2],-n[:,1])).astype('<f4')
        ind=np.array(ob['indices'],dtype='<u4')
        pa=accessor(v,5126,'VEC3',34962,True);na=accessor(n,5126,'VEC3',34962)
        ia=accessor(ind,5125,'SCALAR',34963)
        mat=len(scene['materials']);alpha=ob.get('opacity',1)
        material={'name':ob['id']+'_finish','pbrMetallicRoughness':{'baseColorFactor':rgb(ob['color'])+[alpha],'metallicFactor':.2,'roughnessFactor':.65},'doubleSided':True}
        if alpha<1:material['alphaMode']='BLEND'
        scene['materials'].append(material)
        mi=len(scene['meshes']);scene['meshes'].append({'name':ob['id'],'primitives':[{'attributes':{'POSITION':pa,'NORMAL':na},'indices':ia,'material':mat}]})
        animation=ob.get('animation')
        if animation:
            animation=dict(animation)
            if 'pivot' in animation:
                x,y,z=animation['pivot'];animation['pivot']=[x*.001,z*.001,-y*.001]
            if 'radius' in animation:animation['radius']*=.001
            axis=animation.get('axis')
            if axis in ('x','y','z'):
                animation['axis']={'x':'x','y':'z','z':'y'}[axis]
                if axis=='y':
                    if 'angle' in animation:animation['angle']*=-1
                    animation['direction']=-(animation.get('direction',1))
            if isinstance(animation.get('direction'),list):
                x,y,z=animation['direction'];animation['direction']=[x,z,-y]
            animation['coordinate_system']='glTF metres, Y up'
        ni=len(scene['nodes']);scene['nodes'].append({'name':ob['id'],'mesh':mi,'extras':{'label':ob['name'],'category':ob['category'],'default_hidden':ob.get('default_hidden',False),'animation':animation, 'status':'concept_geometry'}})
        scene['scenes'][0]['nodes'].append(ni)
    scene['buffers'][0]['byteLength']=len(data)
    payload=json.dumps(scene,separators=(',',':')).encode()
    payload+=b' '*((-len(payload))%4);data+=b'\0'*((-len(data))%4)
    result=struct.pack('<4sII',b'glTF',2,12+8+len(payload)+8+len(data))+struct.pack('<I4s',len(payload),b'JSON')+payload+struct.pack('<I4s',len(data),b'BIN\0')+data
    path.write_bytes(result)


def export(parts,p):
    from discharge import ROUTES
    out=ROOT/'exports';out.mkdir(exist_ok=True)
    catdir=out/'categories';catdir.mkdir(exist_ok=True)
    web=ROOT/'web';web.mkdir(exist_ok=True)
    qa=ROOT/'verification';qa.mkdir(exist_ok=True)
    assembly=cq.Assembly(name='Ferrosift_PCB_Concept_v0')
    categories=defaultdict(list)
    for part in parts:
        assembly.add(part['shape'],name=part['id'],color=cq.Color(*rgb(part['color'])))
        categories[part['category']].append(part['shape'])
    path=out/'conveyor_assembly.step'
    print(f'Exporting {len(parts)} named components to STEP',flush=True)
    assembly.export(str(path),exportType='STEP',unit='MM',outputUnit='MM')
    compound=cq.Compound.makeCompound([part['shape'] for part in parts])
    compound.exportBrep(str(out/'conveyor_assembly.brep'))
    for cat,shapes in categories.items():
        cq.exporters.export(cq.Compound.makeCompound(shapes),str(catdir/f'{cat}.step'))
    subsetdir=out/'drawing_subsets';subsetdir.mkdir(exist_ok=True)
    sensorparts=[part['shape'] for part in parts if part['category'] in ('camera','light','sensor','window') or (part['category']=='hood' and not part.get('default_hidden') and not any(t in part['id'].lower() for t in ('panel','roof','window','door','cover')))]
    cq.exporters.export(cq.Compound.makeCompound(sensorparts),str(subsetdir/'sensor_cell.step'))
    print('Tessellating verified BRep solids',flush=True)
    objects=[tessellate(part) for part in parts]
    manifest={'schema_version':1,'units':'mm','coordinate_system':'x-longitudinal,y-transverse,z-up',
        'concept_status':'Discussion geometry; not fabrication, operation, safety or performance approval.',
        'parameters_sha256':digest(ROOT/'design_basis'/'parameters.json'),
        'step_sha256':digest(path),'assembly_bbox':bbox(compound),'part_count':len(parts),
        'parts':[{**{k:v for k,v in part.items() if k!='shape'},'bbox':bbox(part['shape']),
                  'volume_mm3':part['shape'].Volume(),'solid_count':len(part['shape'].Solids())} for part in parts],
        'categories':{cat:{'part_count':sum(1 for part in parts if part['category']==cat),'step_file':f'categories/{cat}.step','sha256':digest(catdir/f'{cat}.step')} for cat in categories}}
    (out/'assembly_manifest.json').write_text(json.dumps(manifest,indent=2))
    sourcehashes={f.name:digest(f) for f in HERE.glob('*.py')}
    g=p['geometry_mm'];ox=g['belt']['discharge_lip_x']-3000;oz=g['belt']['top_z']-1000
    routes={k:[[x+ox,y,z+oz] for x,y,z in path] for k,path in ROUTES.items()}
    zones=[]
    for si,(a,b) in enumerate(zip([-1450,0,1050,2000,3100], [0,1050,2000,3100,4250])):
        active=[r for r in manifest['parts'] if r['bbox']['max'][0]>a and r['bbox']['min'][0]<b]
        if not active:continue
        for side in (-1,1):
            edge=min(r['bbox']['min'][1] for r in active) if side<0 else max(r['bbox']['max'][1] for r in active)
            far=edge+side*g['service']['side_clearance']
            zones.append({'id':f'service_{si}_{side}','points':[[a,edge,0],[b,edge,0],[b,far,0],[a,far,0]],'label':'900 mm reserved beyond closed equipment; door/bin sweeps need validation'})
    packet={'schemaVersion':1,'units':'mm','coordinateSystem':'x-longitudinal,y-transverse,z-up',
      'provenance':{'kind':'cad-tessellation','description':'Generated from executed CadQuery/OpenCascade solid assembly. Concept geometry only; not tested machine performance.','cadquery':cq.__version__,'stepSha256':digest(path),'sourceSha256':sourcehashes},
      'objects':objects,'routes':routes,'serviceZones':zones,'routeStatus':'Illustrative group routing only; paths are not measured trajectories.',
      'footprints':{'camera':{'centre':[g['sensing']['rgb_center_x'],0,g['belt']['top_z']+1],'width':p['width_assumptions_mm']['camera_field_of_view_example'],'length':300,'status':'Provisional example; not validated coverage.'},'beltWidth':g['belt']['active_width'],'usableSensingWidth':None,'lastSensingDatumX':g['sensing']['last_sensing_datum_x'],'cassetteHousingEdgeX':g['induction_cassette']['center_x']+g['induction_cassette']['length']/2}}
    meshpath=web/'conveyor-assembly.json';meshpath.write_text(json.dumps(packet,separators=(',',':')))
    write_glb(objects,out/'conveyor_assembly.glb')
    print('Reimporting complete STEP for native geometry checks',flush=True)
    reopened=cq.importers.importStep(str(path)).val()
    original_volume=sum(part['shape'].Volume() for part in parts)
    receipt={'status':'passed','cadquery':cq.__version__,'all_components_valid':all(part['shape'].isValid() for part in parts),
       'component_count':len(parts),'source_solid_count':len(compound.Solids()),'step_solid_count':len(reopened.Solids()),
       'step_valid':reopened.isValid(),'source_volume_mm3':original_volume,'step_volume_mm3':reopened.Volume(),
       'relative_volume_error':abs(reopened.Volume()-original_volume)/original_volume,
       'source_bbox_mm':bbox(compound),'step_bbox_mm':bbox(reopened),'triangle_count':sum(len(o['indices'])//3 for o in objects),
       'files':{f.name:{'bytes':f.stat().st_size,'sha256':digest(f)} for f in [path,out/'conveyor_assembly.brep',out/'conveyor_assembly.glb',meshpath]},
       'source_sha256':sourcehashes,'limitations':['Solid validity and round-trip checks do not establish strength, sensor performance, chute flow, safe guarding or machine compliance.','Some bolts/locators/assembly mating faces intentionally touch or overlap. See targeted interference report.']}
    receipt['bbox_method']='OpenCascade AddOptimal, triangulation disabled, no shape tolerance expansion'
    receipt['bbox_max_difference_mm']=max(abs(a-b) for side in ('min','max') for a,b in zip(receipt['source_bbox_mm'][side],receipt['step_bbox_mm'][side]))
    if not receipt['step_valid'] or receipt['source_solid_count']!=receipt['step_solid_count'] or receipt['relative_volume_error']>1e-6 or receipt['bbox_max_difference_mm']>.001:
        receipt['status']='failed'
    (qa/'cad_export_validation.json').write_text(json.dumps(receipt,indent=2))
    print(json.dumps({k:receipt[k] for k in ('status','component_count','source_solid_count','step_solid_count','relative_volume_error','triangle_count')}),flush=True)
    if receipt['status']!='passed':raise RuntimeError('STEP round-trip failed')
    return receipt


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--validate-only',action='store_true');parser.add_argument('--belt-width',type=float)
    args=parser.parse_args()
    params=json.loads((ROOT/'design_basis'/'parameters.json').read_text())
    if args.belt_width:params['geometry_mm']['belt']['active_width']=args.belt_width
    parts=build(params)
    if args.validate_only:
        print(json.dumps({'components':len(parts),'all_valid':True,'belt_width_input':params['geometry_mm']['belt']['active_width'],'parts':[{'id':x['id'],'bbox':bbox(x['shape'])} for x in parts if x['category']=='belt']}))
    else:
        if args.belt_width:raise ValueError('Variant may only be used with --validate-only; preserve the frozen release geometry')
        export(parts,params)
