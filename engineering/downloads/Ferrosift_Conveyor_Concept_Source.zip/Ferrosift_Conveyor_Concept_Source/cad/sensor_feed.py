"""Parametric feeder, hood and sensor-envelope solids for Ferrosift concept v0.

All dimensions are millimetres. This is an executed design-study model, not a
fabrication release. Sensor devices are envelopes, without invented internals.
The assembly caller supplies add(id, name, category, shape, color=..., **meta).
"""
from __future__ import annotations

import cadquery as cq


def box(dx, dy, dz, x, y, z):
    return cq.Workplane("XY").box(dx, dy, dz).translate((x, y, z))


def cyl(radius, length, x, y, z, axis="z"):
    shape = cq.Workplane("XY").circle(radius).extrude(length)
    if axis == "x":
        shape = shape.rotate((0, 0, 0), (0, 1, 0), 90)
    elif axis == "y":
        shape = shape.rotate((0, 0, 0), (1, 0, 0), -90)
    return shape.translate((x, y, z))


def xz_plate(points, width, y=0):
    return cq.Workplane("XZ").polyline(points).close().extrude(width / 2, both=True).translate((0, y, 0))


def rhs_z(size, wall, height, x, y, z):
    return box(size, size, height, x, y, z).cut(box(size - 2 * wall, size - 2 * wall, height + 2, x, y, z))


def build(add, p):
    """Add independent valid solid components, retaining named service parts."""
    g = p.get("geometry_mm", p)
    belt_z = g.get("belt", {}).get("top_z", 1000)
    rgb_x = g.get("sensing", {}).get("rgb_center_x", 1300)
    induction_x = g.get("sensing", {}).get("induction_center_x", 1600)
    hood = g.get("optical_hood", {})
    hood_x0, hood_x1 = hood.get("x_min", 1050), hood.get("x_max", 1950)
    hood_width = hood.get("width", 900)
    hood_top = belt_z + hood.get("height_above_deck", 850)
    dz = belt_z - 1000
    colors = dict(steel="#7c8994", frame="#364958", sheet="#a5b5be", black="#18262f", amber="#f5b841", light="#e5f3ed", green="#4bba98", red="#dc5c56", polymer="#b7c9bd")

    def emit(ident, name, cat, shape, color="steel", **meta):
        meta.setdefault("evidence_status", "design_assumption")
        meta.setdefault("manufacturing_status", "concept_only_not_fabrication_release")
        meta.setdefault("source_module", "sensor_feed.py")
        add(ident, name, cat, shape, color=colors.get(color, color), **meta)

    # Small open hopper: a tapered sheet shell, not an opaque block.
    hopper_z0, hopper_z1 = 1250 + dz, 1645 + dz
    outer = (cq.Workplane("XY").workplane(offset=hopper_z0).center(-960, 0).rect(300, 480)
             .workplane(offset=hopper_z1 - hopper_z0).rect(640, 750).loft(combine=True))
    inner = (cq.Workplane("XY").workplane(offset=hopper_z0 - 1).center(-960, 0).rect(294, 474)
             .workplane(offset=hopper_z1 - hopper_z0 + 2).rect(634, 744).loft(combine=True))
    emit("feed_hopper_shell", "Tapered feed hopper · concept sheet shell", "feeder", outer.cut(inner), "sheet", material="unselected_sheet_material", capacity="unvalidated", opening_mm=[640, 750], outlet_mm=[300, 480])
    rim = box(660, 770, 10, -960, 0, 1650 + dz).cut(box(634, 744, 14, -960, 0, 1650 + dz))
    emit("feed_hopper_rim", "Hopper reinforced rim", "feeder", rim)
    throat = box(306, 486, 24, -960, 0, 1238 + dz).cut(box(294, 474, 30, -960, 0, 1238 + dz))
    emit("feed_hopper_throat", "Open metering throat", "feeder", throat, "sheet", feed_rate="No volumetric or mass-rate guarantee")
    # Tray floor slopes down towards x=0; side cheeks and outlet are separate.
    emit("feed_tray_floor", "Sloped vibratory spreader tray", "feeder", xz_plate([(-1110, 1220 + dz), (-40, 1030 + dz), (-40, 1024 + dz), (-1110, 1214 + dz)], 560), "sheet", slope_status="chosen_visual_geometry_requires_feed_trial")
    for sign, side in [(-1, "near"), (1, "far")]:
        emit(f"feed_tray_cheek_{side}", "Tray removable side cheek", "feeder", xz_plate([(-1110, 1220 + dz), (-40, 1030 + dz), (-40, 1100 + dz), (-1110, 1350 + dz)], 4, sign * 282), "steel", removable=True)
    emit("feed_transfer_lip", "Covered transfer lip at belt inlet", "feeder", xz_plate([(-70, 1030 + dz), (0, 1015 + dz), (0, 1011 + dz), (-70, 1026 + dz)], 560), "sheet", transfer_drop_mm=15, clearance_status="fragment_jam_and_trajectory_test_required")
    # Stiffness rails and independently isolated feeder stand.
    for sign, side in [(-1, "near"), (1, "far")]:
        emit(f"feed_tray_rib_{side}", "Tray underside reinforcement", "feeder", xz_plate([(-1090, 1206 + dz), (-70, 1025 + dz), (-70, 990 + dz), (-1090, 1171 + dz)], 25, sign * 210), "frame")
    for x in (-1210, -230):
        leg_top = 1080 if x == -1210 else 925
        for y in (-355, 355):
            tag = f"{abs(x)}_{'n' if y < 0 else 'p'}"
            emit("feed_leg_" + tag, "Independent feeder support leg", "feeder", rhs_z(60, 4, leg_top - 80 + dz, x, y, (leg_top + 80) / 2 + dz / 2), "frame", section_mm="60×60×4 study section; structural calculation pending")
            emit("feed_foot_" + tag, "Feeder levelling foot plate", "feeder", box(125, 125, 12, x, y, 74), "steel")
            emit("feed_floor_pad_" + tag, "Feeder floor support pad · study envelope", "feeder", box(125, 125, 68, x, y, 34), "black", material="unselected_support_pad_material", anchorage="unvalidated", load_capacity="unvalidated", interface="floor_z0_to_existing_footplate_bottom_z68")
            emit("feed_level_stud_" + tag, "Feeder levelling stud envelope", "feeder", cyl(12, 60, x, y, 80), "steel", thread="not_modelled")
    for x in (-1210, -230):
        z = 1090 if x == -1210 else 925
        emit(f"feed_support_cross_{abs(x)}", "Feeder stand transverse bearer", "feeder", box(70, 770, 60, x, 0, z + dz), "frame")
    for y in (-240, 240):
        emit(f"feed_isolation_bearer_{int(y)}", "Sloped fixed feeder isolation bearer", "feeder", xz_plate([(-1210, 1120 + dz), (-90, 920 + dz), (-90, 880 + dz), (-1210, 1080 + dz)], 45, y), "frame")
    for y in (-355, 355):
        emit(f"feed_base_tie_{int(y)}", "Feeder stand lower longitudinal tie", "feeder", box(1030, 45, 45, -720, y, 280), "frame")
        emit(f"feed_hopper_post_{int(y)}", "Hopper independent support extension", "feeder", rhs_z(40, 3, 560, -1210, y, 1320 + dz), "frame")
        emit(f"feed_hopper_support_{int(y)}", "Hopper side mounting bracket", "feeder", box(360, 35, 30, -1050, y, 1580 + dz), "frame")
    for x, z in [(-1030, 1125), (-160, 970)]:
        for y in (-240, 240):
            tag = f"{abs(x)}_{int(y)}"
            emit("feed_isolator_" + tag, "Feeder elastomer isolation mount envelope", "feeder", cyl(32, 45, x, y, z + dz), "black", damping="unselected; transmissibility and fasteners unresolved")
            emit("feed_isolator_seat_" + tag, "Isolation mount seat", "feeder", box(100, 100, 8, x, y, z - 4 + dz))
            emit("feed_isolator_pedestal_" + tag, "Isolation seat mounting pedestal", "feeder", box(65, 75, 45, x, y, z - 30 + dz), "frame")
            emit("feed_isolator_upper_" + tag, "Tray isolation mount connection spacer", "feeder", box(70, 80, 35, x, y, z + 60 + dz), "steel")
    emit("feed_motor_envelope", "Variable vibratory drive · unselected device envelope", "feeder", cyl(64, 210, -860, -105, 1045 + dz, "y"), "frame", vendor_model=None, power=None, performance="No amplitude/frequency/feed-capacity claim")
    emit("feed_motor_mount", "Vibratory drive mounting plate", "feeder", box(220, 250, 12, -860, 0, 1115 + dz), "steel")
    for y in (-110, 110):
        emit(f"feed_motor_bridge_{int(y)}", "Drive plate bridge to sloped tray", "feeder", xz_plate([(-970, 1189 + dz), (-750, 1150 + dz), (-750, 1115 + dz), (-970, 1115 + dz)], 12, y), "steel")
    for y in (-116, 105):
        emit(f"feed_motor_end_{y}", "Vibratory-drive removable eccentric cover envelope", "feeder", cyl(72, 11, -860, y, 1045 + dz, "y"), "amber", device_internal_geometry="not represented")
    # Containment cover is a service node; omit it from the default cutaway.
    cover = box(510, 600, 5, -295, 0, 1230 + dz)
    cover = cover.union(box(510, 4, 120, -295, -298, 1172 + dz)).union(box(510, 4, 120, -295, 298, 1172 + dz))
    emit("feed_transfer_cover", "Lift-off feed transfer cover", "feeder", cover, "frame", removable=True, default_visible=False, cutaway_hidden=True, service_direction_mm=[0, 0, 350])
    port = cyl(50, 80, -390, 0, 1232 + dz).cut(cyl(46, 84, -390, 0, 1230 + dz))
    emit("feed_extraction_port", "Feed dust interface · no extraction sizing", "feeder", port, "steel", parent_component="feed_transfer_cover", default_visible=False, cutaway_hidden=True, dust_control="Placeholder; qualified dust/fire assessment required")

    # Hood perimeter, access panels and repeatable optical mounting rails.
    for x, xs in [(hood_x0 + 20, "in"), (hood_x1 - 20, "out")]:
        for y, ys in [(-hood_width / 2 + 20, "near"), (hood_width / 2 - 20, "far")]:
            emit(f"hood_post_{xs}_{ys}", "Optical hood structural upright", "hood", rhs_z(40, 3, hood_top - belt_z, x, y, (hood_top + belt_z) / 2), "frame")
            foot = box(80, 70, 8, x, y, belt_z + 4)
            for hx in (-25, 25):
                foot = foot.cut(cyl(4.5, 12, x + hx, y, belt_z - 2))
            emit(f"hood_foot_{xs}_{ys}", "Hood bolted mounting foot", "hood", foot)
            emit(f"hood_standoff_{xs}_{ys}", "Hood upright extension to base frame", "hood", rhs_z(40, 3, 92, x, y, belt_z - 46), "frame")
            outrigger_y = -400 if y < 0 else 400
            emit(f"hood_outrigger_{xs}_{ys}", "Hood outboard base mounting bracket", "hood", box(90, 130, 8, x, outrigger_y, belt_z - 96), "steel", interface="base_longitudinal_rail_top_z900")
    for y, side in [(-hood_width / 2 + 20, "near"), (hood_width / 2 - 20, "far")]:
        for z, zs in [(belt_z + 115, "sill"), (hood_top - 20, "upper")]:
            emit(f"hood_longitudinal_{side}_{zs}", "Hood longitudinal perimeter rail", "hood", box(hood_x1 - hood_x0 - 80, 35, 35, (hood_x0 + hood_x1) / 2, y, z), "frame")
    for x, side in [(hood_x0 + 20, "in"), (hood_x1 - 20, "out")]:
        emit(f"hood_transverse_{side}", "Hood transverse roof rail", "hood", box(40, hood_width - 80, 40, x, 0, hood_top - 20), "frame")
        # Baffled openings remain above the transport surface.
        emit(f"hood_baffle_{side}", "Hood entry/exit light baffle", "hood", box(3, hood_width - 80, 150, x, 0, hood_top - 115), "black", adjustable=True, guard_claim="No validated reach-prevention or interlock design")
    roof = box(hood_x1 - hood_x0, hood_width, 4, (hood_x0 + hood_x1) / 2, 0, hood_top - 2)
    emit("hood_roof", "Lift-off optical hood roof", "hood", roof, "frame", removable=True, default_visible=False, cutaway_hidden=True, service_direction_mm=[0, 0, 400])
    for y, side in [(-hood_width / 2 + 2, "near"), (hood_width / 2 - 2, "far")]:
        panel = box(820, 4, 670, 1500, y, 1475 + dz).cut(box(540, 8, 350, 1500, y, 1500 + dz))
        emit(f"hood_access_frame_{side}", "Removable optical service panel frame", "hood", panel, "frame", removable=True, default_visible=side == "far", cutaway_hidden=side == "near", service_direction_mm=[0, -450 if side == "near" else 450, 0])
        emit(f"hood_inspection_window_{side}", "Cleanable tinted inspection panel", "hood", box(564, 3, 374, 1500, y, 1500 + dz), "#557b87", opacity=0.18, transparent=True, removable=True, default_visible=side == "far", cutaway_hidden=side == "near", material="concept_transparent_panel; containment_rating_unselected")
        for x in (1130, 1860):
            for z in (1240, 1710):
                emit(f"hood_hinge_{side}_{x}_{z}", "Service panel hinge envelope", "hood", cyl(9, 65, x, y + (-9 if side == "near" else 9), z + dz), "steel", parent_component=f"hood_access_frame_{side}", default_visible=side == "far", cutaway_hidden=side == "near")
        emit(f"hood_handle_{side}", "Optical-panel pull handle", "hood", box(20, 25, 140, 1810, y + (-16 if side == "near" else 16), 1480 + dz), "black", parent_component=f"hood_access_frame_{side}", default_visible=side == "far", cutaway_hidden=side == "near")
    for y, side in [(-405, "near"), (405, "far")]:
        emit("optical_mount_longitudinal_" + side, "Optical crossrail longitudinal support to hood uprights", "camera", box(820, 30, 40, 1500, y, 1770 + dz), "steel")
    for x, ident in [(rgb_x, "rgb"), (1650, "depth")]:
        emit("optical_crossrail_" + ident, "Adjustable optical-device transverse crossrail", "camera", box(40, 820, 40, x, 0, 1770 + dz), "steel")
        for y in (-392, 392):
            emit(f"optical_crossrail_bracket_{ident}_{int(y)}", "Crossrail end clamp", "camera", box(75, 40, 75, x, y, 1755 + dz), "frame")
    mount = box(120, 8, 220, rgb_x, 65, 1660 + dz)
    for x in (rgb_x - 38, rgb_x + 38):
        slot = box(10, 16, 150, x, 65, 1660 + dz)
        slot = slot.union(cyl(5, 16, x, 57, 1735 + dz, "y")).union(cyl(5, 16, x, 57, 1585 + dz, "y"))
        mount = mount.cut(slot)
    emit("camera_height_adjust_plate", "Slotted camera-height adjustment plate", "camera", mount, "steel", height_range="concept_slots_only; selected_lens_calibration_required")
    emit("camera_carriage", "RGB camera adjustable carriage", "camera", box(140, 100, 12, rgb_x, 22, 1744 + dz), "frame")
    emit("camera_mount_bridge", "Camera body mounting bridge to height plate", "camera", box(100, 32, 12, rgb_x, 55, 1680 + dz), "steel")
    emit("camera_rgb_housing", "RGB camera · generic device envelope", "camera", box(85, 90, 95, rgb_x, 0, 1670 + dz), "black", device_envelope=True, vendor_model=None, camera_height_status="adjustable_unvalidated", footprint_mm={"center": [rgb_x, 0, belt_z + 1], "width_y": 400, "length_x": 300, "type": "illustrative_coverage_only", "selected_or_calibrated": False}, nominal_belt_width_mm=600, usable_sensing_width_mm=None)
    emit("camera_rgb_lens", "RGB lens barrel envelope", "camera", cyl(27, 40, rgb_x, 0, 1582.5 + dz), "frame", optics="focal_length_sensor_format_not_selected")
    emit("camera_rgb_glass", "RGB optical front face", "camera", cyl(23, 2, rgb_x, 0, 1580.5 + dz), "#589aad")
    emit("camera_rgb_connector", "Camera data connector envelope", "camera", cyl(10, 28, rgb_x + 43, 0, 1680 + dz, "x"), "steel")
    emit("depth_optional_housing", "Optional depth/3D device · envelope only", "camera", box(180, 90, 65, 1650, 0, 1715 + dz), "green", optional=True, device_envelope=True, default_visible=True, installed=False, laser_source_selected=False, coverage="not_selected", benefit="overlap_height_association_hypothesis")
    emit("depth_optional_mount", "Optional depth device mount envelope", "camera", box(140, 100, 8, 1650, 0, 1750 + dz), "steel", optional=True, installed=False)
    emit("depth_optional_front", "Optional depth optical face envelope", "camera", box(146, 65, 3, 1650, 0, 1681 + dz), "black", optional=True, installed=False)
    # Two diffuse light bars point inward. Illumination remains to be measured.
    for sign, side in [(-1, "near"), (1, "far")]:
        c = (1500, sign * 310, 1525 + dz)
        body = box(660, 62, 48, *c).rotate(c, (c[0] + 1, c[1], c[2]), -sign * 25)
        diffuser = box(646, 50, 4, 1500, sign * 310, 1499 + dz).rotate(c, (c[0] + 1, c[1], c[2]), -sign * 25)
        emit(f"light_bar_{side}", "Angled diffuse illumination bar housing", "light", body, "frame", illuminance="unselected", angle_deg=25)
        emit(f"light_diffuser_{side}", "Replaceable light-bar diffuser", "light", diffuser, "light", removable=True)
        for x in (1200, 1800):
            emit(f"light_mount_{side}_{x}", "Adjustable light-bar suspension bracket", "light", box(25, 25, 180, x, sign * 310, 1635 + dz), "steel")
        emit(f"light_mount_rail_{side}", "Light adjustment longitudinal rail", "light", box(820, 30, 30, 1500, sign * 310, 1720 + dz), "steel")
        for x in (rgb_x, 1650):
            emit(f"light_crossrail_clamp_{side}_{int(x)}", "Light rail clamp to optical crossrail", "light", box(55, 60, 45, x, sign * 310, 1745 + dz), "steel")

    # Under-belt cassette: hollow unpopulated housing and nonconductive cover.
    cx = induction_x
    tray = box(350, 600, 196, cx, 0, 878 + dz).cut(box(338, 588, 198, cx, 0, 885 + dz))
    emit("induction_cassette_tray", "Replaceable induction enclosure · no internal coil design", "sensor", tray, "green", device_envelope=True, internals="Not modelled; vendor or experimental sensor required", manufacturer_specification=False, physical_envelope_mm={"x": [cx - 175, cx + 175], "y": [-300, 300], "z": [780 + dz, 980 + dz]}, service_direction_mm=[0, -850, 0], last_active_datum_x_mm=1750, physical_enclosure_end_x_mm=cx + 175)
    emit("induction_nonconductive_cap", "Nonconductive cassette top cap", "sensor", box(350, 600, 4, cx, 0, 978 + dz), "polymer", material="unselected_nonconductive_material", active_coil_location="unknown", detection_coverage_mm=None)
    emit("sensing_window", "Nonconductive belt-support window · study thickness", "window", box(500, 600, 6, cx, 0, 991 + dz), "polymer", material="unselected_nonconductive_support", thickness_mm=6, thickness_status="illustrative_not_validated", housing_top_to_window_underside_gap_mm=8, active_sensor_standoff_mm=None, wear_deflection_static_control="requires_test", metallic_aperture="no_metal_support_plate_across_active_aperture")
    # End supports stay outside the cassette's x1425..1775 withdrawal corridor.
    # Polymer section sizes are only packaging assumptions; creep, strength,
    # deflection, wear and field interaction must be verified experimentally.
    for x, end in [(cx - 235, "in"), (cx + 235, "out")]:
        support_meta = dict(material="unselected_nonconductive_study_material", structural_validation="strength_creep_deflection_wear_and_field_interaction_unvalidated", performance_claim="none", support_interface="window_bottom_z988; beam_bottom_z968")
        emit(f"window_end_beam_{end}", "Nonconductive window end support beam · study section", "window", box(30, 770, 20, x, 0, 978 + dz), "polymer", **support_meta)
        for y, side, bottom in [(-365, "near", 760), (365, "far", 900)]:
            emit(f"window_support_pedestal_{end}_{side}", "Nonconductive window support pedestal · study section", "window", box(30 if side == "near" else 40, 40, 968 - bottom, x, y, (968 + bottom) / 2 + dz), "polymer", material="unselected_nonconductive_study_material", structural_validation="strength_creep_deflection_and_field_interaction_unvalidated", base_interface="dropped_negative_side_rail_top_z760" if side == "near" else "positive_side_rail_top_z900", cassette_withdrawal="outside_x1425_to1775_corridor")
    for x, tag in [(cx - 205, "in"), (cx + 205, "out")]:
        rail = box(28, 850, 20, x, -55, 770 + dz)
        emit("sensor_drawer_rail_" + tag, "External cassette drawer support rail", "sensor", rail, "polymer", material="nonconductive_support_study", load_rating=None, service_direction_mm=[0, -850, 0], support_validation="strength_wear_and_field_interaction_unvalidated")
        emit("sensor_far_hanger_" + tag, "Far-side external drawer rail hanger", "sensor", box(45, 35, 65, x, 355, 807.5 + dz), "polymer", material="nonconductive_support_study", interface="far_base_side_rail_bottom_z840")
        for y, side in [(-270, "near"), (270, "far")]:
            emit(f"sensor_locating_pin_{tag}_{side}", "Cassette external repeatable-locator pin", "sensor", cyl(6, 20, x, y, 780 + dz), "polymer", fit_tolerance="not_selected")
            emit(f"sensor_mount_tab_{tag}_{side}", "Cassette external slotted mounting tab", "sensor", box(40, 36, 8, x + (15 if tag == "in" else -15), y, 784 + dz).cut(cyl(7, 12, x, y, 778 + dz)), "polymer")
    handle = cyl(9, 190, cx - 95, -340, 870 + dz, "x")
    handle = handle.union(cyl(9, 42, cx - 95, -342, 870 + dz, "y")).union(cyl(9, 42, cx + 95, -342, 870 + dz, "y"))
    emit("sensor_drawer_handle", "Cassette withdrawal handle", "sensor", handle, "black", service_direction_mm=[0, -850, 0], side_clearance="negative_y_rail_clearance_reserved_with_frame_module")
    for x in (cx - 95, cx + 95):
        emit(f"sensor_handle_pad_{int(x)}", "Drawer handle backing pad", "sensor", box(40, 5, 40, x, -302.5, 870 + dz), "polymer")
    emit("sensor_connector_panel", "Cassette external data/power connector plate", "sensor", box(95, 5, 65, cx, -302.5, 820 + dz), "black", sensor_power="unselected", signal="amplitude_phase_interfaces_to_be_defined")
    for x in (cx - 25, cx + 25):
        emit(f"sensor_connector_{int(x)}", "Sensor external connector envelope", "sensor", cyl(9, 25, x, -330, 820 + dz, "y"), "steel")

    # Separate downstream tracking mount remains unpopulated in the baseline.
    for y, side in [(-420, "near"), (420, "far")]:
        emit(f"tracker_reserve_post_{side}", "Unpopulated final-tracker mounting post", "research", rhs_z(30, 3, 650, 2650, y, 1325 + dz), "steel", optional=True, installed_sensor=False)
        emit(f"tracker_reserve_extension_{side}", "Tracker mounting-post base extension", "research", rhs_z(30, 3, 92, 2650, y, 954 + dz), "steel", optional=True, installed_sensor=False)
        emit(f"tracker_reserve_foot_{side}", "Tracker mount outrigger foot", "research", box(75, 110, 8, 2650, -395 if y < 0 else 395, 904 + dz), "steel", optional=True, installed_sensor=False)
    emit("tracker_reserve_crossrail", "Unpopulated final-tracker transverse mount", "research", box(30, 870, 30, 2650, 0, 1650 + dz), "steel", optional=True, installed_sensor=False, purpose="test_need_for_pose_change_verification")
    emit("tracker_reserve_plate", "Empty tracker equipment mounting plate", "research", box(140, 120, 8, 2650, 0, 1629 + dz), "frame", optional=True, installed_sensor=False)

    # Cabinet is intentionally outside the induction region. No internal wiring
    # or safety architecture is implied by the face controls.
    cab = box(550, 300, 650, 475, -685, 525).cut(box(538, 294, 638, 475, -690, 525))
    emit("controls_cabinet_shell", "Control cabinet shell · external to sensor bay", "controls", cab, "frame", enclosure_rating=None, wiring_design="pending", parent_power_architecture="not_selected")
    door = box(550, 6, 650, 475, -838, 525)
    for z in range(320, 421, 20):
        door = door.cut(box(250, 12, 7, 445, -838, z))
    emit("controls_cabinet_door", "Hinged control cabinet door with ventilation study", "controls", door, "steel", removable=True, service_direction_mm=[-250, -400, 0], ingress_dust_thermal_rating="not_established")
    for z in (300, 740):
        emit(f"cabinet_hinge_{z}", "Cabinet door hinge", "controls", cyl(9, 75, 215, -844, z), "black")
    emit("cabinet_handle", "Cabinet door handle", "controls", box(18, 24, 120, 712, -853, 545), "black")
    emit("cabinet_display_bezel", "Operator display envelope", "controls", box(200, 12, 135, 460, -848, 680), "black", display_content="not_modelled")
    emit("cabinet_display_face", "Operator display front face", "controls", box(174, 2, 109, 460, -855, 680), "#29526a")
    emit("cabinet_isolator_base", "Lockable electrical-isolation provision envelope", "controls", box(60, 14, 60, 660, -850, 730), "amber", safety_design="placeholder_only_no_certification")
    emit("cabinet_isolator_handle", "Isolation handle envelope", "controls", box(18, 26, 55, 660, -869, 730), "red", safety_design="placeholder_only_no_certification")
    for x in (255, 695):
        for y in (-785, -585):
            emit(f"cabinet_foot_{x}_{abs(y)}", "Cabinet mounting pedestal", "controls", box(65, 65, 200, x, y, 100), "frame", anchorage="unvalidated", load_capacity="unvalidated", interface="floor_z0_to_cabinet_bottom_z200")
    for x in (385, 470, 555):
        emit(f"cabinet_gland_{x}", "Separated cable-gland envelope", "controls", cyl(13, 25, x, -650, 850), "black", power_signal_separation="routes_require_electrical_EMC_design")


if __name__ == "__main__":
    import json
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    params = json.loads((root / "design_basis/parameters.json").read_text())
    result = []

    def inspect(ident, name, category, shape, color, **meta):
        s = shape.val() if isinstance(shape, cq.Workplane) else shape
        result.append({"id": ident, "category": category, "valid": s.isValid(), "solid_count": len(s.Solids()), "volume_mm3": s.Volume()})

    build(inspect, params)
    invalid = [r for r in result if not r["valid"] or r["solid_count"] < 1 or r["volume_mm3"] <= 0]
    print(json.dumps({"components": len(result), "invalid": invalid, "solid_count": sum(r["solid_count"] for r in result)}, indent=2))
    raise SystemExit(bool(invalid))
