FERROSIFT CONVEYOR CONCEPT — EDITABLE SOURCE

Design study v0, 13 October 2026. Not a fabrication release or a tested sorting machine.

Contents: executed CadQuery model source, mechanical/sensor specification JSON,
parameter/design-basis files, calculations and tests, dependency lock, and three
research briefs. No model weights, private records, virtual environment, or
unexecuted Fusion probe are included.

To rebuild in a separate local Python 3.12 environment:
  python3.12 -m venv .venv-cad
  .venv-cad/bin/python -m pip install -r requirements.lock.txt
  .venv-cad/bin/python cad/build_conveyor.py

The build writes exports/, web/ and verification/ beneath the extracted folder.
Install dependencies only into your chosen isolated environment. The dependency
lock records the tested Mac environment; platform availability can differ.

The supplied STEP is an editable solid interchange assembly. The editable
parameter source is the CadQuery code and JSON; no Fusion feature history is
claimed. Rendering meshes alone do not establish strength, safety, sensing,
ejection performance, buyer acceptance or production capacity.

The 600 mm belt, 3000 mm deck and associated layout dimensions are study inputs.
Read the design basis and research limits before adapting the model. The older
steel/copper image model is separate and does not validate PCB classification.
