# Revalis M02 retrofit sensing module — 16 October 2026

M02 is a proposed removable computer-vision and multi-angle electromagnetic sensing module for an existing recycling line. The grey conveyor is partial host context. The module does not include a conveyor drive, feeder, ejector, chute or collection system. This is an inspectable research design, not a fabrication, site-installation, safety or performance release.

## Product boundary and geometry

`cad/build_module.py` is the editable CadQuery assembly; `cad/export_common.py` tessellates the actual BRep surfaces. `exports/module_assembly.step`, `.brep` and `.glb` contain the module and its removable calibration accessory. `module_with_host.*` adds the grey reference; `host_reference.*` isolates it. `exports/groups/` and `exports/selections/` provide exact subsets for review and drawings. GLB uses metres, Y up; CAD and `web/module-assembly.json` use millimetres, X travel / Y across / Z up. Scope and optional metadata distinguish module, host and optional exterior 3D capture.

The nominal 600 mm host belt has one central 180 mm mechanical experimental lane. Guides, flexible skirts, upstream outer-lane masks and removable pod covers are shown. Host metering/singulation must restrict feed before the stationary masks; blocked feed, collision, entrapment, wear and safe jam-clearing behavior remain unresolved. The 180 mm passage is neither validated sensitivity width nor an accepted fragment envelope. The outer lanes are unused; full-width arrays need a new layout and measured coverage/cross-talk/registration studies.

Station A has one XY-plane Tx winding and two independent Rx windings, with principally Z-directed excitation intended. Station B, 300 mm downstream, has one XZ-plane Tx winding and two independent Rx windings, with Y-directed excitation intended. Each of these six functional windings has a continuous open core, annular insulation, two distinct contact pins and a recessed inner return in its nonmetallic former. Main perimeter paths lie in the stated planes; return paths deliberately leave those planes.

M02 retains three nested rectangular perimeter passes, 3.8 mm centre pitch, a 0.9 mm core and 1.4 mm insulation OD. Spiral transitions and the terminal return mean these are visual passes, not exactly three closed encirclements. Requested bend radius is 1.2 mm, with a measured minimum of 1.2 mm. The open return groove matches the nominal insulation diameter, leaving a 1.0 mm former floor and 1.6 mm insulation separation beneath straight crossing turns. The separate nonlocal curve check found a smaller minimum insulation-envelope gap of 1.14558 mm near curved transitions. These are inspectable proposed packaging dimensions, not qualified winding instructions. Electrical turn count, wire/insulation construction, frequency/current, winding sense/polarity, parasitics, thermal limits, tolerance, retention and manufacture remain unselected.

The candidate Rx combination is unoptimized; independent channels remain distinct. Balanced cancellation, position-dependent sensitivity, field shape and assay performance are unmeasured. Tx/Rx reversal is not another independent direction. The stations observe fragments sequentially and need verified same-object association; encoder travel is belt travel, not fragment motion. Individual terminal pairs end the internal winding model: internal harness routing to cable exits, paired/shielded conductors, pinout and electrical circuitry remain unresolved. Cable-to-shell contact does not establish a complete circuit.

The proposed metal-exclusion/test reservation is X −180…480, Y ±340 and Z 850…1200. Metal structural parts are checked against this chosen box; intended coils and leads are explicitly inside it, and actual belt reinforcement/splices remain unknown. Its extent must be determined experimentally with the real host, return run, frames, rollers, shields and switching equipment. A nonmetallic support window alone does not prove host compatibility.

At the checked nominal pose, belt thickness is 4 mm, support thickness 6 mm, cartridge-cover to support gap 10 mm, bare Rx core top to belt surface 30.85 mm and bare Tx core top to belt surface 37.85 mm. Insulation-to-belt gaps are 30.6 mm (Rx) and 37.6 mm (Tx); separate terminal-pin gaps are 30.2 mm and 37.2 mm. These values are distinct source extrema, not a sensitivity or accepted lift-off claim. Conductive-feature height and motion add to relevant separation. The return belt has 64 mm nominal clearance below the cartridge. Loaded deflection, tolerances, wear and material choices are unresolved.

## Mounting, adjustment and service

The module uses proposed slotted host clamps, optical slots, a transverse Y-slot carriage and Z-slot mounting plate, plus removable nonmetallic height spacer packs beneath the under-belt slide rails. Retainers and mounting surfaces are inspectable. Only the installed nominal pose is geometrically checked: adjustment travel, loads, locking, repeatability, manufacturing tolerances and hardware materials/ratings still require engineering review.

The under-belt cartridge, its cover, coils, formers and handle withdraw 850 mm toward negative Y after isolation, releasing the stated cover retainers, disconnecting leads and supplying external support. The conservative source-solid swept check includes the flanges and handle; host rails are shown with 30 mm nominal cartridge clearance and 10 mm below the fixed slide rails. The control front removes toward negative Y and the optical cover upward. No drawing establishes an approved operator aisle, lifting method or safe energized access.

A removable nonmetallic calibration carrier, handle and unselected reference coupon envelope are provided as a hidden accessory and separate STEP selection. The reference material, certified targets, calibration procedure, field maps, safe insertion and repeatability are unselected. The optical centreline check is only a centreline check, not full field-of-view or depth-performance validation.

## Editing and rebuilding

The full geometric layout is editable in `cad/build_module.py`. `design_basis/parameters.json` and `geometry_contract.json` are coordination registers: the current source executes host width and belt datum for shapes, while other dimensional edits require corresponding source changes and complete regeneration. The released coordinate metadata is valid only at the nominal belt-top Z=1000 mm. The +100 mm datum test is a shape-translation probe; it does not update coil, cable or gland coordinate metadata or establish nonnominal export consistency. The nominal 600 mm host is the only checked interface. A `--host-width` validity probe does not adapt every clamp or establish compatibility with another belt width; do not treat valid solids as a validated parametric product family.

Use the preserved local CadQuery environment or reproduce `requirements.lock.txt`. No cloud CAD, model training or paid service is needed:

```sh
export PYTHONDONTWRITEBYTECODE=1
export XDG_CACHE_HOME=/tmp/revalis-module-cad-cache
# Set CAD_PYTHON to a compatible local interpreter.
"$CAD_PYTHON" cad/build_module.py
"$CAD_PYTHON" verification/check_interfaces.py
"$CAD_PYTHON" ../verification/independent_engineering/review_source_geometry.py
"$CAD_PYTHON" ../verification/independent_engineering/review_winding_geometry.py
"$CAD_PYTHON" ../verification/independent_engineering/review_hardware_geometry.py
"$CAD_PYTHON" ../verification/independent_engineering/verify_export_files.py
"$CAD_PYTHON" ../verification/independent_engineering/verify_datum_parameter.py
```

Rebuild drawings/figures using their own included instructions only after export source hashes are stable. Exported STEP timestamps can change byte identity. Regenerate manifests, receipts, drawings and web assets together; do not replace old files in preserved history.

`verification/cad_export_validation.json` records source validity, STEP reopening, volume/bounds and mesh counts. `interfaces_review.json` records scoped clearance/contact checks. `geometry_checks.json` aggregates the release evidence. These checks do not establish field performance, sensor coverage, recovery, purity, economic benefit or certification. `design_basis/design_holds.json` lists outstanding engineering and physical validation gates; `interface_contract.json` separates acquisition, host and safety responsibilities. `bom/component_schedule.csv` is a geometric component schedule, not a purchased bill of materials.


M01 and the sealed M01-W1 source and exports remain unchanged in the sibling `module_package_20261015_v01` private archive. M02 retains all six winding paths and the same host, feed and service arrangement while refining real support hardware, optics and external cable entries. `cad/windings.py` is the authoritative winding geometry helper and is included in export provenance.

For winding mesh surfaces only, the angular tessellation parameter is 0.32 rad. Circular chord estimates are about 0.006 mm for the core radius and 0.009 mm for the insulation outer radius; these are tessellation estimates, not manufacturing tolerances or global error certification. Exact STEP/BREP geometry is preserved.


## M02 hardware detail

The relieved Tx and Rx formers have open centers and visible support bridges. Nonmetallic perimeter lips and six locating-pin keepers sit around and over the actual insulated paths. The keeper bridges make nominal insulation contact; their material, retention, fatigue, tolerance, adhesive and dielectric suitability are unqualified. No winding count, pitch, conductor diameter or electrical performance was optimized by these additions.

RGB and optional depth heads now have hollow housings, recessed window seats and attached retaining bezels. The RGB lens barrel has three real annular grooves and a 2 mm glass recess. Its glass datum remains Z=1443; the lower retaining rim reaches Z=1441. A recessed mounting shoe and socket fasteners locate the RGB body on the slotted carrier. Shallow housing grooves and positive socket-head floors are actual CAD features, not texture effects. No lens prescription, sensor vendor, ingress rating or heat-dissipation performance is selected.

External cable paths use rounded source sweeps with separate optical and transverse branches. Proposed glands have matching wall bores, exterior flanges, interior locknuts and nominal cable-contact inserts. Straight final approaches follow the gland axes. The cabinet has separate proposed RGB, optional depth, A, B-Tx, B-Rx and encoder entries; power and host-IO openings have no external cable modeled. Internal winding-to-cable harnesses, circuitry, pinout, grounding, shielding, selected bend limits and strain-relief qualification remain unresolved. The encoder sensor-end seal remains an explicit interface hold.

For an opaque winding inspection view, use `presentationHideSets` from the mesh packet: remove the listed covers, belt and support window, then optionally hide the actual insulation annuli to inspect the copper cores. Keep the relieved formers, bobbin lips, keeper bridges, terminals and far-side housing opaque. The near side housing can be separately omitted only with an explicit cutaway label. `exports/selections/optical_detail.step` and `winding_detail.step` contain the exact native subsets.


Some inherited fastener receivers remain coordination geometry: the window-bridge and lane retainers, cover/control-panel receivers and four lower-rail clamp passages still require coordinated clearance, bearing and engagement details. The socket heads have actual 3 mm recesses and 2 mm floors, but that does not complete their installation interfaces. The two RGB screws have explicitly illustrative nominal engagement into the housing; no helical thread, supplier specification, torque or strength is asserted. These unfinished fastening interfaces are recorded separately from the checked M02 gland wall bores and bearing faces.

The external cable runs include proposed separated routing layers below the cabinet. Only the optical overhead saddles are modeled as local cable supports; the remaining route requires selected clips/tray, minimum bend-radius verification, strain relief and service-disconnection engineering. The drawn cable solids do not establish an installable harness or cable qualification.

## Revalis branding release R01

This package changes the current product name and presentation only. The underlying hardware remains geometry revision M02. Native BRep bytes, STEP geometric statements, GLB binary buffers and all 353 web mesh objects are identical to the preserved M02 release. STEP assembly names, GLB generator metadata, presentation labels and source provenance hashes are updated. The drawings use the same exact projected geometry, rendered with Revalis title blocks. `verification/rebrand/` at the package root records the comparison; historical validation is retained under `history/M02_validation/` and was not rerun or upgraded to physical certification. Public downloads use `revalis_` names; legacy downloads remain unchanged.
