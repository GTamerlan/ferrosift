/* Offscreen CAD illustration: exact source triangles, orthographic camera,
 * per-fragment depth test, individual-triangle-sorted transparent surfaces.
 * No UI, external library, geometry simplification, pose change or remeshing.
 */
'use strict';
(function(){
const W=2400,H=1440,VP={x:70,y:170,w:2260,h:1090};let RW=VP.w,RH=VP.h;
const dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0),cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],norm=a=>{const s=Math.hypot(...a);return a.map(v=>v/s);},rgb=s=>[0,2,4].map(i=>parseInt(s.replace('#','').slice(i,i+2),16)/255);
const canvas=document.createElement('canvas');canvas.width=VP.w;canvas.height=VP.h;
const gl=canvas.getContext('webgl2',{alpha:false,antialias:true,depth:true,preserveDrawingBuffer:true});
if(!gl)throw Error('WebGL2 is required for static depth-buffer previews.');
const VS=`#version 300 es
in vec3 position;in vec3 normal;uniform mat4 vp;out vec3 world;out vec3 n;
void main(){world=position;n=normal;gl_Position=vp*vec4(position,1.0);}`;
const FS=`#version 300 es
precision highp float;in vec3 world;in vec3 n;uniform vec3 color;uniform float alpha;uniform float unlit;uniform float metalness;uniform float gloss;uniform mat4 lightVP;uniform highp sampler2DShadow shadowMap;uniform vec2 shadowTexel;uniform vec3 viewDirection;uniform vec3 clipMin;uniform vec3 clipMax;out vec4 pixel;
void main(){if(any(lessThan(world,clipMin))||any(greaterThan(world,clipMax)))discard;
vec3 nn=normalize(n);if(!gl_FrontFacing)nn=-nn;
vec3 key=normalize(vec3(-.45,-.65,1.)),fill=normalize(viewDirection),rim=normalize(vec3(.15,1.,.8));
vec3 base=pow(color,vec3(2.2));
float sky=.20+.20*(nn.z*.5+.5);
vec4 lightPoint=lightVP*vec4(world+nn*.12,1.);vec3 samplePoint=lightPoint.xyz/lightPoint.w*.5+.5;
float visibility=1.;if(all(greaterThanEqual(samplePoint,vec3(0.)))&&all(lessThanEqual(samplePoint,vec3(1.)))){
 visibility=0.;for(int x=-1;x<=1;x++)for(int y=-1;y<=1;y++)visibility+=texture(shadowMap,vec3(samplePoint.xy+vec2(float(x),float(y))*shadowTexel*1.15,samplePoint.z-.00012));visibility/=9.;}
float diffuse=sky+.95*max(0.,dot(nn,key))*visibility+.26*max(0.,dot(nn,fill))+.18*max(0.,dot(nn,rim));
vec3 h=normalize(key+viewDirection);vec3 hf=normalize(fill+viewDirection);vec3 hr=normalize(rim+viewDirection);
float spec=pow(max(0.,dot(nn,h)),gloss)*.95+pow(max(0.,dot(nn,hf)),gloss*.65)*.26+pow(max(0.,dot(nn,hr)),gloss*.8)*.36;
vec3 f0=mix(vec3(.035),base,metalness);float fresnel=pow(1.-max(0.,dot(nn,viewDirection)),5.);
vec3 linear=base*diffuse*(1.-metalness*.3)+(f0+(1.-f0)*fresnel)*spec;
linear=linear/(vec3(.60)+linear)*.94;
vec3 display=pow(max(linear,vec3(0.)),vec3(1./2.2));
pixel=vec4(mix(display,color,unlit),alpha);}`;
function shader(type,src){const s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s;}
const program=gl.createProgram();gl.attachShader(program,shader(gl.VERTEX_SHADER,VS));gl.attachShader(program,shader(gl.FRAGMENT_SHADER,FS));gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(program));
const loc={};for(const name of ['vp','color','alpha','unlit','metalness','gloss','lightVP','shadowMap','shadowTexel','viewDirection','clipMin','clipMax'])loc[name]=gl.getUniformLocation(program,name);loc.position=gl.getAttribLocation(program,'position');loc.normal=gl.getAttribLocation(program,'normal');
// A depth-only directional-light pass uses the same source triangle buffers.
const shadowWidth=4096,shadowHeight=2048,shadowTexture=gl.createTexture();
gl.bindTexture(gl.TEXTURE_2D,shadowTexture);gl.texImage2D(gl.TEXTURE_2D,0,gl.DEPTH_COMPONENT24,shadowWidth,shadowHeight,0,gl.DEPTH_COMPONENT,gl.UNSIGNED_INT,null);
gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_COMPARE_MODE,gl.COMPARE_REF_TO_TEXTURE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_COMPARE_FUNC,gl.LEQUAL);
const shadowFbo=gl.createFramebuffer();gl.bindFramebuffer(gl.FRAMEBUFFER,shadowFbo);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.TEXTURE_2D,shadowTexture,0);gl.drawBuffers([gl.NONE]);gl.readBuffer(gl.NONE);if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw Error('Incomplete shadow framebuffer');gl.bindFramebuffer(gl.FRAMEBUFFER,null);
const shadowProgram=gl.createProgram();gl.attachShader(shadowProgram,shader(gl.VERTEX_SHADER,'#version 300 es\nin vec3 position;uniform mat4 vp;out vec3 world;void main(){world=position;gl_Position=vp*vec4(position,1.);}'));
gl.attachShader(shadowProgram,shader(gl.FRAGMENT_SHADER,'#version 300 es\nprecision highp float;in vec3 world;uniform vec3 clipMin;uniform vec3 clipMax;void main(){if(any(lessThan(world,clipMin))||any(greaterThan(world,clipMax)))discard;}'));gl.linkProgram(shadowProgram);if(!gl.getProgramParameter(shadowProgram,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(shadowProgram));
const shadowLoc={position:gl.getAttribLocation(shadowProgram,'position'),vp:gl.getUniformLocation(shadowProgram,'vp'),clipMin:gl.getUniformLocation(shadowProgram,'clipMin'),clipMax:gl.getUniformLocation(shadowProgram,'clipMax')};
function renderShadow(items,s){for(let i=0;i<gl.getParameter(gl.MAX_VERTEX_ATTRIBS);i++)gl.disableVertexAttribArray(i);const light=camera(items,{...s,azimuth:-124.7,elevation:51.7});gl.bindFramebuffer(gl.FRAMEBUFFER,shadowFbo);gl.viewport(0,0,shadowWidth,shadowHeight);gl.clearDepth(1);gl.clear(gl.DEPTH_BUFFER_BIT);gl.useProgram(shadowProgram);gl.enable(gl.POLYGON_OFFSET_FILL);gl.polygonOffset(3,6);gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LESS);gl.disable(gl.BLEND);gl.depthMask(true);gl.disable(gl.CULL_FACE);gl.uniformMatrix4fv(shadowLoc.vp,false,light.matrix);gl.uniform3fv(shadowLoc.clipMin,s.clipMin);gl.uniform3fv(shadowLoc.clipMax,s.clipMax);
 for(const m of items){gl.bindBuffer(gl.ARRAY_BUFFER,m.positionBuffer);gl.enableVertexAttribArray(shadowLoc.position);gl.vertexAttribPointer(shadowLoc.position,3,gl.FLOAT,false,0,0);gl.drawArrays(gl.TRIANGLES,0,m.count);}
 gl.disable(gl.POLYGON_OFFSET_FILL);gl.bindFramebuffer(gl.FRAMEBUFFER,null);return light;}
let assembly,meshes;
function buffer(values){const b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(values),gl.STATIC_DRAW);return b;}
function mesh(object){if(!object.vertices||!object.indices||!object.normals)throw Error('Incomplete mesh '+object.id);
 const v=new Float32Array(object.indices.length*3),n=new Float32Array(v.length);object.indices.forEach((index,k)=>{v.set(object.vertices.slice(index*3,index*3+3),k*3);n.set(object.normals.slice(index*3,index*3+3),k*3);});
 const bounds=object.bbox||{min:[Infinity,Infinity,Infinity],max:[-Infinity,-Infinity,-Infinity]};if(!object.bbox)for(let i=0;i<v.length;i+=3)for(let k=0;k<3;k++){bounds.min[k]=Math.min(bounds.min[k],v[i+k]);bounds.max[k]=Math.max(bounds.max[k],v[i+k]);}
 return{object,v,n,positionBuffer:buffer(v),normalBuffer:buffer(n),bounds,color:rgb(object.color),opacity:object.opacity??1,count:v.length/3};}
function bind(m){gl.bindBuffer(gl.ARRAY_BUFFER,m.positionBuffer);gl.enableVertexAttribArray(loc.position);gl.vertexAttribPointer(loc.position,3,gl.FLOAT,false,0,0);gl.bindBuffer(gl.ARRAY_BUFFER,m.normalBuffer);gl.enableVertexAttribArray(loc.normal);gl.vertexAttribPointer(loc.normal,3,gl.FLOAT,false,0,0);}
function draw(m,unlit=0){bind(m);gl.uniform1f(loc.metalness,m.metalness??0);gl.uniform1f(loc.gloss,m.gloss??36);gl.uniform3fv(loc.color,m.color);gl.uniform1f(loc.alpha,m.opacity);gl.uniform1f(loc.unlit,unlit);gl.drawArrays(gl.TRIANGLES,0,m.count);}
function material(m,s){const c=m.object.materialClass,id=m.object.id;let color=m.color,metalness=0,gloss=36;
 if(c==='coil_conductor'||c==='coil_terminal'){color=rgb('#bd743c');metalness=.78;gloss=90;}
 else if(c==='metal'){const raw=m.object.color.toLowerCase();metalness=raw==='#8a9aa3'||raw==='#d8e7e7'?.65:.12;gloss=metalness>.5?76:40;}
 else if(c==='optical_glass'){metalness=.5;gloss=120;}
 else if(c==='cable'||id.includes('gland')){metalness=.06;gloss=28;}
 if(m.object.scope==='host_reference'){color=rgb(c==='host_belt_unknown'?'#9ca3a8':'#b1b7bc');metalness=.15;gloss=32;}
 return{...m,color,metalness,gloss,opacity:s.opacityByGroup?.[m.object.group]??m.opacity};}
function visible(m,s){return (!m.object.default_hidden||s.includeHidden)&&(!s.scopes||s.scopes.includes(m.object.scope))&&(!s.groups||s.groups.includes(m.object.group))&&(!s.excludeIds||!s.excludeIds.includes(m.object.id))&&(!s.includeIds||s.includeIds.includes(m.object.id))&&(!s.includeIdPrefixes||s.includeIdPrefixes.some(p=>m.object.id.startsWith(p)))&&m.bounds.min.every((v,k)=>v<=s.clipMax[k])&&m.bounds.max.every((v,k)=>v>=s.clipMin[k]);}
function camera(items,s){const az=s.azimuth*Math.PI/180,el=s.elevation*Math.PI/180,direction=[Math.cos(az)*Math.cos(el),Math.sin(az)*Math.cos(el),Math.sin(el)],right=norm(cross([0,0,1],direction)),up=cross(direction,right),lo=[Infinity,Infinity,Infinity],hi=[-Infinity,-Infinity,-Infinity];
 for(const m of items){const a=m.bounds.min.map((v,k)=>Math.max(v,s.clipMin[k])),b=m.bounds.max.map((v,k)=>Math.min(v,s.clipMax[k]));if(a.some((v,k)=>v>b[k]))continue;
  for(const x of[a[0],b[0]])for(const y of[a[1],b[1]])for(const z of[a[2],b[2]]){const p=[x,y,z],q=[dot(p,right),dot(p,up),dot(p,direction)];q.forEach((v,k)=>{lo[k]=Math.min(lo[k],v);hi[k]=Math.max(hi[k],v);});}}
 const center=lo.map((v,k)=>(v+hi[k])/2);let spanX=(hi[0]-lo[0])*1.09,spanY=(hi[1]-lo[1])*1.10;if(spanX/spanY>RW/RH)spanY=spanX*RH/RW;else spanX=spanY*RW/RH;
 const depth=(hi[2]-lo[2])/2+1000,sx=spanX/2,sy=spanY/2,matrix=new Float32Array([right[0]/sx,up[0]/sy,-direction[0]/depth,0,right[1]/sx,up[1]/sy,-direction[1]/depth,0,right[2]/sx,up[2]/sy,-direction[2]/depth,0,-center[0]/sx,-center[1]/sy,center[2]/depth,1]);
 return{direction,right,up,matrix,spanX,spanY,center,viewBounds:{min:lo,max:hi}};}
function transparentPass(items,cam){const tris=[];for(const m of items)for(let i=0;i<m.v.length;i+=9){let d=0;for(let k=0;k<3;k++)d+=dot(Array.from(m.v.slice(i+k*3,i+k*3+3)),cam.direction)/3;tris.push({m,i,d});}tris.sort((a,b)=>a.d-b.d);
 const batches=[];for(const t of tris){let b=batches.at(-1);if(!b||b.mesh!==t.m){b={mesh:t.m,v:[],n:[]};batches.push(b);}b.v.push(...t.m.v.slice(t.i,t.i+9));b.n.push(...t.m.n.slice(t.i,t.i+9));}
 gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);gl.depthMask(false);for(const b of batches){const m={...b.mesh,positionBuffer:buffer(b.v),normalBuffer:buffer(b.n),count:b.v.length/3};draw(m);gl.deleteBuffer(m.positionBuffer);gl.deleteBuffer(m.normalBuffer);}gl.depthMask(true);gl.disable(gl.BLEND);return tris.length;}
function routeMeshes(s,cam){if(!s.routes)return[];const colors={target:'#c97e29',balance:'#34799b',review:'#995e47'},result=[];
 for(const[name,path]of Object.entries(assembly.routes||{})){const v=[],n=[];for(let i=1;i<path.length;i++){const a=path[i-1],b=path[i],delta=b.map((x,k)=>x-a[k]),len=Math.hypot(...delta),dir=delta.map(x=>x/len),side=norm(cross(dir,cam.direction)).map(x=>x*5.5);
  for(let start=0;start<len;start+=46){const end=Math.min(start+27,len),p=a.map((x,k)=>x+dir[k]*start),q=a.map((x,k)=>x+dir[k]*end),corners=[p.map((x,k)=>x+side[k]),p.map((x,k)=>x-side[k]),q.map((x,k)=>x-side[k]),q.map((x,k)=>x+side[k])];for(const k of[0,1,2,0,2,3]){v.push(...corners[k]);n.push(...cam.direction);}}}
 result.push({positionBuffer:buffer(v),normalBuffer:buffer(n),count:v.length/3,color:rgb(colors[name]),opacity:1});}return result;}
function axes(ctx,cam){const ox=2200,oy=1310,colors=['#ad754e','#5c8770','#507d9c'];ctx.lineCap='round';ctx.lineWidth=3;ctx.font='600 20px Arial';
 for(let k=0;k<3;k++){const dx=cam.right[k]*67,dy=-cam.up[k]*67;ctx.strokeStyle=colors[k];ctx.fillStyle=colors[k];ctx.beginPath();ctx.moveTo(ox,oy);ctx.lineTo(ox+dx,oy+dy);ctx.stroke();ctx.fillText(['X','Y','Z'][k],ox+dx+7,oy+dy+6);}ctx.font='18px Arial';ctx.fillStyle='#536b79';ctx.fillText('CAD axes',2163,1374);}
function compose(s,cam,count,art){const sheet=document.createElement('canvas');sheet.width=W;sheet.height=H;const ctx=sheet.getContext('2d');ctx.fillStyle='#f3f5f6';ctx.fillRect(0,0,W,H);ctx.drawImage(art,VP.x,VP.y);
 ctx.fillStyle='#172c36';ctx.font='600 48px Arial';ctx.fillText(s.title,70,84);ctx.font='22px Arial';ctx.fillStyle='#536b79';ctx.fillText('REVALIS  /  RETROFIT SENSING MODULE  /  '+(s.revision||'M02'),72,126);
 ctx.fillStyle='#536b79';ctx.font='600 21px Arial';ctx.textAlign='right';ctx.fillText(s.code,2325,85);ctx.textAlign='left';ctx.strokeStyle='#bdced4';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(70,151);ctx.lineTo(2330,151);ctx.stroke();
 const project=p=>[VP.x+VP.w*(.5+(dot(p,cam.right)-cam.center[0])/cam.spanX),VP.y+VP.h*(.5-(dot(p,cam.up)-cam.center[1])/cam.spanY)];
 if(s.exclusion){const e=s.exclusion,c=[];for(const x of[e.min[0],e.max[0]])for(const y of[e.min[1],e.max[1]])for(const z of[e.min[2],e.max[2]])c.push([x,y,z]);ctx.strokeStyle='#ca9a61';ctx.lineWidth=2;ctx.setLineDash([10,7]);for(let i=0;i<8;i++)for(let j=i+1;j<8;j++){if(c[i].filter((v,k)=>v!==c[j][k]).length===1){const a=project(c[i]),b=project(c[j]);ctx.beginPath();ctx.moveTo(...a);ctx.lineTo(...b);ctx.stroke();}}ctx.setLineDash([]);}
 if(s.arrows)for(const arrow of s.arrows){const a=project(arrow.from),b=project(arrow.to),angle=Math.atan2(b[1]-a[1],b[0]-a[0]);ctx.strokeStyle=arrow.color||'#f2c984';ctx.fillStyle=arrow.color||'#f2c984';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(...a);ctx.lineTo(...b);ctx.stroke();ctx.beginPath();ctx.moveTo(...b);ctx.lineTo(b[0]-18*Math.cos(angle-.45),b[1]-18*Math.sin(angle-.45));ctx.lineTo(b[0]-18*Math.cos(angle+.45),b[1]-18*Math.sin(angle+.45));ctx.fill();if(arrow.label){ctx.font='600 23px Arial';ctx.fillText(arrow.label,b[0]+12,b[1]-12);}}
 if(s.panels){ctx.font='600 22px Arial';ctx.fillStyle='#2e4956';for(const p of s.panels)ctx.fillText(p.label,VP.x+p.placement[0]+14,VP.y+p.placement[1]+25);}
 if(s.detail){ctx.font='600 22px Arial';ctx.fillStyle='#2e4956';ctx.fillText('A  OVERALL MODULE',90,200);ctx.fillText('B  RGB HEAD DETAIL',1730,200);ctx.strokeStyle='#bdced4';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(1690,230);ctx.lineTo(1690,1170);ctx.stroke();ctx.font='19px Arial';ctx.fillStyle='#536b79';ctx.fillText('Carrier, cover and lighting omitted.',1730,1230);}
 ctx.font='23px Arial';ctx.fillStyle='#2e4956';ctx.fillText(s.caption,72,1304);
 ctx.font='21px Arial';ctx.fillStyle='#536b79';ctx.fillText(s.contextNote,72,1340);ctx.fillText('Research geometry • not fabrication-certified',72,1375);if(s.showAxes)axes(ctx,cam);
 return sheet.toDataURL('image/png').split(',')[1];}
window.depthProbe=function(){const c=document.createElement('canvas');c.width=c.height=16;const g=c.getContext('webgl2',{depth:true,antialias:false,preserveDrawingBuffer:true});
 const compile=(type,src)=>{const s=g.createShader(type);g.shaderSource(s,src);g.compileShader(s);if(!g.getShaderParameter(s,g.COMPILE_STATUS))throw Error(g.getShaderInfoLog(s));return s;};const p=g.createProgram();g.attachShader(p,compile(g.VERTEX_SHADER,'#version 300 es\nin vec3 p;void main(){gl_Position=vec4(p,1.);}'));g.attachShader(p,compile(g.FRAGMENT_SHADER,'#version 300 es\nprecision highp float;uniform vec3 c;out vec4 outColor;void main(){outColor=vec4(c,1.);}'));g.linkProgram(p);g.useProgram(p);
 const pl=g.getAttribLocation(p,'p'),cl=g.getUniformLocation(p,'c'),b=g.createBuffer();g.bindBuffer(g.ARRAY_BUFFER,b);g.enableVertexAttribArray(pl);g.vertexAttribPointer(pl,3,g.FLOAT,false,0,0);g.enable(g.DEPTH_TEST);g.depthFunc(g.LESS);g.viewport(0,0,16,16);
 const draw=(z,color)=>{g.bufferData(g.ARRAY_BUFFER,new Float32Array([-1,-1,z,3,-1,z,-1,3,z]),g.STREAM_DRAW);g.uniform3fv(cl,color);g.drawArrays(g.TRIANGLES,0,3);};const tests=[];
 for(const reversed of[false,true]){g.clear(g.COLOR_BUFFER_BIT|g.DEPTH_BUFFER_BIT);if(reversed){draw(.5,[1,0,0]);draw(-.5,[0,1,0]);}else{draw(-.5,[0,1,0]);draw(.5,[1,0,0]);}const px=new Uint8Array(4);g.readPixels(8,8,1,1,g.RGBA,g.UNSIGNED_BYTE,px);tests.push(Array.from(px));}
 const passed=tests.every(px=>px[0]===0&&px[1]===255&&px[2]===0);if(!passed)throw Error('Depth occlusion probe failed.');return{passed,near_triangle_visible_in_both_draw_orders:tests,depth_bits:g.getParameter(g.DEPTH_BITS)};};
function renderScene(s,width=VP.w,height=VP.h){RW=width;RH=height;canvas.width=RW;canvas.height=RH;const shown=meshes.filter(m=>visible(m,s)).map(m=>material(m,s));if(!shown.length)throw Error('Empty preview '+s.name);const cam=camera(shown,s),opaque=shown.filter(m=>m.opacity>=1),transparent=shown.filter(m=>m.opacity<1),light=renderShadow(opaque,s);
 gl.viewport(0,0,RW,RH);gl.clearColor(243/255,245/255,246/255,1);gl.clearDepth(1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.useProgram(program);gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LESS);gl.disable(gl.CULL_FACE);gl.disable(gl.BLEND);gl.depthMask(true);
 gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,shadowTexture);gl.uniform1i(loc.shadowMap,0);gl.uniformMatrix4fv(loc.lightVP,false,light.matrix);gl.uniform2f(loc.shadowTexel,1/shadowWidth,1/shadowHeight);gl.uniformMatrix4fv(loc.vp,false,cam.matrix);gl.uniform3fv(loc.viewDirection,cam.direction);gl.uniform3fv(loc.clipMin,s.clipMin);gl.uniform3fv(loc.clipMax,s.clipMax);for(const m of opaque)draw(m);const transparentTriangles=transparentPass(transparent,cam);
 const overlays=routeMeshes(s,cam);gl.depthMask(false);for(const m of overlays)draw(m,1);gl.depthMask(true);gl.finish();const error=gl.getError();if(error!==gl.NO_ERROR)throw Error('WebGL error '+error);
 const snapshot=document.createElement('canvas');snapshot.width=RW;snapshot.height=RH;snapshot.getContext('2d').drawImage(canvas,0,0);for(const m of overlays){gl.deleteBuffer(m.positionBuffer);gl.deleteBuffer(m.normalBuffer);}
 return{snapshot,cam,metadata:{name:s.name,width:RW,height:RH,visible_components:shown.length,visible_source_triangles:shown.reduce((v,m)=>v+m.count/3,0),opaque_components:opaque.length,transparent_components:transparent.length,triangle_sorted_transparent_triangles:transparentTriangles,source_component_ids:shown.map(m=>m.object.id),depth_test_enabled:gl.isEnabled(gl.DEPTH_TEST),depth_write_restored:gl.getParameter(gl.DEPTH_WRITEMASK),depth_bits:gl.getParameter(gl.DEPTH_BITS),antialias:gl.getContextAttributes().antialias,renderer:gl.getParameter(gl.RENDERER),version:gl.getParameter(gl.VERSION),gl_error:error,clip_min_mm:s.clipMin,clip_max_mm:s.clipMax,camera:{azimuth_deg:s.azimuth,elevation_deg:s.elevation,projection:'orthographic',view_plane_span_mm:[cam.spanX,cam.spanY],view_bounds:cam.viewBounds},capture:'Raw WebGL canvas drawn onto a captioned 2D canvas; no UI screenshot',geometry:'Exactly expanded source indices/vertices/normals; no simplification, remeshing or pose changes',omitted_component_ids:s.excludeIds||[],scopes:s.scopes||['module','host_reference'],opacity_overrides:s.opacityByGroup||{},lighting:'Three directional studio lights plus hemispheric ambient; exact source-triangle depth shadow, linear-color shading, material-dependent specular, tone mapping',shadow_pass:{source:'Same visible opaque CAD triangle buffers',resolution:[shadowWidth,shadowHeight],filter:'3x3 percentage-closer filtering',added_geometry:false},material_display:'Copper-colored functional winding cores and pins; grey host; source component colors otherwise retained. Appearance is illustrative, not a selected finish or alloy.',included_id_prefixes:s.includeIdPrefixes||null,geometric_annotations:s.exclusion?'Dashed proposed metal-exclusion/test envelope; not a measured field or validated clearance':null,routes:s.routes?'Depth-tested dashed routing-intent overlays, not CAD bodies':false}};}
window.renderStaticPreview=function(s){
 if(s.panels){const art=document.createElement('canvas');art.width=VP.w;art.height=VP.h;const c=art.getContext('2d');c.fillStyle='#f3f5f6';c.fillRect(0,0,VP.w,VP.h);const records=[];let first;
  for(const p of s.panels){const [x,y,w,h]=p.placement;const result=renderScene({...p,clipMin:p.clipMin||s.clipMin,clipMax:p.clipMax||s.clipMax},w,h);c.drawImage(result.snapshot,x,y);records.push({...result.metadata,label:p.label,placement_px:p.placement});if(!first)first=result;}
  const metadata={name:s.name,width:W,height:H,visible_components:records.reduce((n,r)=>n+r.visible_components,0),visible_source_triangles:records.reduce((n,r)=>n+r.visible_source_triangles,0),source_component_ids:[...new Set(records.flatMap(r=>r.source_component_ids))],depth_bits:gl.getParameter(gl.DEPTH_BITS),depth_test_enabled:true,depth_write_restored:true,gl_error:gl.getError(),multi_view_panels:records,capture:'Exact source mesh views assembled on a canvas; no UI screenshot',geometry:'No geometry changes; declared omissions and independent view scales',clean_canvas_size:[VP.w,VP.h]};
  return{png:compose(s,first.cam,metadata.visible_components,art),cleanPng:art.toDataURL('image/png').split(',')[1],metadata};}
 const primary=renderScene(s,s.detail?1580:VP.w,VP.h);let art=primary.snapshot;
 if(s.detail){const detail=renderScene({...s.detail,clipMin:s.detail.clipMin||s.clipMin,clipMax:s.detail.clipMax||s.clipMax},610,900);art=document.createElement('canvas');art.width=VP.w;art.height=VP.h;const c=art.getContext('2d');c.fillStyle='#f3f5f6';c.fillRect(0,0,VP.w,VP.h);c.drawImage(primary.snapshot,0,0);c.drawImage(detail.snapshot,1650,80);primary.metadata.detail_panel=detail.metadata;primary.metadata.detail_panel.placement_px=[1650,80,610,900];primary.metadata.detail_panel.caption='B RGB head detail; carrier, cover and lighting omitted.';}
 primary.metadata.width=W;primary.metadata.height=H;primary.metadata.clean_canvas_size=[VP.w,VP.h];
 return{png:compose(s,primary.cam,primary.metadata.visible_components,art),cleanPng:art.toDataURL('image/png').split(',')[1],metadata:primary.metadata};
};
window.previewReady=fetch('/mesh.json').then(r=>{if(!r.ok)throw Error('Mesh fetch failed');return r.json();}).then(data=>{assembly=data;if(data.units!=='mm')throw Error('Expected millimetre mesh');meshes=data.objects.map(mesh);return{objects:meshes.length,triangles:meshes.reduce((s,m)=>s+m.count/3,0)};});
})();
