# Revalis module figures M02

Four illustrations use only generated CAD triangle positions and normals. Orthographic cameras, material-dependent highlights and source-triangle shadows make the modeled hardware visible; there is no image-generated or invented mechanism geometry. Copper-colored winding paths and other finishes are illustrative appearances, not selected alloys, coatings or component specifications.

- `module_isolated.png`: A, complete module without the host; B, a larger RGB head detail from the same source. The detail omits the carrier, cover and lighting and uses a separate scale.
- `module_installed_host.png`: colored module on a grey host reference. The central 180 mm lane is mechanically constrained within a 600 mm belt; this does not establish useful sensing coverage.
- `module_sensing_arrangement.png`: A, under-belt cartridge with one Tx and two Rx; B, lane-facing transverse Tx head; C, lane-facing transverse head with two Rx. These are separate exact-CAD views at independent scales. Housings, formers, bobbin lips and keepers remain opaque. Covers and insulation are omitted, and host/installation supports are excluded from the closeups. Six functional paths contain three illustrative perimeter passes each, not an optimized electrical winding design.
- `module_maintenance_interfaces.png`: acquisition/control enclosure with its front omitted, showing internal device envelopes and cable-entry hardware. Electrical specification, harness and enclosure rating remain unresolved.

Captioned files are 2400 x 1440 pixels. Matching `_clean.png` files are 2260 x 1090 pixels and contain the same CAD canvas without titles, captions or arrows. Figures 1 and 3 retain their multiple CAD views in the clean composites; label the separate views/scales in the surrounding paper/deck. No paper figure has a default direction-arrow or axes overlay.

Suggested shared caption: "Proposed retrofit sensing hardware for a constrained test lane. Actual CAD geometry; declared covers omitted. Preliminary design, not fabrication certified or physically validated."

`review/` contains five additional PNG/SVG views: installed overall, installed top, longitudinal under-belt section at Y=0 mm, transverse section at X=334 mm, and cartridge withdrawal. The section planes intersect actual winding cores. Their source hashes, selections and exact section checks are recorded separately.

## Reproduce

From the package or extracted source ZIP root (the directory containing `engineering/`), run `node engineering/figures/render_figures.cjs` after the CAD source/export freeze. Generate the CAD exports first when rebuilding from the compact source ZIP. From the larger Revalis_Lab checkout, prefix that path with `revalis_module_package_20261016_v03/`. This starts an isolated headless Chrome process with a fresh temporary profile and loopback-only content; it does not operate user tabs or UI. Set `CHROME_PATH` to a local Chrome executable when it differs from the default macOS installation path. The runner refuses changed source/export hashes. Final outputs still require direct visual review.

Draft-only flags `--draft --source-root=<preserved engineering directory> --out-dir=<draft directory> --only=<figure filename>` allow styling checks without changing final figures. `--mesh-path=<CAD preview JSON>` is accepted only with `--draft` and a separate output directory; its output is never an export-sealed release. Never treat a draft as a released M02 image.
