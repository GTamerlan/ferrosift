"""Aggregate source-bound scoped checks. Refuses stale inputs; no physics claim."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,csv
ROOT=Path(__file__).resolve().parents[1];PKG=ROOT.parent

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text())
qa=ROOT/'verification';ind=PKG/'verification/independent_engineering'
paths={'cad_export':qa/'cad_export_validation.json','interfaces':qa/'interfaces_review.json','independent_source':ind/'SOURCE_SPATIAL_REVIEW.json','independent_exports':ind/'EXPORT_FILE_REVIEW.json','datum':ind/'DATUM_PARAMETER_REVIEW.json','winding_verdict':ind/'WINDING_REVIEW_VERDICT.json','winding_geometry':ind/'WINDING_GEOMETRY_REVIEW.json','hardware_verdict':ind/'HARDWARE_REVIEW_VERDICT.json','hardware_geometry':ind/'HARDWARE_GEOMETRY_REVIEW.json','independent_verdict':ind/'INDEPENDENT_REVIEW_VERDICT.json'}
reports={k:read(p) for k,p in paths.items()};checks=[]
for name in ('cad_export','interfaces','independent_source','winding_verdict','winding_geometry','hardware_verdict','hardware_geometry','independent_verdict'):
 for rel,sha in reports[name]['source_sha256'].items():
  if digest(ROOT/rel)!=sha:raise RuntimeError(f'Stale source in {name}: {rel}')
for verdict_name in ('winding_verdict','hardware_verdict','independent_verdict'):
 for name,evidence in reports[verdict_name]['evidence'].items():
  if digest(ind/name)!=(evidence if isinstance(evidence,str) else evidence['sha256']):raise RuntimeError('Stale '+verdict_name+' evidence: '+name)
checks.append({'check':'source_hashes_match_all_native_receipts','passed':True})
checks.append({'check':'independent_interpretation_and_evidence_bound','passed':reports['independent_verdict']['result']=='passed_nominal_research_geometry_only','retained_holds':reports['independent_verdict']['retained_holds']})
ce=reports['cad_export'];it=reports['interfaces'];sr=reports['independent_source'];ex=reports['independent_exports'];dr=reports['datum'];sp=sr['spatial_checks']
checks.append({'check':'source_and_STEP_roundtrips','passed':ce['status']=='passed' and ce['source_unchanged_during_build'],'roundtrips':ce['roundtrips']})
checks.append({'check':'targeted_source_interfaces','passed':it['status']=='passed' and all(v['passed'] for v in it['checks']),'executed_check_count':len(it['checks'])})
checks.append({'check':'independent_binary_geometry_and_scope','passed':ex['result']=='pass' and ex['web_sha256']==digest(ROOT/'web/module-assembly.json'),'details':ex['checks']})
for f in ex['files']:
 if digest(ROOT/f['path'])!=f['sha256']:raise RuntimeError('Stale export review: '+f['path'])
checks.append({'check':'datum_translation_executes_once','passed':dr['result']=='pass' and dr['source_sha256']==digest(ROOT/'cad/build_module.py'),'delta_mm':dr['all_part_bboxes_translate_exactly_mm'],'scope':dr['scope']})
checks.append({'check':'six_continuous_windings_and_separate_terminals','passed':reports['winding_verdict']['result']=='passed_nominal_winding_geometry_only','scope':'Open source paths, insulation spacing, former support, distinct terminal contacts and housing clearance only; electrical design and internal harness remain unresolved.'})
checks.append({'check':'detailed_hardware_interfaces','passed':reports['hardware_verdict']['result']=='passed_nominal_hardware_geometry_only','scope':'Real gland wall bores and bearing faces, socket recess depths, bobbin/keeper contacts, optic mounting and separated external cable paths only; inherited receiver and cable-installation holds remain explicit.'})
checks.append({'check':'six_source_coil_planes','passed':len(sp['coil_planes'])==6,'details':sp['coil_planes']})
checks.append({'check':'structural_metal_outside_selected_reservation','passed':not sp['unintended_metal_in_reservation'],'exceptions':'Intended coil conductors and leads are inside; actual host belt and return reinforcement/splices remain uncharacterized.'})
sweeps=[sp['under_cartridge_withdrawal'],*sp['other_removal_sweeps']]
checks.append({'check':'four_continuous_conservative_removal_sweeps','passed':len(sweeps)==4 and not any(v['potential_obstructions'] for v in sweeps),'details':sweeps})
checks.append({'check':'optical_central_rays','passed':not any(v['obstructions'] for v in sp['optical_central_rays']),'details':sp['optical_central_rays'],'scope':'Centre lines only; does not validate field of view, depth accuracy, lighting or optics.'})
checks.append({'check':'adjustment_hardware_to_cover_clearance','passed':not sp['adjustment_hardware_guard_collisions']})
# Preserve intentional engagement interpretations; do not hide real collisions.
for key,accepted in [('module_host_intersections',{'intended_coupling_engagement'}),('cable_structure_intersections',{'intended_device_endpoint'})]:
 value=sp[key]
 unexpected=[v for v in value if v.get('interpretation') not in accepted]
 checks.append({'check':key,'passed':not unexpected,'intentional_intersections':value,'unexpected_intersections':unexpected,'scope':'Device endpoint/coupling engagement only; Selected gland geometry is checked separately; internal wiring, connector selection and remaining fastening receivers remain unresolved.'})
pairs=sp['cable_pair_separation'];routes=sp['cable_path_continuity']
checks.append({'check':'six_external_routes_have_fifteen_separated_pairs','passed':len(pairs)==15 and all(v['intersection_mm3']<1e-5 and v['distance_mm']>0 for v in pairs),'minimum_exact_solid_gap_mm':min(v['distance_mm'] for v in pairs),'details':pairs,'scope':'Nominal external route solids only; clips/tray, bends, slack, strain relief and internal wiring remain unresolved.'})
checks.append({'check':'six_rounded_external_routes_are_continuous','passed':len(routes)==6 and all(v['valid'] and v['solid_count']==1 and not v['sampled_path_points_outside_cable'] and v['maximum_adjacent_endpoint_gap_mm']<1e-6 for v in routes),'details':routes,'scope':'Drawn route geometry only; minimum allowed bend radius and selected cable construction are unqualified.'})
manifest=read(ROOT/'exports/assembly_manifest.json')
with (ROOT/'bom/component_schedule.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['id','name','scope','group','quantity','optional','material_class','solid_volume_mm3','bbox_min_mm','bbox_max_mm','status'])
 for v in manifest['parts']:
  w.writerow([v['id'],v['name'],v['scope'],v['group'],1,v.get('optional',False),v['materialClass'],round(v['volume_mm3'],3),' '.join(str(round(x,3)) for x in v['bbox']['min']),' '.join(str(round(x,3)) for x in v['bbox']['max']),'Proposed geometric component; no supplier, price, mass, rating or fabrication specification'])
result={'revision':'M02','generated_utc':datetime.now(timezone.utc).isoformat(),'status':'passed_scoped_geometry' if all(v['passed'] for v in checks) else 'failed','scope':'Nominal CAD geometry, documented clearances and export integrity only; no fabrication, operation, safety or sensor performance approval.','components':ce['components'],'module_components':manifest['scope_counts']['module_assembly'],'host_reference_components':manifest['scope_counts']['host_reference'],'triangles':ce['triangle_count'],'source_sha256':ce['source_sha256'],'web_sha256':digest(ROOT/'web/module-assembly.json'),'module_STEP_sha256':digest(ROOT/'exports/module_assembly.step'),'nominal_dimensions_mm':sp['nominal_interface_dimensions_mm'],'checks':checks,'evidence_files':{k:{'path':str(p.relative_to(PKG)),'sha256':digest(p)} for k,p in paths.items()},'holds_file':{'path':'design_basis/design_holds.json','sha256':digest(ROOT/'design_basis/design_holds.json')},'physical_validation_performed':False,'electromagnetic_simulation_performed':False,'limitations':['No validated active sensing width, field response, component ratings, feed/operating limits, safe handling, recovery, purity or economic benefit.','Grey host is a partial reference, with bearings, drive, turnaround belt and guarding intentionally incomplete.','Calibration accessory is separate; rigid structural contact is not strength or manufacturability proof.','Only nominal adjustment pose, Z=1000 datum and 600 mm host interface checked; movement range, locking loads, tolerance and calibration repeatability remain open. The datum probe tests shapes only; coordinate metadata stays nominal.','Window/lane/cover/panel receivers and four lower-rail clamp passages remain simplified engagement geometry. No fully manufacturable fastening system is claimed.','Only overhead optical saddles are modeled; remaining cable tray/clips, bends, strain relief, disconnection, sensor-end encoder seal and internal harness remain unresolved.']}
(qa/'geometry_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'checks':len(checks),'components':result['components'],'triangles':result['triangles']}))
if result['status']!='passed_scoped_geometry':raise SystemExit(1)
