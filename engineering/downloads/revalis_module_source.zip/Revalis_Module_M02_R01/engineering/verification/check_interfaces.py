"""Targeted M02 source-solid geometry checks; no physics/safety certification."""
import json,sys,hashlib
from datetime import datetime,timezone
from pathlib import Path
import cadquery as cq
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'cad'))
from build_module import build,box,digest
from export_common import bbox
p=json.loads((ROOT/'design_basis/parameters.json').read_text());parts=build(p);by={v['id']:v for v in parts};checks=[]
def check(name,passed,**detail):
 checks.append({'check':name,'passed':bool(passed),**detail});print(name,passed,flush=True)
def contact(a,b):
 s=by[a]['shape'];t=by[b]['shape'];return {'distance_mm':s.distance(t),'common_volume_mm3':s.intersect(t).Volume()}
# Intentionally conservative bounding-box sweep includes spaces between moving parts.
move=[v for v in parts if v.get('service_group')=='under_cartridge']
removed={'cable_under_lead','under_cover_retainer_-100','under_cover_retainer_100'}
bs=[bbox(v['shape']) for v in move];mn=np.min([v['min'] for v in bs],axis=0);mx=np.max([v['max'] for v in bs],axis=0);mn[1]-=850
sweep=box(*(mx-mn),*((mx+mn)/2));clashes=[]
for v in parts:
 if v in move or v['id'] in removed:continue
 vol=sweep.intersect(v['shape']).Volume()
 if vol>1e-4:clashes.append({'id':v['id'],'intersection_mm3':vol})
check('under_cartridge_continuous_conservative_withdrawal',not clashes,bbox_mm={'min':mn.tolist(),'max':mx.tolist()},travel_mm=[0,-850,0],excluded_removed_or_disconnected=sorted(removed),moving_ids=[v['id'] for v in move],clashes=clashes,scope='Exact source intersection against conservative swept solid after stated removals; does not establish handling/operator access or loaded/tolerance clearance')
# Source clearance values, not inferred from a decorative arrow.
mechanical_gap=by['module_support_window']['shape'].BoundingBox().zmin-max(bbox(v['shape'])['max'][2] for v in move)
core_gap=1000-max(bbox(v['shape'])['max'][2] for v in parts if v.get('coil',{}).get('plane')=='XY')
check('cartridge_closed_to_support_gap',abs(mechanical_gap-10)<1e-5 and abs(core_gap-30.85)<1e-5,mechanical_gap_mm=mechanical_gap,coil_core_top_to_belt_top_mm=core_gap,belt_thickness_mm=4,support_thickness_mm=6)
# A mechanical passage witness, not an accepted object envelope. Inlet mask and skirts must close both outer lanes.
passage=box(930,180,60,35,0,1030);blocking=[]
for v in parts:
 if v['group'] in ('lane','transverse') and not v.get('calibration_accessory'):
  q=passage.intersect(v['shape']).Volume()
  if q>1e-4:blocking.append({'id':v['id'],'volume_mm3':q})
check('central_180_by_60_packaging_witness_clear',not blocking,clashes=blocking,scope='60mm height witness only; not feed acceptance, usable sensor aperture, overheight handling or safety certification')
for sy in (-1,1):
 mask=by[f'inlet_outer_lane_mask_{sy}']['shape'].fuse(by[f'inlet_mask_skirt_{sy}']['shape']);witness=box(6,210,60,-500,sy*195,1030)
 ratio=mask.intersect(witness).Volume()/witness.Volume()
 check(f'upstream_outer_lane_mask_{sy}',abs(ratio-1)<1e-6,blocked_fraction=ratio,status='Host must prevent off-lane feed before stationary masks; collision, jam, wear and safety remain holds')
# Exclusion reservation: nearby metal must stay outside; intended sensing conductors/leads are explicit exceptions.
e=p['exclusion_test_envelope'];lo=np.array(e['min']);hi=np.array(e['max']);env=box(*(hi-lo),*((lo+hi)/2));metal_inside=[];intended=[];unknown=[]
for v in parts:
 q=env.intersect(v['shape']).Volume()
 if q<=1e-5:continue
 if v['materialClass']=='metal':metal_inside.append({'id':v['id'],'common_mm3':q})
 elif v['materialClass'] in ('coil_conductor','coil_terminal','cable'):intended.append(v['id'])
 elif v['materialClass']=='host_belt_unknown':unknown.append(v['id'])
check('declared_metal_outside_illustrative_exclusion',not metal_inside,metal_clashes=metal_inside,intended_conductors_and_leads_inside=intended,unknown_host_material_inside=unknown,status='Final exclusion extent and belt reinforcement/splice/return-run/EMC interaction experimentally unresolved')
for plane in ('XY','XZ'):
 coils=[v for v in parts if v.get('coil',{}).get('plane')==plane]
 axis=2 if plane=='XY' else 1;dimensions=[np.array(bbox(v['shape'])['max'])-bbox(v['shape'])['min'] for v in coils]
 main_plane_ok=all(max(q[axis] for q in v['winding']['path_control_points_mm'][:-4])-min(q[axis] for q in v['winding']['path_control_points_mm'][:-4])<1e-6 for v in coils)
 check('coil_plane_'+plane,len(coils)==3 and main_plane_ok and all(abs(d[axis]-3.9)<1e-5 for d in dimensions),coil_ids=[v['id'] for v in coils],thickness_mm=[float(d[axis]) for d in dimensions],roles=[v['coil']['role'] for v in coils],status='Main perimeter paths lie in the declared plane; recessed returns are deliberately out of plane. No field or balanced response validation')
# Meaningful physical contact checks, allowing selected assembly engagement.
contacts=[]
for x in (-620,620):
 for sy in (-1,1):
  for a,b in [(f'mount_plate_{x}_{sy}',f'mount_spacer_{x}_{sy}'),(f'mount_spacer_{x}_{sy}',f'host_side_rail_{sy}'),(f'mount_backing_{x}_{sy}',f'host_side_rail_{sy}'),(f'portal_column_{x}_{sy}',f'mount_plate_{x}_{sy}')]:contacts.append({'pair':[a,b],**contact(a,b)})
for sy in (-1,1):
 for a,b in [(f'side_support_post_{sy}',f'lower_side_rail_{sy}'),(f'side_support_post_{sy}',f'side_outer_bracket_{sy}'),(f'side_arm_{sy}',f'side_head_hanger_{sy}'),(f'side_head_hanger_{sy}',f'side_cartridge_{sy}')]:contacts.append({'pair':[a,b],**contact(a,b)})
for x in (-135,135):
 for sy in (-1,1):
  for a,b in [(f'under_slide_rail_{x}',f'under_height_shim_{x}_{sy}_1'),(f'under_height_shim_{x}_{sy}_1',f'under_height_shim_{x}_{sy}_0'),(f'under_height_shim_{x}_{sy}_0',f'lower_side_rail_{sy}')]:contacts.append({'pair':[a,b],**contact(a,b)})
for a,b in [('optional_3d_mount','optional_3d_body'),('optional_3d_mount','optical_slotted_carrier'),('rgb_body','optical_slotted_carrier'),('control_carrier_1360','portal_column_620_-1'),('control_mounting_ear_680','control_carrier_1360'),('control_enclosure_shell','control_mounting_ear_680')]:contacts.append({'pair':[a,b],**contact(a,b)})
check('selected_mounts_have_geometric_contact',all(v['distance_mm']<1e-5 for v in contacts),pairs=contacts,scope='Contact or selected engagement only; fastener/structure strength and tolerance review remain open')
# Positive-area support-window bearing and return clearance.
window=by['module_support_window']['shape']
for x in (-235,495):
 bridge=by[f'window_support_bridge_{x}']['shape'];probe=bridge.translate((0,0,0.1));overlap=window.intersect(probe).Volume()
 check(f'support_window_bearing_{x}',overlap>100,common_volume_after_0_1mm_probe=overlap,status='Small upward contact probe establishes finite contact area, not allowable load/deflection')
return_gap=min(bbox(v['shape'])['min'][2] for v in move)-bbox(by['host_return_belt']['shape'])['max'][2]
check('return_belt_to_cartridge_clearance',return_gap>0,nominal_gap_mm=return_gap,status='Actual sag, tension, loaded motion and metallic return effects unresolved')
# Nonmetallic calibration target path, carried upstream-to-downstream through lane at nominal 10mm height.
cal=box(930,140,10,35,0,1005);cl=[]
for v in parts:
 if v['group'] not in ('lane','transverse','optical') or v.get('calibration_accessory'):continue
 if cal.intersect(v['shape']).Volume()>1e-4:cl.append(v['id'])
check('calibration_coupon_geometric_path',not cl,clashes=cl,witness_size_mm=[140,10],scope='Nonmetallic carrier witness in central lane; coupon standards, optical/EM calibration and safe insertion procedure unselected')
report={'status':'passed' if all(v['passed'] for v in checks) else 'failed','generated_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':{str(f.relative_to(ROOT)):digest(f) for f in (ROOT/'cad').glob('*.py')},'checks':checks,'limitations':['No physical testing, electromagnetic simulation, accepted fragment sizes, operating speed, recovery, purity, economic benefit, guarding or certification is established.','Illustrative construction details need material/hardware/loads/tolerances/EMC/thermal review.','Selected contacts can include intended overlap at modeled brackets; this is not exhaustive whole-assembly interference proof.']}
(ROOT/'verification/interfaces_review.json').write_text(json.dumps(report,indent=2)+'\n')
if report['status']!='passed':sys.exit(1)
