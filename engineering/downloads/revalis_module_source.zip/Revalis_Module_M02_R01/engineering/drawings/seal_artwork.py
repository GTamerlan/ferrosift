#!/usr/bin/env python3
"""Bind reviewed M02 artwork to a frozen source. Does not perform visual review."""
from pathlib import Path
import argparse, hashlib, json, shutil
from datetime import datetime, timezone
from PIL import Image
import fitz

ROOT=Path(__file__).resolve().parents[1]
PACKAGE=ROOT.parent
D=ROOT/'drawings';F=ROOT/'figures';V=F/'review'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def save(p,j):p.write_text(json.dumps(j,indent=2)+'\n')
def record(p):return {'path':str(p.relative_to(PACKAGE)),'bytes':p.stat().st_size,'sha256':sha(p)}

p=argparse.ArgumentParser()
p.add_argument('--context-sha',required=True)
p.add_argument('--independent-visual-receipt',required=True,type=Path)
p.add_argument('--visual-reviewed',action='store_true',required=True)
a=p.parse_args()
context=sha(ROOT/'exports/module_with_host.step');assert context==a.context_sha
module=sha(ROOT/'exports/module_assembly.step');mesh=sha(ROOT/'web/module-assembly.json')
assembly=load(ROOT/'exports/assembly_manifest.json')
for source,h in assembly['source_sha256'].items():assert sha(ROOT/source)==h,source
for name in ['module_with_host.step','module_assembly.step']:
 assert sha(ROOT/'exports'/name)==assembly['exports'][name]['sha256']
d=load(D/'drawing_manifest.json');f=load(F/'figure_manifest.json');q=load(D/'drawing_layout_qa.json');v=load(V/'review_views_manifest.json')
assert d['revision']=='M02' and d['source_step_sha256']==context
assert d['source_manifest_sha256']==sha(ROOT/'exports/assembly_manifest.json')
assert d['source_contract_sha256']==sha(ROOT/'design_basis/geometry_contract.json')
assert q['status']=='PASS' and q['pdf_sha256']==d['pdf_sha256']==sha(D/'module_drawings.pdf')
assert len(fitz.open(D/'module_drawings.pdf'))==d['page_count']==6
assert len(d['sheets'])==6
for s in d['sheets']:assert sha(D/s['path'])==s['sha256']
assert f['status']=='PASS' and not f.get('draft')
assert f['step_sha256']==context and f['geometry_sha256']==mesh
assert f['assembly_manifest_sha256']==sha(ROOT/'exports/assembly_manifest.json')
assert f['depth_occlusion_probe']['passed'] and not f['runtime_exceptions'] and not f['external_network_requests']
assert len(f['previews'])==4
for x in f['previews']:
 assert sha(F/x['name'])==x['sha256'] and Image.open(F/x['name']).size==(2400,1440)
 c=x['clean_image'];assert sha(F/c['path'])==c['sha256'] and Image.open(F/c['path']).size==(2260,1090)
assert v['revision']=='M02' and v['context_step_sha256']==context and v['web_mesh_sha256']==mesh
assert len(v['views'])==5
for x in v['views']:
 for ext in ['svg','png']:assert sha(V/(x['name']+'.'+ext))==x[ext+'_sha256']
assert all(x['status']=='PASS' for x in v['section_conductor_intersection_checks'])
i=load(a.independent_visual_receipt)
assert i['revision']=='M02' and i['result'].startswith('pass') and i['context_step_sha256']==context
for source,h in i['source_sha256'].items():assert sha(ROOT/source)==h
assert i['web_mesh_sha256']==mesh and i['drawing_pdf_sha256_at_sample']==sha(D/'module_drawings.pdf')
assert i['remaining_visual_blockers']==[]
for sample in i['reviewed_images']:
 assert sample['result']=='PASS' and sha(ROOT/sample['path'])==sample['sha256'],sample['path']
now=datetime.now(timezone.utc).isoformat()
d['status']='PASS';d['checks']['visual_review']='PASS'
d['visual_review']={'status':'PASS','reviewed_utc':now,'method':'Direct inspection of all six M02 page PNGs','result':'Legible actual-CAD views and dimensional annotations; no clipping or overlapping labels observed.','scope':'Visual layout/source correspondence only.'}
d['source_module_step_sha256']=module;d['source_web_mesh_sha256']=mesh
d['authoring_source_sha256']={x.name:sha(x) for x in sorted(D.glob('*.py'))}
d['view_definitions_sha256']=sha(D/'view_definitions.json')
f['visual_review']={'status':'PASS','reviewed_utc':now,'method':'Direct inspection of all four final captioned CAD figures and their matching clean canvases','result':'Hardware, copper winding paths and declared cutaways are clear; host contrast and captions are legible.','scope':'Illustrative appearance, not selected material/finish or physical validation.'}
f['figure_specs_sha256']=sha(F/'figure_specs.json');f['source_module_step_sha256']=module
v['status']='PASS';v['visual_review']={'status':'PASS','reviewed_utc':now,'method':'Direct inspection of all five final M02 review PNGs','result':'Source-derived overall, top, conductor sections and service view are legible with omissions and poses declared.','scope':'Geometry/layout review only.'}
independent=record(a.independent_visual_receipt.resolve())
v['independent_visual_sample']=independent
save(D/'drawing_manifest.json',d);save(F/'figure_manifest.json',f);save(V/'review_views_manifest.json',v)
shutil.copyfile(F/'module_isolated.png',D/'module_isometric.png')
outputs=[D/'module_drawings.pdf',D/'module_isometric.png']+[D/x['path'] for x in d['sheets']]
for x in f['previews']:outputs.extend([F/x['name'],F/x['clean_image']['path']])
for x in v['views']:outputs.extend([V/(x['name']+'.png'),V/(x['name']+'.svg')])
receipt={'revision':'M02','status':'COMPLETE_NOT_PUBLISHED','sealed_utc':now,'source_part_count':assembly['part_count'],'source_triangles':f['source_stats']['triangles'],'context_step_sha256':context,'module_step_sha256':module,'mesh_sha256':mesh,'pdf_pages':6,'editable_svg_sheets':6,'captioned_figures':4,'clean_figures':4,'standalone_review_views':5,'pdf_bytes':(D/'module_drawings.pdf').stat().st_size,'checks':{'current_frozen_source':'PASS','six_A3_pages_and_text_containment':'PASS','all_pages_figures_review_views_visual_review':'PASS','actual_conductor_section_intersections':'PASS','depth_buffer_and_local_render_isolation':'PASS','independent_visual_sample':'PASS'},'independent_visual_sample':independent,'manifests':[record(D/'drawing_manifest.json'),record(F/'figure_manifest.json'),record(V/'review_views_manifest.json'),record(D/'drawing_layout_qa.json')],'outputs':[record(x) for x in outputs],'supporting_files':[record(D/'README.md'),record(F/'README.md')],'physical_validation_performed':False,'publication_performed':False,'remaining_holds':['Preliminary geometry; not fabrication certified.','Useful sensing coverage, electrical harness, component selection, tolerances, loads, host compatibility and safe service remain unvalidated.']}
save(D/'artwork_release_receipt.json',receipt)
(PACKAGE/'verification/artwork').mkdir(parents=True,exist_ok=True)
save(PACKAGE/'verification/artwork/ARTWORK_RELEASE_RECEIPT.json',receipt)
print(json.dumps({'status':receipt['status'],'outputs':len(outputs),'pdf_bytes':receipt['pdf_bytes'],'receipt_sha256':sha(D/'artwork_release_receipt.json')},indent=2))
