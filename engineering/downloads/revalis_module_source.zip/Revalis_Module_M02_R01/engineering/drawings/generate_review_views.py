#!/usr/bin/env python3
"""Five clearly labelled review views from exact current CAD; no physical validation."""
import base64, hashlib, html, json, math
from datetime import datetime, timezone
from pathlib import Path
import fitz
ROOT=Path(__file__).resolve().parents[1]
D=ROOT/'drawings';F=ROOT/'figures';OUT=F/'review';OUT.mkdir(exist_ok=True)
W,H=1200,720;INK='#17282d';TEAL='#087f80';MUTED='#52686f';AMBER='#a35b12'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def esc(t):return html.escape(str(t))
M=load(ROOT/'exports/assembly_manifest.json');context=sha(ROOT/'exports/module_with_host.step');mesh=sha(ROOT/'web/module-assembly.json')
for p,h in M['source_sha256'].items():assert sha(ROOT/p)==h,p
assert M['exports']['module_with_host.step']['sha256']==context
for definition in load(D/'review_view_definitions.json')+load(D/'view_definitions.json'):
 record=load(D/'projections'/f"{definition['name']}.json")
 expected=hashlib.sha256(b''.join((ROOT/s).read_bytes() for s in definition['sources'])+json.dumps(definition,sort_keys=True).encode()+(D/'project_views.py').read_bytes()).hexdigest()
 assert record['input_sha256']==expected,definition['name']
records=[]
class Review:
 def __init__(self,num,title,subtitle):
  self.num=num;self.a=[f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1200" height="720" viewBox="0 0 1200 720">', '<rect width="1200" height="720" fill="#fff"/>']
  self.text(40,31,f'REVALIS / M02 REVIEW VIEW {num:02d}',13,TEAL,True)
  self.text(40,67,title,29,INK,True);self.text(40,93,subtitle,13,MUTED)
  self.text(1160,31,'PRELIMINARY / NOT FOR FABRICATION',12,AMBER,True,'end')
  self.a.append('<path d="M40 111H1160 M40 645H1160" stroke="#087f80" stroke-width="1.5"/>')
  self.inputs=[];self.definition=None
 def text(self,x,y,t,size=14,color=INK,bold=False,anchor='start'):
  self.a.append(f'<text x="{x}" y="{y}" font-size="{size}" font-family="Arial,Helvetica,sans-serif" fill="{color}" font-weight="{700 if bold else 400}" text-anchor="{anchor}">{esc(t)}</text>')
 def line(self,x1,y1,x2,y2,color=TEAL,width=1):self.a.append(f'<path d="M{x1} {y1}L{x2} {y2}" fill="none" stroke="{color}" stroke-width="{width}"/>')
 def dim(self,p1,p2,label,offset=-22):
  x1,y1=p1;x2,y2=p2;y=min(y1,y2)+offset
  self.line(x1,y1,x1,y);self.line(x2,y2,x2,y);self.line(x1,y,x2,y)
  self.line(x1-3,y-3,x1+3,y+3);self.line(x2-3,y-3,x2+3,y+3)
  self.text((x1+x2)/2,y-7,label,13,TEAL,True,'middle')
 def projection(self,name,box):
  d=load(D/'projections'/f'{name}.json');l,b,r,t=d['bounds'];x,y,w,h=box;s=min(w/(r-l),h/(t-b));ox=x+(w-(r-l)*s)/2-l*s;oy=y+(h-(t-b)*s)/2+t*s
  self.a.append(f'<g transform="translate({ox},{oy}) scale({s},{-s})" fill="none" stroke="{INK}" stroke-width="{1.2/s}" stroke-linejoin="round">')
  for tri in d.get('fill_triangles',[]):self.a.append('<polygon points="'+' '.join(f'{px},{py}' for px,py in tri)+'" fill="#d8eceb" stroke="none"/>')
  self.a.extend(f'<path d="{p}"/>' for p in d['paths']);self.a.append('</g>')
  self.inputs.append({'name':name,'projection_input_sha256':d['input_sha256'],'method':d['method'],'section':d.get('section'),'crop_bbox_mm':d.get('crop_bbox_mm'),'sources':{p:sha(ROOT/p) for p in d['sources']}})
  normal=d['normal'];vx=d['x_direction'];ny=[normal[1]*vx[2]-normal[2]*vx[1],normal[2]*vx[0]-normal[0]*vx[2],normal[0]*vx[1]-normal[1]*vx[0]]
  def mapping(p):return (ox+s*sum(a*b for a,b in zip(p,vx)),oy-s*sum(a*b for a,b in zip(p,ny)))
  return mapping
 def note(self,lines):
  for i,t in enumerate(lines):self.text(40,592+i*20,t,13,MUTED)
 def finish(self,name,notes):
  self.text(40,668,'Dimensions in mm. Geometry/interface research review only; no load, safety, field or performance validation.',12,MUTED)
  self.text(40,691,f'Context STEP SHA-256 {context[:24]}  |  Exact revision bound in review_views_manifest.json',11,MUTED)
  self.text(1160,691,'16 OCT 2026 / M02 / BRAND R01',11,MUTED,False,'end');self.a.append('</svg>')
  svg=OUT/f'{name}.svg';svg.write_text('\n'.join(self.a))
  doc=fitz.open(stream=svg.read_bytes(),filetype='svg');pdf=fitz.open('pdf',doc.convert_to_pdf());page=pdf[0]
  for block in page.get_text('dict')['blocks']:
   for line in block.get('lines',[]):
    for span in line['spans']:
     x0,y0,x1,y1=span['bbox'];assert x0>=25 and x1<=1175 and y0>=12 and y1<=710,(name,span)
  page.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False).save(OUT/f'{name}.png')
  records.append({'name':name,'svg_sha256':sha(svg),'png_sha256':sha(OUT/f'{name}.png'),'size_px':[2400,1440],'inputs':self.inputs,'notes':notes})
# Overall preserves the source mesh render without altered pose or geometry.
fm=load(F/'figure_manifest.json');assert fm['step_sha256']==context and fm['geometry_sha256']==mesh
p=Review(1,'Installed module / grey host reference','Actual CAD mesh; colored module and grey host. Central 180 mm lane within a 600 mm host belt.')
img=F/'module_installed_host_clean.png'
image_record=next(v for v in fm['previews'] if v['name']=='module_installed_host.png')['clean_image'];assert sha(img)==image_record['sha256']
p.a.append(f'<image x="85" y="120" width="1030" height="450" preserveAspectRatio="xMidYMid meet" xlink:href="data:image/png;base64,{base64.b64encode(img.read_bytes()).decode()}"/>')
p.inputs=[{'mesh_sha256':mesh,'image_sha256':sha(img),'source_figure':'module_installed_host_clean.png'}]
p.note(['Host interface context includes carrying/return runs and supporting frame. Module includes research heads, optics and controls.', 'Opaque installed view. Internal unselected device envelopes are hidden; no field or useful sensing coverage is implied.'])
p.finish('review_01_installed_overall','No cut; exact source mesh view with host/module material contrast.')
p=Review(2,'Installed top view','Viewed from +Z. Exact visible-edge projection of the complete context STEP; hidden geometry is not drawn.')
top=p.projection('review_installed_top',(50,135,1100,425))
p.note(['The central passage is 180 mm wide. Upstream outer-lane masks and pod guards are included in the modeled installation.', 'No full-width sensing claim. Belt direction +X; camera, under-belt and transverse stations are longitudinally separated.'])
p.finish('review_02_installed_top','Full installed STEP visible-edge projection; no artificial cut or component offsets.')
p=Review(3,'Under-belt / support / return-run section','Longitudinal section at Y=0 mm. Exact solid intersections through the Tx and both Rx side segments.')
a=p.projection('review_stack_section_side',(70,155,1060,350))
p.note(['Belt-top gaps: Rx core 30.85, insulation 30.6, terminals 30.2. Carry/support 4/6; head-support 10; return-shell 64.', 'Section only: X -350 to +550, Z 830 to 1060. Off-plane side guides, host rails, optics and mounting parts are omitted.'])
p.finish('review_03_under_belt_section','Plane Y=0 mm intersects actual conductor segments. Tint denotes cut solid material, not a field or material rating.')
p=Review(4,'Transverse heads / contained lane section','Transverse section at X=334 mm through an Rx path and the opposed Tx. Exact solid intersections.')
a=p.projection('review_transverse_section',(60,150,1080,390))
p.dim(a((334,-90,1003)),a((334,90,1003)),'180 passage',-50)
p.note(['Inner guide faces Y +/-90; skirts meet the nominal Z=1000 carrying surface. Transverse conductor planes are XZ.', 'Section only: Y +/-450, Z 830 to 1205. Other longitudinal stations and off-plane hardware are omitted.'])
p.finish('review_04_transverse_section','Plane X=334 mm crosses upper/lower actual transverse Tx/Rx conductor segments; cut tint is not field strength.')
p=Review(5,'Cartridge withdrawal / service review','End view from +X. Installed under-belt assembly plus the same cartridge translated 850 mm toward -Y.')
a=p.projection('cartridge_service_end',(55,155,1090,320))
p.note(['Only the cartridge selection is offset; fixed rails, supports and host remain at their source positions. View cropped in X/Z.', 'Host must be isolated and the area cleared. Cable disconnection, handling loads and safe access remain unresolved.'])
p.finish('review_05_cartridge_service','Exact source cartridge translated [0,-850,0] mm; this review pose does not establish a safe removal procedure.')
assert sha(ROOT/'exports/module_with_host.step')==context and sha(ROOT/'web/module-assembly.json')==mesh
report={'revision':'M02','status':'GEOMETRY_AND_TEXT_CHECKS_PASS_VISUAL_REVIEW_PENDING','created_utc':datetime.now(timezone.utc).isoformat(),'context_step_sha256':context,'module_step_sha256':sha(ROOT/'exports/module_assembly.step'),'web_mesh_sha256':mesh,'assembly_manifest_sha256':sha(ROOT/'exports/assembly_manifest.json'),'source_sha256':M['source_sha256'],'review_definition_sha256':sha(D/'review_view_definitions.json'),'generator_sha256':sha(Path(__file__)),'render_backend':'OpenCascade exact HLR/solid plane sections, PyMuPDF SVG raster; source WebGL mesh image for overall','views':records,'physical_validation_performed':False,'visual_review':'PENDING'}
(OUT/'review_views_manifest.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'review_views':len(records),'directory':str(OUT),'context_step_sha256':context},indent=2))
