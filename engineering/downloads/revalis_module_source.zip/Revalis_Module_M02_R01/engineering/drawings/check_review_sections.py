#!/usr/bin/env python3
"""Check that declared review planes cut the actual exported functional conductors."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json
import cadquery as cq
ROOT=Path(__file__).resolve().parents[1]
M=json.loads((ROOT/'exports/assembly_manifest.json').read_text())
PARTS={p['id']:p for p in M['parts']}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for p,h in M['source_sha256'].items():assert sha(ROOT/p)==h,p
checks=[]
for selection,axis,value,expected in [('under_windings',1,0,['under_tx_xy','under_rx_xy_-42','under_rx_xy_42']),('transverse_windings',0,334,['side_tx_xz','side_rx_xz_334'])]:
 source=ROOT/f'exports/selections/{selection}.step'
 solids=cq.importers.importStep(str(source)).val().Solids()
 normal=tuple(int(i==axis) for i in range(3));origin=tuple(value*int(i==axis) for i in range(3))
 plane=cq.Face.makePlane(basePnt=origin,dir=normal);rows=[]
 candidates=[p for p in PARTS.values() if p.get('coil') and p['id'] in ('under_tx_xy','under_rx_xy_-42','under_rx_xy_42','side_tx_xz','side_rx_xz_266','side_rx_xz_334')]
 matched=[]
 for solid in solids:
  b=solid.BoundingBox();lo=[b.xmin,b.ymin,b.zmin];hi=[b.xmax,b.ymax,b.zmax]
  matching=[p for p in candidates if max(abs(p['bbox']['min'][i]-lo[i])+abs(p['bbox']['max'][i]-hi[i]) for i in range(3))<1e-5]
  if not matching:continue
  assert len(matching)==1,matching
  ident=matching[0]['id'];matched.append(ident)
  faces=solid.intersect(plane).Faces();area=sum(f.Area() for f in faces)
  if area>1e-6:rows.append({'component_id':ident,'cut_face_count':len(faces),'cut_area_mm2':area})
 assert len(matched)==3,(selection,'expected three exported functional winding cores',matched)
 assert set(expected)=={x['component_id'] for x in rows},rows
 checks.append({'selection':selection,'selection_step_sha256':sha(source),'section_axis':'XYZ'[axis],'section_value_mm':value,'status':'PASS','intersected_conductors':rows})
p=ROOT/'figures/review/review_views_manifest.json';m=json.loads(p.read_text())
assert m['context_step_sha256']==sha(ROOT/'exports/module_with_host.step')
m['section_conductor_intersection_checks']=checks;m['section_checks_utc']=datetime.now(timezone.utc).isoformat()
p.write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({'status':'PASS','checks':checks,'scope':'Actual conductor-solid section intersections only; no field, sensitivity or physical validation.'},indent=2))
