"""Proposed M01-W1 winding packaging. No electrical or thermal qualification.

Each winding is one open conductor path with three rectangular passes, a return
recessed into a nonmetallic former, and two separate accessible terminals.
"""
import math
import cadquery as cq

N_VISUAL = 3
PITCH = 3.8
CORE_RADIUS = 0.45
INSULATION_RADIUS = 0.7
MAIN_NORMAL = 0.7
RETURN_NORMAL = -2.3

def path_wire(points, radius=1.2):
    """Fillet a spatial polyline with explicit tangent circular arcs."""
    pts = [cq.Vector(*p) for p in points]
    edges = []
    previous = pts[0]
    for a,b,c in zip(pts,pts[1:],pts[2:]):
        incoming = (b-a).normalized()
        outgoing = (c-b).normalized()
        angle = math.acos(max(-1,min(1,incoming.dot(outgoing))))
        if angle < 1e-8:
            continue
        tangent = min(radius*math.tan(angle/2), (b-a).Length*.4, (c-b).Length*.4)
        actual_r = tangent/math.tan(angle/2)
        start = b-incoming*tangent
        end = b+outgoing*tangent
        centre = b+(-incoming+outgoing).normalized()*(actual_r/math.sin((math.pi-angle)/2))
        midpoint = centre+((start-centre).normalized()+(end-centre).normalized()).normalized()*actual_r
        if (start-previous).Length > 1e-8: edges.append(cq.Edge.makeLine(previous,start))
        edges.append(cq.Edge.makeThreePointArc(start,midpoint,end))
        previous = end
    edges.append(cq.Edge.makeLine(previous,pts[-1]))
    return cq.Wire.assembleEdges(edges)

def sweep(wire, radius):
    start = wire.startPoint()
    normal = wire.Edges()[0].tangentAt(0)
    profile = cq.Wire.assembleEdges([cq.Edge.makeCircle(radius,start,normal)])
    return cq.Solid.sweep(profile, [], wire, True, False, transitionMode='round')

def winding(width,height):
    """Local u/v plane, former face normal=0, outward normal=+Z."""
    hw,hh=(width-2*INSULATION_RADIUS)/2,(height-2*INSULATION_RADIUS)/2
    start = (hw,-hh-3,MAIN_NORMAL)
    points=[start,(hw,-hh,MAIN_NORMAL)]
    for i in range(N_VISUAL):
        points += [(-hw+i*PITCH,-hh+i*PITCH,MAIN_NORMAL),
                   (-hw+i*PITCH,hh-i*PITCH,MAIN_NORMAL),
                   (hw-i*PITCH,hh-i*PITCH,MAIN_NORMAL),
                   (hw-i*PITCH,-hh+(i+1)*PITCH,MAIN_NORMAL)]
    inner=points[-1]
    # Descent is inside the innermost pass; the return crosses beneath all turns.
    return_u=inner[0]-3
    points += [(return_u,inner[1],MAIN_NORMAL),
               (return_u,inner[1],RETURN_NORMAL),
               (return_u,-hh-3,RETURN_NORMAL),
               (return_u,-hh-3,MAIN_NORMAL)]
    wire=path_wire(points)
    core=sweep(wire,CORE_RADIUS)
    envelope=sweep(wire,INSULATION_RADIUS)
    insulation=envelope.cut(core)
    # The return channel is open for assembly and inspection; insulation is
    # supported by a matching nominal channel floor. No fit tolerance asserted.
    channel_path=path_wire(points[-5:])
    channel=sweep(channel_path,INSULATION_RADIUS)
    # Two separate contact posts overlap their intended open conductor ends.
    terminals=[];bases=[];pins=[];pockets=[]
    for u,v,n in (points[0],points[-1]):
        pin=cq.Solid.makeCylinder(.8,2.2,cq.Vector(u,v,-.4),cq.Vector(0,0,1))
        insulation=insulation.cut(pin)
        pocket=cq.Workplane('XY').box(5,5,2).translate((u,v,-1)).val()
        base=pocket.cut(pin).cut(envelope)
        terminals.append({'centre':[u,v,MAIN_NORMAL],'pin_radius_mm':.8,'pin_normal_range_mm':[-.4,1.8]})
        bases.append(base)
        pins.append(pin);pockets.append(pocket)
    # An open top slot exposes the recessed return for assembly and inspection.
    # The circular groove matches the nominal insulation OD; fit/retention and
    # production tolerance remain unselected rather than implied by this contact.
    low_y=-hh-3
    high_y=inner[1]
    opening=cq.Workplane('XY').box(1.4,high_y-low_y+1.4,2.4).translate((return_u,(low_y+high_y)/2,-1.1)).val()
    channel=channel.fuse(opening)
    return {'conductor':core,'insulation':insulation,'channel':channel,'terminal_bases':bases,
            'terminal_pins':pins,'terminal_pockets':pockets,
            'path':wire,'points':points,'terminals':terminals,
            'spec':{'visual_rectangular_passes':N_VISUAL,'pitch_mm':PITCH,
                    'conductor_diameter_mm':2*CORE_RADIUS,'insulation_od_mm':2*INSULATION_RADIUS,
                    'main_normal_mm':MAIN_NORMAL,'recessed_return_normal_mm':RETURN_NORMAL,
                    'nominal_crossing_insulation_gap_mm':1.6,'bend_radius_requested_mm':1.2,
                    'minimum_drawn_bend_radius_mm':min(e.radius() for e in wire.Edges() if e.geomType()=='CIRCLE'),
                    'groove_width_mm':1.4,'groove_lowest_normal_mm':-3.0,
                    'former_remaining_floor_mm':1.0,
                    'turn_convention':'Three nested rectangular perimeter passes; open spiral transition and terminal return mean these are visual passes, not three exact closed encirclements or a selected electrical turn count',
                    'electrical_selection':'Unselected: turns, wire construction, insulation, frequency, current, polarity, balance, parasitics and thermal rating require design and experiment'}}

def place(shape, origin, plane='XY', normal_sign=1):
    if plane=='XZ':
        shape=shape.rotate((0,0,0),(1,0,0),-90*normal_sign)
    return shape.translate(origin)

def place_point(point,origin,plane='XY',normal_sign=1):
    u,v,n=point
    mapped=(u,v,n) if plane=='XY' else (u,normal_sign*n,-normal_sign*v)
    return [a+b for a,b in zip(origin,mapped)]
