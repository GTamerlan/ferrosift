"""Proven source-surface tessellation and GLB writer, adapted from preserved investor CAD. No dependency on prior files."""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import struct
import sys
from datetime import datetime, timezone
from collections import defaultdict
from pathlib import Path
import cadquery as cq
import numpy as np
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
from OCP.BRep import BRep_Tool
from OCP.BRepLib import BRepLib_ToolTriangulatedShape
from OCP.TopLoc import TopLoc_Location
from OCP.TopAbs import TopAbs_Orientation

def rgb(c):
    if isinstance(c,str):return [int(c.lstrip('#')[i:i+2],16)/255 for i in (0,2,4)]
    return list(c[:3])


def bbox(shape):
    b=Bnd_Box()
    BRepBndLib.AddOptimal_s(shape.wrapped,b,False,False)
    x0,y0,z0,x1,y1,z1=b.Get()
    return {'min':[x0,y0,z0],'max':[x1,y1,z1]}


def tessellate(part):
    # Retain indexed CAD-face vertices. Surface-derived normals shade true
    # cylinders/roundovers smoothly while independent BRep faces retain their
    # hard boundaries. This does not round or otherwise alter source geometry.
    shape=part['shape']
    angular_tolerance=0.32 if part.get('coil') or part.get('winding_id') else 0.16
    shape.mesh(0.6,angular_tolerance)
    from OCP.BRepAdaptor import BRepAdaptor_Surface
    vertices=[];normals=[];indices=[];apex_winding_repairs=[]
    for face_index,face in enumerate(shape.Faces()):
        loc=TopLoc_Location()
        poly=BRep_Tool.Triangulation_s(face.wrapped,loc)
        if poly is None:continue
        BRepLib_ToolTriangulatedShape.ComputeNormals_s(face.wrapped,poly)
        transform=loc.Transformation()
        reverse=face.wrapped.Orientation()==TopAbs_Orientation.TopAbs_REVERSED
        cone_apex=None
        if face.geomType()=='CONE':
            apex=BRepAdaptor_Surface(face.wrapped).Cone().Apex()
            cone_apex=np.array([apex.X(),apex.Y(),apex.Z()])
        offset=len(vertices)
        for i in range(1,poly.NbNodes()+1):
            vertex=poly.Node(i).Transformed(transform)
            normal=poly.Normal(i).Transformed(transform)
            direction=-1 if reverse else 1
            vertices.append([vertex.X(),vertex.Y(),vertex.Z()])
            normals.append([direction*normal.X(),direction*normal.Y(),direction*normal.Z()])
        for face_triangle_index,tri in enumerate(poly.Triangles()):
            order=(1,3,2) if reverse else (1,2,3)
            triangle=[tri.Value(j)+offset-1 for j in order]
            points=np.asarray([vertices[i] for i in triangle])
            area=np.cross(points[1]-points[0],points[2]-points[0])
            area_length=np.linalg.norm(area)
            if area_length>1e-10:
                reference=np.asarray([normals[i] for i in triangle]).mean(axis=0)
                agreement=float(np.dot(area,reference)/area_length)
                if agreement<=0:
                    # OCC can return a reversed triangle incident on the
                    # singular apex of a trimmed cone. Its nonsingular source
                    # surface normals still determine the outward side. Repair
                    # only that demonstrable case, preserving every position,
                    # source normal and undirected triangle edge. Other normal
                    # disagreements remain hard failures, not a generic flip.
                    distances=(np.linalg.norm(points-cone_apex,axis=1)
                               if cone_apex is not None else np.full(3,np.inf))
                    nonapex=distances>1e-6
                    if cone_apex is None or not np.any(~nonapex) or not np.any(nonapex):
                        raise ValueError(f'CAD normal/winding disagreement outside cone apex: {part["id"]}, face {face_index}')
                    regular_reference=np.asarray([normals[i] for i in triangle])[nonapex].mean(axis=0)
                    if np.dot(area,regular_reference)>=0:
                        raise ValueError(f'Ambiguous cone-apex orientation: {part["id"]}, face {face_index}')
                    triangle[1],triangle[2]=triangle[2],triangle[1]
                    apex_winding_repairs.append({'face_index':face_index,
                        'triangle_index_in_face':face_triangle_index,
                        'analytic_apex_mm':cone_apex.tolist(),
                        'winding_to_source_normal_agreement_before':agreement})
            indices.append(triangle)
    xyz=np.asarray(vertices,dtype=np.float64)
    nn=np.asarray(normals,dtype=np.float64)
    triangles=np.asarray(indices,dtype=np.int64)
    edges=xyz[triangles]
    areas=np.cross(edges[:,1]-edges[:,0],edges[:,2]-edges[:,0])
    triangles=triangles[np.linalg.norm(areas,axis=1)>1e-10]
    used,remap=np.unique(triangles.ravel(),return_inverse=True)
    xyz=xyz[used];nn=nn[used];triangles=remap.reshape((-1,3))
    if not np.isfinite(xyz).all() or not np.isfinite(nn).all():
        raise ValueError('Nonfinite CAD mesh: '+part['id'])
    if np.max(np.abs(np.linalg.norm(nn,axis=1)-1))>1e-5:
        raise ValueError('Invalid CAD surface normals: '+part['id'])
    base={k:v for k,v in part.items() if k!='shape'}
    return dict(base,tessellation_diagnostics={'linear_deflection_parameter':0.6,'relative_deflection':True,'angular_tolerance_rad':angular_tolerance,
                    'cone_apex_winding_repair_count':len(apex_winding_repairs),
                    'cone_apex_winding_repairs':apex_winding_repairs,
                    'positions_and_source_normals_modified':False},
                vertices=np.round(xyz,5).ravel().tolist(),normals=np.round(nn,6).ravel().tolist(),
                indices=triangles.ravel().tolist(),bbox=bbox(part['shape']))


def write_glb(objects,path):
    """Standard GLB2, named assembly nodes, mm->m and Z-up->Y-up explicitly."""
    scene={'asset':{'version':'2.0','generator':'Revalis CadQuery2.8 BRep tessellation'},'scene':0,
      'scenes':[{'nodes':[]}],'nodes':[],'meshes':[],'materials':[],'buffers':[{'byteLength':0}],
      'bufferViews':[],'accessors':[]}
    data=bytearray()
    def accessor(array,component,kind,target,limits=False):
        while len(data)%4:data.append(0)
        start=len(data);data.extend(array.tobytes())
        bv=len(scene['bufferViews']);scene['bufferViews'].append({'buffer':0,'byteOffset':start,'byteLength':array.nbytes,'target':target})
        a={'bufferView':bv,'componentType':component,'count':len(array),'type':kind}
        if limits:a.update(min=array.min(axis=0).astype(float).tolist(),max=array.max(axis=0).astype(float).tolist())
        i=len(scene['accessors']);scene['accessors'].append(a);return i
    for ob in objects:
        v=np.array(ob['vertices'],dtype=np.float32).reshape((-1,3))
        n=np.array(ob['normals'],dtype=np.float32).reshape((-1,3))
        v=np.column_stack((v[:,0],v[:,2],-v[:,1])).astype('<f4')*.001
        n=np.column_stack((n[:,0],n[:,2],-n[:,1])).astype('<f4')
        ind=np.array(ob['indices'],dtype='<u4')
        pa=accessor(v,5126,'VEC3',34962,True);na=accessor(n,5126,'VEC3',34962)
        ia=accessor(ind,5125,'SCALAR',34963)
        mat=len(scene['materials']);alpha=ob.get('opacity',1)
        material={'name':ob['id']+'_finish','pbrMetallicRoughness':{'baseColorFactor':rgb(ob['color'])+[alpha],'metallicFactor':.2,'roughnessFactor':.65},'doubleSided':True}
        if alpha<1:material['alphaMode']='BLEND'
        scene['materials'].append(material)
        mi=len(scene['meshes']);scene['meshes'].append({'name':ob['id'],'primitives':[{'attributes':{'POSITION':pa,'NORMAL':na},'indices':ia,'material':mat}]})
        animation=ob.get('animation')
        if animation:
            animation=dict(animation)
            if 'pivot' in animation:
                x,y,z=animation['pivot'];animation['pivot']=[x*.001,z*.001,-y*.001]
            if 'radius' in animation:animation['radius']*=.001
            axis=animation.get('axis')
            if axis in ('x','y','z'):
                animation['axis']={'x':'x','y':'z','z':'y'}[axis]
                if axis=='y':
                    if 'angle' in animation:animation['angle']*=-1
                    animation['direction']=-(animation.get('direction',1))
            if isinstance(animation.get('direction'),list):
                x,y,z=animation['direction'];animation['direction']=[x,z,-y]
            animation['coordinate_system']='glTF metres, Y up'
        ni=len(scene['nodes']);scene['nodes'].append({'name':ob['id'],'mesh':mi,'extras':{'label':ob['name'],'category':ob['category'],'scope':ob.get('scope'),'group':ob.get('group'),'materialClass':ob.get('materialClass'),'default_hidden':ob.get('default_hidden',False),'optional':ob.get('optional',False),'installed':ob.get('installed'),'animation':animation, 'status':'unvalidated_concept_geometry'}})
        scene['scenes'][0]['nodes'].append(ni)
    scene['buffers'][0]['byteLength']=len(data)
    payload=json.dumps(scene,separators=(',',':')).encode()
    payload+=b' '*((-len(payload))%4);data+=b'\0'*((-len(data))%4)
    result=struct.pack('<4sII',b'glTF',2,12+8+len(payload)+8+len(data))+struct.pack('<I4s',len(payload),b'JSON')+payload+struct.pack('<I4s',len(data),b'BIN\0')+data
    path.write_bytes(result)

