"""M02 mechanical presentation detail, editable BRep geometry.

Dimensions describe research packaging only, not selected hardware or ratings.
"""
import cadquery as cq

def box(dx,dy,dz,x=0,y=0,z=0):
    return cq.Workplane('XY').box(dx,dy,dz).translate((x,y,z)).val()

def ring_rect(width,height,wall,depth):
    outer=cq.Workplane('XY').box(width,height,depth).edges('|Z').fillet(3).translate((0,0,depth/2)).val()
    inner=cq.Workplane('XY').box(width-2*wall,height-2*wall,depth+2).edges('|Z').fillet(2).translate((0,0,depth/2)).val()
    return outer.cut(inner)

def keeper(height):
    """One nonmetallic bridge over three strands with two locating pins."""
    hh=(height-1.4)/2
    lo,hi=hh-14.3,hh+3.7
    body=box(6,hi-lo+2,.6,0,(lo+hi)/2,1.7)
    holes=[]
    for v in (lo,hi):
        foot=box(6,2,1.4,0,v,.7)
        pin=cq.Solid.makeCylinder(1,1,cq.Vector(0,v,-1),cq.Vector(0,0,1))
        body=body.fuse(foot).fuse(pin)
        holes.append(cq.Solid.makeCylinder(1.05,1.1,cq.Vector(0,v,-1.1),cq.Vector(0,0,1)))
    return body,holes

def orient(shape,origin,axis):
    if axis==(0,-1,0):shape=shape.rotate((0,0,0),(1,0,0),90)
    elif axis==(0,1,0):shape=shape.rotate((0,0,0),(1,0,0),-90)
    elif axis==(1,0,0):shape=shape.rotate((0,0,0),(0,1,0),90)
    elif axis==(0,0,-1):shape=shape.rotate((0,0,0),(1,0,0),180)
    elif axis!=(0,0,1):raise ValueError(axis)
    return shape.translate(origin)

def gland(wall_thickness):
    """Local Z points outward from outer wall face. Bore follows real cable."""
    def cylinder(r,h,z):return cq.Solid.makeCylinder(r,h,cq.Vector(0,0,z),cq.Vector(0,0,1))
    shaft=cylinder(6.3,wall_thickness+14,-wall_thickness-2)
    flange=cq.Workplane('XY').polygon(6,19).extrude(3).val()
    nose=cylinder(7.3,5,7)
    body=shaft.fuse(flange).fuse(nose).cut(cylinder(4.2,wall_thickness+16,-wall_thickness-3))
    # A shallow annular separation line distinguishes compression cap geometry.
    groove=cylinder(7.5,.6,7.4).cut(cylinder(6.4,.8,7.3))
    body=body.cut(groove)
    locknut=cq.Workplane('XY').polygon(6,18).extrude(2).translate((0,0,-wall_thickness-2)).val().cut(cylinder(6.3,4,-wall_thickness-3))
    seal=cylinder(4.2,2,10).cut(cylinder(4,4,9))
    opening=cylinder(6.4,wall_thickness+2,-wall_thickness-1)
    return {'body':body,'locknut':locknut,'seal':seal,'wall_opening':opening}

def socket_cutter(radius):
    """Three millimetres of recess in a five millimetre head; two remain."""
    return cq.Workplane('XY').polygon(6,radius*1.5).extrude(3.05).val()
