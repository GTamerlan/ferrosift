"""Locate draft cable overlaps from immutable review metadata, without live CAD."""
from pathlib import Path
import json
import cadquery as cq
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib

HERE=Path(__file__).resolve().parent
def bb(s):
 b=Bnd_Box();BRepBndLib.AddOptimal_s(s.wrapped,b,False,False);v=b.Get()
 return {'min':list(v[:3]),'max':list(v[3:])}
def main():
 folder=HERE/'draft_01_findings'
 rows=json.loads((folder/'HARDWARE_GEOMETRY_REVIEW.json').read_text())['parts'];solids={}
 for row in rows:
  m=row['metadata']
  if m['materialClass']!='cable':continue
  edges=[]
  for e in m['path_edges']:
   v=[cq.Vector(*e[k]) for k in ('start','middle','end')]
   edges.append(cq.Edge.makeLine(v[0],v[2]) if e['type']=='LINE' else cq.Edge.makeThreePointArc(*v))
  wire=cq.Wire.assembleEdges(edges)
  profile=cq.Wire.assembleEdges([cq.Edge.makeCircle(m['cable_radius_mm'],wire.startPoint(),edges[0].tangentAt(0))])
  solids[row['id']]=cq.Solid.sweep(profile,[],wire,True,False,transitionMode='round')
 out=[]
 for p in json.loads((folder/'FINDINGS.json').read_text())['failed_cable_pairs']:
  intersection=solids[p['a']].intersect(solids[p['b']])
  out.append({**p,'collision_bounds_mm':bb(intersection),'collision_centres_mm':[list(s.Center().toTuple()) for s in intersection.Solids()]})
 (folder/'CABLE_COLLISION_LOCATIONS.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()
