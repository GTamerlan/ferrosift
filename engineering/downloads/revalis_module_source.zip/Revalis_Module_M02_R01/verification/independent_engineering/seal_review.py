"""Seal reviewed M02 measurements; no CAD mutation and no physical approval."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]/'engineering'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(n):return json.loads((HERE/n).read_text())
def write(n,v):(HERE/n).write_text(json.dumps(v,indent=2)+'\n')
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--source-only',action='store_true');args=parser.parse_args()
 sources={str(p.relative_to(ROOT)):sha(p) for p in [*sorted((ROOT/'cad').glob('*.py')),*sorted((ROOT/'design_basis').glob('*.json'))]}
 s=read('SOURCE_SPATIAL_REVIEW.json');w=read('WINDING_GEOMETRY_REVIEW.json');h=read('HARDWARE_GEOMETRY_REVIEW.json');c=s['spatial_checks']
 for r in (s,w,h):assert r['source_sha256']==sources,'Stale source review'
 assert s['part_count']==w['parts']==h['part_count']
 assert not c['unintended_metal_in_reservation']
 assert not c['under_cartridge_withdrawal']['potential_obstructions']
 assert all(not x['potential_obstructions'] for x in c['other_removal_sweeps'])
 assert all(not x['obstructions'] for x in c['optical_central_rays'])
 assert not c['adjustment_hardware_guard_collisions']
 assert all(x['interpretation']=='intended_coupling_engagement' for x in c['module_host_intersections'])
 assert all((x['cable'],x['fixed'])==('cable_encoder','encoder_body') for x in c['cable_structure_intersections'])
 assert all(x['intersection_mm3']<1e-4 and x['distance_mm']>0 for x in c['cable_pair_separation'])
 for q in c['cable_path_continuity']:
  assert q['valid'] and q['solid_count']==1 and q['maximum_adjacent_endpoint_gap_mm']<1e-6 and not q['sampled_path_points_outside_cable']
  assert abs(q['actual_minimum_bend_radius_mm']-q['reported_minimum_bend_radius_mm'])<1e-6
 assert w['coil_count']==6
 assert all(x['intersection_mm3']<1e-4 for x in w['coil_pair_clearances'])
 for q in w['coils']:
  assert q['baseline_m01_w1_path_identity']=='unchanged' and q['solid_count']==1 and not q['path_closed']
  assert not q['insulation_intersections']
  assert abs(q['former']['groove_floor_probe_thickness_mm']-1)<1e-5
  assert q['nominal_min_nonlocal_insulation_separation_mm']>1.14
  assert all(x['intersection_mm3']<1e-4 or x['id'] in q['winding_metadata']['terminal_ids'] for x in q['parts_within_5mm'])
 assert len(h['gland_checks'])==13
 for g in h['gland_checks']:
  for k in ('wall_bore_probe_intersection_mm3','body_host_intersection_mm3','locknut_host_intersection_mm3','body_host_distance_mm','locknut_host_distance_mm','body_locknut_distance_mm','body_seal_distance_mm'):assert abs(g[k])<1e-5,(g['id'],k,g[k])
  if g['metadata']['cable_id']:
   assert g['cable_body_intersection_mm3']<1e-5 and abs(g['cable_body_distance_mm']-.2)<1e-5
   assert g['cable_seal_intersection_mm3']<1e-5 and g['cable_seal_distance_mm']<1e-5
   assert all(p['inside_cable'] for p in g['cable_axis_samples'])
 for q in h['socket_checks']:
  assert q['hex_floor_face_count']==q['socket_mouth_face_count']==1
  assert abs(q['exact_face_recess_depth_mm']-3)<1e-6
  assert q['metadata']['head_thickness_mm']-q['exact_face_recess_depth_mm']>1.99999
 parts={p['id']:p for p in h['parts']}
 bobbins=[p for p in h['parts'] if p['metadata'].get('winding_part') in ('bobbin','retainer')]
 assert len(bobbins)==12
 for p in bobbins:
  assert p['actual_contacts'] and all(x['intersection_mm3']<1e-4 for x in p['actual_contacts'])
  assert any('former' in x['id'] for x in p['actual_contacts'])
  if p['metadata']['winding_part']=='retainer':assert any(x['id']==p['metadata']['winding_id']+'_insulation' for x in p['actual_contacts'])
 wedge=parts['optional_3d_mount']
 assert {x['id'] for x in wedge['actual_contacts']}=={'optional_3d_body','optical_slotted_carrier'}
 assert all(x['intersection_mm3']<1e-4 for x in wedge['actual_contacts'])
 minimum=min(c['cable_pair_separation'],key=lambda x:x['distance_mm'])
 holds=[
 'Inherited window/lane/cover/panel fastener receivers and four lower-rail clamp passages remain simplified; coordinated bores, bearing and engagement are unresolved. Socket detail does not complete those interfaces.',
 'Existing structural envelope joints include overlapping material. They are coordination connections, not resolved separate manufactured parts or certified welds. The review does not assert an entirely clash-free manufactured assembly.',
 'RGB screw engagement into housing and encoder coupling/device endpoints are deliberate illustrative overlaps; threads, seals, fit, torque and strength remain unqualified.',
 'External cable solids are geometric routes. Selected bend limits, supports over long spans, slack, abrasion, strain relief, installation and cabinet wiring remain unresolved. The encoder sensor-end seal is unmodeled; power/host-I/O gland cables are unmodeled.',
 'Internal winding-to-acquisition harness, shielding/pinout/circuit, electrical turns/wire/current/frequency and phase reference are unresolved. No closed electrical circuit or balanced response is claimed.',
 'All selected materials, tolerances, loaded deflection, wear, fatigue, electromagnetic/thermal/ingress/safety behavior and fabrication validation remain open.',
 'The 180 mm central mechanical lane on a 600 mm host is not measured sensing width. Feed, exclusion/containment, optical FOV, moving-object association, last usable observation and downstream capture are unvalidated.',
 'Grey host is partial context; roller bearings, drive, complete guards and turnaround geometry are omitted.',
 'Release geometry and coordinate metadata are nominal at belt Z1000. The +100 datum test checks shape translation only; other sizes and metadata variants require coordinated regeneration and review.'
 ]
 passed={
 'glands':{'count':13,'connected_cable_entries':11,'wall_bores_open':True,'flange_and_locknut_bearing':True,'cable_radial_bore_clearance_mm':.2,'nominal_seal_contact':True},
 'sockets':{'count':len(h['socket_checks']),'actual_recess_depth_mm':3,'remaining_head_floor_mm':2,'method':'Exact planar mouth/floor distance; unchanged baseline fasteners also checked by removed-volume prism.'},
 'bobbins':{'lips':6,'keepers':6,'former_contacts':True,'keeper_insulation_contact':True,'no_positive_volume_penetration':True,'tx_keeper_to_rx_former_mm':1},
 'optics':{'tilted_spacer_bearing_without_overlap':True,'central_rays_clear':3,'field_of_view_validated':False},
 'cables':{'routes':len(c['cable_path_continuity']),'pairs':len(c['cable_pair_separation']),'no_pair_intersections':True,'minimum_pair_gap':minimum,'unintended_fixed_collisions':0,'path_continuity':True},
 'service':{'continuous_conservative_sweeps_clear':4,'removal_prerequisites_preserved':True},
 'windings':{'functional_count':6,'tx':2,'rx':4,'six_paths_identical_to_M01_W1':True,'nonlocal_min_insulation_gap_mm':min(p['nominal_min_nonlocal_insulation_separation_mm'] for p in w['coils']),'return_groove_floor_mm':1,'tx_terminal_to_rx_former_mm':1.2,'electrical_optimization_claim':False}
 }
 evidence={n:sha(HERE/n) for n in ('SOURCE_SPATIAL_REVIEW.json','WINDING_GEOMETRY_REVIEW.json','HARDWARE_GEOMETRY_REVIEW.json')}
 now=datetime.now(timezone.utc).isoformat()
 common={'revision':'M02','generated_utc':now,'source_sha256':sources,'scope':'Nominal research geometry only; no physical, electrical, performance or fabrication certification.','evidence':evidence,'retained_holds':holds}
 write('HARDWARE_REVIEW_VERDICT.json',{**common,'result':'passed_nominal_hardware_geometry_only','passed_checks':passed})
 write('WINDING_REVIEW_VERDICT.json',{**common,'result':'passed_nominal_winding_geometry_only','passed_checks':passed['windings']})
 if args.source_only:
  print('M02 source/hardware/winding review sealed; export/datum reconciliation remains pending.');return
 d=read('DATUM_PARAMETER_REVIEW.json');e=read('EXPORT_FILE_REVIEW.json')
 assert d['result']==e['result']=='pass' and d['dependency_sha256']==e['source_sha256']==sources
 for f in e['files']:assert sha(ROOT/f['path'])==f['sha256']
 assert sha(ROOT/'web/module-assembly.json')==e['web_sha256']
 evidence.update({n:sha(HERE/n) for n in ('DATUM_PARAMETER_REVIEW.json','EXPORT_FILE_REVIEW.json','HARDWARE_REVIEW_VERDICT.json','WINDING_REVIEW_VERDICT.json','REPRODUCTION.md')})
 inherited=[{'part':p['id'],'intersections':[x for x in p['actual_contacts'] if x['intersection_mm3']>1e-4]} for p in h['parts'] if p['metadata']['materialClass']!='cable' and any(x['intersection_mm3']>1e-4 for x in p['actual_contacts'])]
 verdict={**common,'result':'passed_nominal_research_geometry_only','part_count':s['part_count'],'passed_checks':passed,'export_checks':e['checks'],'datum_scope':d['scope'],'baseline_status':'M01-W1 fixtures are historical comparison inputs only. Earlier baseline and failed draft receipts are superseded for this M02 release. Original v01 remains preserved.','reviewed_inherited_overlap_holds':inherited}
 write('INDEPENDENT_REVIEW_VERDICT.json',verdict)
 summary=f'''# M02 independent engineering review

Result: **passed nominal research geometry only**, for the exact source hashes in `INDEPENDENT_REVIEW_VERDICT.json`. This is not fabrication, installation, operation or performance approval.

The review measured {s['part_count']} source components, then reconciled source bounds and volumes with STEP/BREP, binary GLB positions/normals/indices and the web mesh. Host/module and optional-part scopes remained consistent. Four continuous conservative service sweeps and three central optical rays were clear under their stated removal prerequisites. Central rays do not validate a complete field of view.

All six functional winding paths remain geometrically identical to M01-W1: two Tx and four candidate Rx, in XY and XZ orientations. Their illustrated perimeter passes are not an optimized electrical turn count. Continuous conductors, intended pin contacts, distinct channels, unpenetrated insulation, recessed returns and 1 mm groove floors were checked. The minimum nonlocal insulation-envelope gap is {passed['windings']['nonlocal_min_insulation_gap_mm']:.6f} mm. The Tx terminal retains 1.2 mm to the Rx former; the new Tx keeper has 1.0 mm to that former. These are unloaded nominal dimensions.

Six perimeter lips and six keepers contact their intended former/insulation without positive-volume penetration. The repaired transverse Tx lip and tilted 3D spacer now meet their mating surfaces without overlap. All 13 glands have open real wall bores and exterior/interior bearing contact. Eleven connected entries have aligned cable axis samples, 0.2 mm radial body clearance and nominal seal contact; two entries have no external cable modeled. All {len(h['socket_checks'])} socket recesses measure 3 mm deep with 2 mm head floor.

All 15 pairs of the six external cable routes are separate. The minimum nominal cable-to-cable gap is {minimum['distance_mm']:.6f} mm ({minimum['a']} / {minimum['b']}). Rounded paths are continuous single solids and sampled centerlines lie inside them. Bend geometry does not qualify an actual cable. The only cable/device volume intersection is the explicitly illustrative encoder endpoint. The only module/host intersection is the illustrative encoder shaft coupling.

The first draft failed for five cable-pair overlaps, two cable/rail penetrations, one bobbin/housing overlap and an optical-spacer overlap. The current receipt supersedes that draft after repair and rerun; no physical tests were performed.

## Unresolved limits

'''+''.join('- '+x+'\n' for x in holds)+'''
## Evidence and reproduction

`INDEPENDENT_REVIEW_VERDICT.json` binds the raw source, winding, hardware, datum and export receipts by SHA-256 and lists scoped passing checks and explicit inherited overlap holds. `REPRODUCTION.md` gives the portable commands and baseline-fixture requirements. Historical BASELINE files are reference inputs, not M02 approvals.
'''
 (HERE/'INDEPENDENT_ENGINEERING_REVIEW.md').write_text(summary)
 print(json.dumps({'result':verdict['result'],'revision':'M02','parts':s['part_count'],'minimum_cable_gap_mm':minimum['distance_mm'],'source_sha256':sources},indent=2))
if __name__=='__main__':main()
