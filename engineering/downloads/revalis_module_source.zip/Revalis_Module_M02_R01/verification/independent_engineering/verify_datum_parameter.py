"""Check geometric-only belt datum translation; no variant exports are written."""
from pathlib import Path
import copy, hashlib, importlib.util, json, sys
from datetime import datetime, timezone
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]/'engineering'
sys.path.insert(0,str(ROOT/'cad'))
source=ROOT/'cad/build_module.py'
before=hashlib.sha256(source.read_bytes()).hexdigest()
dependencies=[*sorted((ROOT/'cad').glob('*.py')),*sorted((ROOT/'design_basis').glob('*.json'))]
dependency_hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in dependencies}
spec=importlib.util.spec_from_file_location('datum_review_source',source)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
p=json.loads((ROOT/'design_basis/parameters.json').read_text())
q=copy.deepcopy(p);q['host']['belt_top_z']+=100
nominal={v['id']:v for v in module.build(p)}
variant={v['id']:v for v in module.build(q)}
def bounds(shape):
    b=Bnd_Box();BRepBndLib.AddOptimal_s(shape.wrapped,b,False,False)
    return list(b.Get())
errors=[]
for key,a in nominal.items():
    old=bounds(a['shape']);new=bounds(variant[key]['shape'])
    expected=[v+(100 if i in(2,5) else 0) for i,v in enumerate(old)]
    error=max(abs(x-y) for x,y in zip(expected,new))
    if error>1e-6:errors.append({'id':key,'max_bbox_error_mm':error})
after=hashlib.sha256(source.read_bytes()).hexdigest()
assert before==after,'Source changed during parameter review'
assert dependency_hashes=={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in dependencies},'Dependency changed during parameter review'
assert not errors,errors
report={'generated_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':before,
        'dependency_sha256':dependency_hashes,
        'part_count':len(nominal),'baseline_belt_top_mm':p['host']['belt_top_z'],
        'variant_belt_top_mm':q['host']['belt_top_z'],'all_part_bboxes_translate_exactly_mm':100,
        'result':'pass','revision':'M02','scope':'Geometry-only datum translation. Exported nominal M02 and coordinate metadata are pinned to Z1000. This does not establish arbitrary host widths or translate descriptive coordinate metadata.'}
(HERE/'DATUM_PARAMETER_REVIEW.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
