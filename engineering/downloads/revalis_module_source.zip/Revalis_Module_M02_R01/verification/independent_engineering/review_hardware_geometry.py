"""Independent M02 additions/contact review. Run only after source freeze.
Reports exact new/changed-part contacts for interpretation; no load/fit approval.
"""
from pathlib import Path
from datetime import datetime,timezone
import importlib.util,hashlib,json,sys,math
import cadquery as cq
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]/'engineering'
sys.path.insert(0,str(ROOT/'cad'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def bounds(s):
 b=Bnd_Box();BRepBndLib.AddOptimal_s(s.wrapped,b,False,False);v=b.Get();return {'min':list(v[:3]),'max':list(v[3:])}
def bbox_distance(a,b):return sum(max(a['min'][i]-b['max'][i],b['min'][i]-a['max'][i],0)**2 for i in range(3))**.5
def overlap(a,b):return all(a['min'][i]<b['max'][i]-1e-7 and b['min'][i]<a['max'][i]-1e-7 for i in range(3))
def main():
 files=[*sorted((ROOT/'cad').glob('*.py')),*sorted((ROOT/'design_basis').glob('*.json'))]
 original={str(p.relative_to(ROOT)):sha(p) for p in files}
 spec=importlib.util.spec_from_file_location('m02_independent_hardware',ROOT/'cad/build_module.py');source=importlib.util.module_from_spec(spec);spec.loader.exec_module(source)
 p=json.loads((ROOT/'design_basis/parameters.json').read_text());parts=source.build(p);rows={x['id']:x for x in parts}
 bb={x['id']:bounds(x['shape']) for x in parts};vol={x['id']:x['shape'].Volume() for x in parts}
 baseline=json.loads((HERE/'BASELINE_M01_W1_SOURCE_SPATIAL_REVIEW.json').read_text());changed={}
 for ident,b in bb.items():
  old=baseline['part_bounds'].get(ident)
  if old is None:changed[ident]={'change':'added'};continue
  dv=vol[ident]-baseline['part_volumes_mm3'][ident]
  db=max(abs(b[side][i]-old[side][i]) for side in ('min','max') for i in range(3))
  if db>1e-6 or abs(dv)>1e-6:changed[ident]={'change':'modified','volume_change_mm3':dv,'max_bound_change_mm':db}
 reviews=[]
 for ident,change in changed.items():
  a=rows[ident];contacts=[];near=[]
  for b in parts:
   if a is b:continue
   if bbox_distance(bb[ident],bb[b['id']])>1.0:continue
   distance=a['shape'].distance(b['shape'])
   if distance>1.0:continue
   item={'id':b['id'],'distance_mm':distance,'material':b['materialClass'],'intersection_mm3':a['shape'].intersect(b['shape']).Volume() if overlap(bb[ident],bb[b['id']]) else 0.0}
   (contacts if distance<1e-5 else near).append(item)
  metadata={k:v for k,v in a.items() if k not in ('shape',)}
  reviews.append({'id':ident,**change,'bounds_mm':bb[ident],'volume_mm3':vol[ident],'metadata':metadata,'actual_contacts':contacts,'near_within_1mm':near})
 glands=[]
 for a in parts:
  if 'gland' not in a:continue
  g=a['gland'];host=rows[g['host_id']];o=cq.Vector(*g['outer_wall_point_mm']);axis=cq.Vector(*g['outward_axis']);th=g['wall_thickness_mm']
  probe=cq.Solid.makeCylinder(g['wall_bore_radius_mm']-.01,th,o.sub(axis.multiply(th)),axis)
  locknut=rows[a['id']+'_locknut'];seal=rows[a['id']+'_seal'];cable=rows.get(g.get('cable_id'))
  item={'id':a['id'],'metadata':g,'wall_bore_probe_intersection_mm3':host['shape'].intersect(probe).Volume(),
        'body_host_intersection_mm3':a['shape'].intersect(host['shape']).Volume(),
        'body_host_distance_mm':a['shape'].distance(host['shape']),
        'locknut_host_intersection_mm3':locknut['shape'].intersect(host['shape']).Volume(),
        'locknut_host_distance_mm':locknut['shape'].distance(host['shape']),
        'body_locknut_distance_mm':a['shape'].distance(locknut['shape']),
        'body_seal_distance_mm':a['shape'].distance(seal['shape'])}
  if cable:
   item.update(cable_body_intersection_mm3=cable['shape'].intersect(a['shape']).Volume(),
               cable_body_distance_mm=cable['shape'].distance(a['shape']),
               cable_seal_intersection_mm3=cable['shape'].intersect(seal['shape']).Volume(),
               cable_seal_distance_mm=cable['shape'].distance(seal['shape']))
   item['cable_axis_samples']=[{'outward_mm':t,'inside_cable':cable['shape'].isInside(o.add(axis.multiply(t)),1e-6)} for t in (-th,0,3,6,10,12)]
  glands.append(item)
 sockets=[]
 for a in parts:
  if 'socket_recess' not in a:continue
  m=a['socket_recess'];item={'id':a['id'],'metadata':m}
  planes=[f for f in a['shape'].Faces() if f.geomType()=='PLANE']
  floors=[f for f in planes if len(f.Edges())==6 and all(e.geomType()=='LINE' for e in f.Edges())]
  mouths=[f for f in planes if len(f.Edges())==7 and sum(e.geomType()=='CIRCLE' for e in f.Edges())==1]
  item['hex_floor_face_count']=len(floors);item['socket_mouth_face_count']=len(mouths)
  if len(floors)==len(mouths)==1:
   measured=abs((floors[0].Center()-mouths[0].Center()).dot(mouths[0].normalAt()))
   item['exact_face_recess_depth_mm']=measured
   item['exact_face_depth_difference_mm']=measured-m['depth_mm']
  if a['id'] in baseline['part_volumes_mm3']:
   removed=baseline['part_volumes_mm3'][a['id']]-vol[a['id']]
   area=3*math.sqrt(3)/2*(m['hex_circumdiameter_mm']/2)**2
   depth=removed/area
   item.update(removed_volume_mm3=removed,hex_area_mm2=area,measured_recess_depth_mm=depth,measured_floor_mm=m['head_thickness_mm']-depth,
               nominal_depth_difference_mm=depth-m['depth_mm'],scope='Depth inferred from removed volume versus unchanged M01-W1 head and shaft; exact six-sided prism area.')
  sockets.append(item)
 assert original=={str(p.relative_to(ROOT)):sha(p) for p in files},'Source changed during review'
 report={'generated_utc':datetime.now(timezone.utc).isoformat(),'revision':'M02','source_sha256':original,'scope':'Nominal contact/interference of new or modified geometry only; no material, fit, load, bending rating or fabrication validation.','part_count':len(parts),'new_or_modified_count':len(changed),'removed_ids':sorted(set(baseline['part_bounds'])-set(rows)),'parts':reviews,'gland_checks':glands,'socket_checks':sockets,'status':'requires_independent_interpretation'}
 (HERE/'HARDWARE_GEOMETRY_REVIEW.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'part_count':len(parts),'changed':[(r['id'],r['change']) for r in reviews]},indent=2))
if __name__=='__main__':main()
