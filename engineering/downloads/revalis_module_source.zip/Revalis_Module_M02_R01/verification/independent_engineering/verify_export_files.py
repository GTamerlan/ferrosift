"""Independent file-level geometry check; run after the M02 export is frozen.

Does not import or call the author's tessellation/export helper. Tests GLB binary
positions against the web mesh, explicit scope metadata and STEP/BREP volumes.
"""
from pathlib import Path
import hashlib
import json
import struct
from datetime import datetime, timezone

import cadquery as cq
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1] / 'engineering'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_glb(path):
    raw = path.read_bytes()
    magic, version, length = struct.unpack_from('<4sII', raw)
    assert magic == b'glTF' and version == 2 and length == len(raw)
    offset = 12
    chunks = {}
    while offset < len(raw):
        size, kind = struct.unpack_from('<I4s', raw, offset)
        offset += 8
        chunks[kind] = raw[offset:offset + size]
        offset += size
    return json.loads(chunks[b'JSON']), chunks[b'BIN\0']


def accessor(document, data, index):
    a = document['accessors'][index]
    v = document['bufferViews'][a['bufferView']]
    assert 'byteStride' not in v, 'Interleaved data needs explicit decoding'
    dtype = {5126: '<f4', 5125: '<u4', 5123: '<u2'}[a['componentType']]
    width = {'SCALAR': 1, 'VEC3': 3, 'VEC4': 4}[a['type']]
    start = v.get('byteOffset', 0) + a.get('byteOffset', 0)
    return np.frombuffer(data, dtype=dtype, count=a['count'] * width,
                         offset=start).reshape(a['count'], width)


def main():
    webfile = ROOT / 'web/module-assembly.json'
    web = json.loads(webfile.read_text())
    assert 'M02' in web['releaseId'], 'M02 release identity required'
    for name, expected in web['provenance']['sourceSha256'].items():
        assert digest(ROOT / name) == expected, ('Stale export provenance', name)
    objects = web['objects']
    mapped = {p['id']: p for p in objects}
    assert len(mapped) == len(objects), 'Duplicate part IDs'
    assert all(p['scope'] in ('module', 'host_reference') for p in objects)
    source_review = json.loads((HERE / 'SOURCE_SPATIAL_REVIEW.json').read_text())
    assert all(web['provenance']['sourceSha256'][name] == value
               for name, value in source_review['source_sha256'].items())
    manifest = json.loads((ROOT/'exports/assembly_manifest.json').read_text())
    manifest_parts = {p['id']:p for p in manifest['parts']}
    assert set(mapped) == set(source_review['part_bounds']) == set(manifest_parts)
    for ident, ob in mapped.items():
        actual_bbox = source_review['part_bounds'][ident]
        for side in ('min', 'max'):
            assert max(abs(a-b) for a,b in zip(ob['bbox'][side],actual_bbox[side])) < 1e-6
        actual_volume = source_review['part_volumes_mm3'][ident]
        assert abs(manifest_parts[ident]['volume_mm3']-actual_volume)/actual_volume < 1e-8
        assert manifest_parts[ident]['scope'] == ob['scope']
    report = {'generated_utc': datetime.now(timezone.utc).isoformat(),
              'revision': 'M02', 'source_sha256': web['provenance']['sourceSha256'],
              'scope': 'Independent export identity and scale review only',
              'web_sha256': digest(webfile), 'files': [], 'checks': []}
    for name, scopes in [('module_assembly', {'module'}),
                         ('module_with_host', {'module', 'host_reference'})]:
        file = ROOT / f'exports/{name}.glb'
        doc, data = load_glb(file)
        selected = {key: value for key, value in mapped.items()
                    if value['scope'] in scopes}
        assert {n['name'] for n in doc['nodes']} == set(selected)
        max_error = 0.0
        for node in doc['nodes']:
            ob = selected[node['name']]
            assert node['extras']['scope'] == ob['scope']
            assert node['extras'].get('optional', False) == ob.get('optional', False)
            primitive = doc['meshes'][node['mesh']]['primitives'][0]
            actual = accessor(doc, data, primitive['attributes']['POSITION'])
            original = np.array(ob['vertices']).reshape(-1, 3)
            expected = original[:, [0, 2, 1]] * np.array([.001, .001, -.001])
            assert actual.shape == expected.shape
            error = float(np.abs(actual - expected).max())
            max_error = max(max_error, error)
            assert error < 1e-6, (ob['id'], error)
            actual_indices = accessor(doc, data, primitive['indices']).ravel()
            assert np.array_equal(actual_indices, np.array(ob['indices']))
            assert np.isfinite(actual).all()
            normals = accessor(doc, data, primitive['attributes']['NORMAL'])
            original_normals = np.array(ob['normals']).reshape(-1, 3)
            expected_normals = original_normals[:, [0, 2, 1]] * np.array([1, 1, -1])
            assert np.abs(normals-expected_normals).max() < 1e-5
            assert np.abs(np.linalg.norm(normals, axis=1)-1).max() < 1e-5
        stepfile = ROOT / f'exports/{name}.step'
        brepfile = ROOT / f'exports/{name}.brep'
        step = cq.importers.importStep(str(stepfile)).val()
        brep = cq.Shape.importBrep(str(brepfile))
        assert step.isValid() and brep.isValid()
        error = abs(step.Volume() - brep.Volume()) / max(1.0, brep.Volume())
        assert error < 1e-7
        source_volume = sum(source_review['part_volumes_mm3'][ident] for ident in selected)
        source_error = abs(step.Volume()-source_volume)/source_volume
        assert source_error < 1e-7
        assert len(step.Solids()) == len(brep.Solids())
        report['checks'].append({'name': name, 'parts': len(selected),
            'max_glb_coordinate_error_metres': max_error,
            'step_brep_relative_volume_error': error,
            'step_independent_source_relative_volume_error': source_error,
            'step_solids': len(step.Solids()),
            'scope_and_optional_metadata': 'pass'})
        for path in (file, stepfile, brepfile):
            report['files'].append({'path': str(path.relative_to(ROOT)),
                'bytes': path.stat().st_size, 'sha256': digest(path)})
    report['result'] = 'pass'
    (HERE / 'EXPORT_FILE_REVIEW.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
