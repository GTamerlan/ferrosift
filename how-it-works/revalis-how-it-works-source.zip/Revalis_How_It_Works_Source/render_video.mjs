import fs from 'node:fs/promises';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
const require=createRequire(import.meta.url);
const sharp=require('sharp');
const output=path.dirname(fileURLToPath(import.meta.url));
const {scenes,duration,renderSvg}=await import(path.join(output,'scenes.mjs'));
const frameDir=path.join(output,'build/frames');
await fs.mkdir(frameDir,{recursive:true});
const fps=24,frames=duration*fps;
const sceneInfo={duration_seconds:duration,fps,width:1280,height:720,frame_count:frames,scenes,scope:'Original illustrative schematic. No field solution, measured data, physical validation or selected electrical specifications.'};
await fs.writeFile(path.join(output,'scene-data.json'),JSON.stringify(sceneInfo,null,2)+'\n');
await fs.writeFile(path.join(output,'build/scene-data.json'),JSON.stringify(sceneInfo,null,2)+'\n');
let start=0;let transcript='REVALIS — HOW IT WORKS\nOriginal illustrative concept. 50-second silent guide.\n\n';let vtt='WEBVTT\n\n';
const ts=x=>`00:00:${String(x).padStart(2,'0')}.000`;
for(const s of scenes){transcript+=`${start}–${start+s.duration}s | ${s.title}\n${s.caption}\n${s.note}\n\n`;vtt+=`${ts(start)} --> ${ts(start+s.duration)}\n${s.title}\n${s.caption}\n\n`;start+=s.duration;}
transcript+='Arrows are illustrative, not solved fields. Orange loops are electrical currents inside a generic conductor. Blue arrows represent magnetic field in air. No measured response, classification, assay, value, coverage or validated performance is shown.\n\nAssociation can fail through overlap, occlusion, slip, bounce or rotation. Encoder travel alone is not proof of object identity. Another field direction must earn its cost against simpler baselines. The existing host sorter and collection require end-to-end validation.\n\nPrimary physics sources:\nhttps://www.feynmanlectures.caltech.edu/II_17.html\nhttps://openstax.org/books/university-physics-volume-2/pages/13-5-eddy-currents\nhttps://docs.zhinst.com/mfli_user_manual/signal_processing_basics.html\n';
await fs.writeFile(path.join(output,'transcript.txt'),transcript);await fs.writeFile(path.join(output,'captions.vtt'),vtt);
let next=0;await Promise.all(Array.from({length:4},async()=>{while(next<frames){const n=next++;await sharp(Buffer.from(renderSvg(n/fps,{video:true}))).png().toFile(path.join(frameDir,`${String(n).padStart(5,'0')}.png`));if(n%240===0)console.log(`Rendered ${n}/${frames}`);}}));
let t=0;const tiles=[];for(const s of scenes){const b=await sharp(Buffer.from(renderSvg(t+s.duration/2,{video:true}))).resize(480,270).png().toBuffer();tiles.push({input:b,left:(tiles.length%3)*480,top:Math.floor(tiles.length/3)*270});t+=s.duration;}
await sharp({create:{width:1440,height:810,channels:3,background:'#f8faf6'}}).composite(tiles).png().toFile(path.join(output,'build/storyboard.png'));
console.log(JSON.stringify({frames,frameDir,duration,fps}));
