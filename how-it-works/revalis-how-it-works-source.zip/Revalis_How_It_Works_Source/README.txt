REVALIS — OPTIONAL ILLUSTRATED GUIDE SOURCE

Editable native SVG scene generator, browser controller, styling, scene data,
captions and transcript. Nine scenes, 50 seconds. Conceptual teaching only.
No measured fields, classification, material assay or physical validation.

Serve this directory over HTTP and open index.html for the interactive guide.
The MP4 is distributed separately as revalis-how-it-works.mp4.

For local media rebuilding with existing dependencies:
  node render_video.mjs
  python3 encode_video.py
Node requires Sharp; Python requires OpenCV with an H.264-capable FFmpeg
backend. Rebuilding needs 1,200 PNG frames and local disk space. No installation,
network connection or cloud service is performed by these scripts.

Revalis branding changes only the former project wordmark in the established
educational guide. Research attributions, scene timing and physical caveats
are retained. This generic optional guide is separate from the 3D Explorer
whole-piece illustration and from recorded model evidence.
