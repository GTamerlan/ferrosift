"""Encode and independently decode the generated SVG frames using installed OpenCV/FFmpeg.

Artifact generation only: no browser capture or UI automation. Uses the existing
.venv-vision environment. No installation, network access or physical simulation.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import cv2

root=Path(__file__).resolve().parent
education=root/'build'
public=root
frames=education/'frames'
output=public/'revalis-how-it-works.mp4'
fps=24
count=1200
size=(1280,720)
writer=cv2.VideoWriter(str(output),cv2.CAP_FFMPEG,cv2.VideoWriter_fourcc(*'avc1'),fps,size)
assert writer.isOpened(), 'Installed H.264 encoder unavailable'
frame_hash=hashlib.sha256()
for i in range(count):
    p=frames/f'{i:05d}.png'
    frame_hash.update(p.name.encode()+hashlib.sha256(p.read_bytes()).digest())
    im=cv2.imread(str(p))
    assert im is not None and (im.shape[1],im.shape[0])==size
    writer.write(im)
writer.release()
capture=cv2.VideoCapture(str(output),cv2.CAP_FFMPEG)
assert capture.isOpened()
metadata={'width':int(capture.get(cv2.CAP_PROP_FRAME_WIDTH)), 'height':int(capture.get(cv2.CAP_PROP_FRAME_HEIGHT)), 'fps':capture.get(cv2.CAP_PROP_FPS), 'reported_frame_count':int(capture.get(cv2.CAP_PROP_FRAME_COUNT))}
samples=[60,180,300,420,564,720,864,1008,1140]
tiles=[]
differences=[]
decoded=0
while True:
    ok,im=capture.read()
    if not ok: break
    assert (im.shape[1],im.shape[0])==size
    if decoded in samples:
        source=cv2.imread(str(frames/f'{decoded:05d}.png'))
        differences.append({'frame':decoded,'time_seconds':decoded/fps,'mean_absolute_pixel_difference':float(cv2.absdiff(im,source).mean())})
        cv2.imwrite(str(education/f'decoded_scene_{len(tiles)+1}.png'),im)
        tiles.append(cv2.resize(im,(480,270),interpolation=cv2.INTER_AREA))
    decoded+=1
capture.release()
assert decoded==count and metadata=={'width':1280,'height':720,'fps':24.0,'reported_frame_count':1200}
assert len(tiles)==9
assert max(x['mean_absolute_pixel_difference'] for x in differences)<5
cv2.imwrite(str(education/'decoded_storyboard.png'),cv2.vconcat([cv2.hconcat(tiles[i:i+3]) for i in (0,3,6)]))
paths=[public/'scenes.mjs',public/'scene-data.json',root/'render_video.mjs',Path(__file__),output]
receipt={'status':'PASS_ENCODE_AND_FULL_DECODE', 'created_utc':datetime.now(timezone.utc).isoformat(), 'duration_seconds':decoded/fps, 'decoded_frames':decoded, 'metadata':metadata, 'silent':True, 'encoder':'Existing .venv-vision OpenCV 5.0.0 / FFmpeg backend / H.264 avc1', 'frame_renderer':'Existing Sharp 0.35.4 + librsvg 2.62.91 rasterization of the same native scenes.mjs SVG renderer used by the browser', 'all_frame_png_ordered_digest':frame_hash.hexdigest(), 'regenerated_for_revalis_brand_only':True, 'sample_frame_comparisons':differences,'files':{str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths},'earlier_attempts':{'CapCut_ffmpeg':'Did not produce test output; not used','AVFoundation':'H.264 encoder unavailable; not used for final MP4'},'scope':'Illustrative educational animation only; no simulated electromagnetic solution, measured signal, validated classification, assay or host actuation.'}
(education/'VIDEO_EXPORT_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
(public/'video_metadata.json').write_text(json.dumps({k:receipt[k] for k in ['status','duration_seconds','decoded_frames','metadata','silent','scope']},indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['status','duration_seconds','decoded_frames','metadata']},indent=2))
